package com.neondeck.dj.audio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** Análisis offline: forma de onda coloreada, BPM, rejilla de beats y tonalidad (Camelot). */
object Analyzer {
    const val BIN = 128
    const val QCOLORS = 24

    private fun lerpC(a: Int, b: Int, t: Float): Int {
        val r = ((a shr 16 and 255) + ((b shr 16 and 255) - (a shr 16 and 255)) * t).toInt()
        val g = ((a shr 8 and 255) + ((b shr 8 and 255) - (a shr 8 and 255)) * t).toInt()
        val bl = ((a and 255) + ((b and 255) - (a and 255)) * t).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    private val STOPS = intArrayOf(
        0xFFFF1744.toInt(),   // graves (bombo): rojo
        0xFFFF9100.toInt(),   // graves-medios: naranja
        0xFFFFEA00.toInt(),   // medios bajos: amarillo
        0xFF00E676.toInt(),   // medios: verde
        0xFF18FFFF.toInt(),   // medios altos: cian
        0xFF2979FF.toInt(),   // agudos: azul
        0xFFD500F9.toInt()    // brillos altos: violeta
    )

    /** Color de la onda por frecuencia dominante: graves rojo/naranja, medios amarillo/verde, agudos azul/blanco. */
    @Suppress("UNUSED_PARAMETER")
    fun waveColor(i: Int, deck: Int = 0): Int {
        val x = (i / (QCOLORS - 1f)).coerceIn(0f, 1f) * (STOPS.size - 1)
        val k = x.toInt().coerceAtMost(STOPS.size - 2)
        return lerpC(STOPS[k], STOPS[k + 1], x - k)
    }

    /** Construye la forma de onda en streaming, a medida que llega el PCM. */
    class WaveBuilder(private val w: Waveform, srcRate: Int) {
        private val aL = (1.0 - exp(-2.0 * PI * 250.0 / srcRate)).toFloat()
        private val aH = (1.0 - exp(-2.0 * PI * 2500.0 / srcRate)).toFloat()
        private var l1 = 0f; private var l2 = 0f; private var h1 = 0f; private var h2 = 0f
        private var prevE = 0f
        private var runMax = 0.25f
        private var cMean = 0.35f
        var done = 0
            private set

        fun feed(pcm: ShortArray, decodedFrames: Int) {
            val target = decodedFrames / BIN
            if (target <= done) return
            w.ensure(target + 1)
            val peak = w.peak; val color = w.color; val onset = w.onset
            for (b in done until target) {
                var pk = 0f; var eL = 0f; var eM = 0f; var eH = 0f
                val base = b * BIN
                for (i in 0 until BIN) {
                    val idx = (base + i) * 2
                    val x = (pcm[idx] + pcm[idx + 1]) * (0.5f / 32768f)
                    l1 += aL * (x - l1); l2 += aL * (l1 - l2)
                    h1 += aH * (x - h1); h2 += aH * (h1 - h2)
                    eL += abs(l2); eM += abs(h2 - l2); eH += abs(x - h2)
                    val a = abs(x)
                    if (a > pk) pk = a
                }
                if (pk > runMax) runMax = pk
                peak[b] = sqrt(min(1f, pk / runMax))
                val tot = eL + eM + eH + 1e-6f
                val c0 = ((eM * 0.5f + eH * 1.0f) / tot * 1.9f).coerceIn(0f, 1f)
                cMean += (c0 - cMean) * 0.003f
                // contraste adaptativo: reparte los colores alrededor de la media de la pista para distinguir graves/medios/agudos
                val c = (0.5f + 0.5f * kotlin.math.tanh((c0 - cMean) * 5.5f)).coerceIn(0f, 1f)
                color[b] = (c * (QCOLORS - 1)).toInt().toByte()
                val e = eL / BIN + 0.5f * (eM / BIN)
                onset[b] = max(0f, e - prevE)
                prevE = e
            }
            done = target
            w.bins = target
        }
    }

    fun overviewBitmap(w: Waveform, deck: Int, width: Int = 900, height: Int = 48): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint().apply { strokeWidth = 1f; isAntiAlias = false }
        val bins = minOf(w.bins, w.peak.size, w.color.size)
        if (bins == 0) return bmp
        val mid = height / 2f
        for (x in 0 until width) {
            val b0 = (x.toLong() * bins / width).toInt()
            val b1 = max(b0 + 1, ((x + 1).toLong() * bins / width).toInt()).coerceAtMost(bins)
            var best = 0f; var bi = b0
            for (b in b0 until b1) if (w.peak[b] > best) { best = w.peak[b]; bi = b }
            p.color = waveColor(w.color[bi.coerceAtMost(bins - 1)].toInt().coerceIn(0, QCOLORS - 1), deck)
            val h = best * mid * 0.95f
            cv.drawLine(x + 0.5f, mid - h, x + 0.5f, mid + h, p)
        }
        return bmp
    }

    // ------------------------------------------------------------------ BPM

    /**
     * BPM rápido. onsetIn[0 until n] es la envolvente de ataques (hopRate = bins/s).
     * Analiza como máximo 60 s (centrados si hay más). Devuelve (bpm, primer beat en s, relativo al inicio de onsetIn).
     */
    fun detectBpm(onsetIn: FloatArray, n: Int, hopRate: Double): Pair<Float, Double> {
        if (n < hopRate * 8) return 0f to 0.0
        val maxLen = (hopRate * 60).toInt()
        val start = if (n > maxLen + hopRate * 10) (n - maxLen) / 2 else 0
        val end = min(n, start + maxLen)
        val seg = onsetIn.copyOfRange(start, end)
        var mean = 0.0
        for (v in seg) mean += v
        mean /= seg.size
        for (i in seg.indices) seg[i] = max(0f, seg[i] - (mean * 0.8).toFloat())

        fun acf(lag: Double): Double {
            val li = lag.toInt()
            val fr = (lag - li).toFloat()
            val lim = seg.size - li - 2
            if (lim <= 0) return 0.0
            var s = 0.0
            for (i in 0 until lim) s += seg[i] * (seg[i + li] * (1f - fr) + seg[i + li + 1] * fr)
            return s / lim
        }
        fun score(bpm: Double): Double {
            val lag = 60.0 / bpm * hopRate
            return acf(lag) + 0.5 * acf(lag * 2)
        }
        fun prior(bpm: Double): Double {
            val d = ln(bpm / 125.0) / ln(2.0)
            return exp(-d * d / (2 * 0.55 * 0.55))
        }

        var bestBpm = 120.0; var bestScore = -1.0
        var b = 70.0
        while (b <= 180.0) {
            val s = score(b) * prior(b)
            if (s > bestScore) { bestScore = s; bestBpm = b }
            b += 1.0
        }
        var fine = bestBpm; var fineScore = -1.0
        var f = bestBpm - 1.2
        while (f <= bestBpm + 1.2) {
            val s = score(f)
            if (s > fineScore) { fineScore = s; fine = f }
            f += 0.1
        }
        var bpm = fine
        while (bpm < 80) bpm *= 2
        while (bpm > 180) bpm /= 2

        // fase de la rejilla sobre el mismo tramo
        val lagBins = 60.0 / bpm * hopRate
        var bestPhase = 0.0; var bestPs = -1.0
        var ph = 0.0
        while (ph < lagBins) {
            var s = 0.0
            var pos = ph
            while (pos < seg.size - 1) {
                val i = pos.toInt(); val fr = (pos - i).toFloat()
                s += seg[i] * (1f - fr) + seg[i + 1] * fr
                pos += lagBins
            }
            if (s > bestPs) { bestPs = s; bestPhase = ph }
            ph += 0.5
        }
        // pasar la fase al inicio del audio original y normalizarla a [0, beat)
        val lagSec = 60.0 / bpm
        var first = (start + bestPhase) / hopRate
        first %= lagSec
        if (first < 0) first += lagSec
        return bpm.toFloat() to first
    }

    // ------------------------------------------------------------------ REJILLA DINÁMICA

    class GridResult(val steady: Boolean, val bpm: Float, val firstSec: Double, val beatsSec: DoubleArray)

    /**
     * Seguimiento de beats por programación dinámica (Ellis 2007) sobre la envolvente de transitorios de graves.
     * Cada beat se afina a sub-bin con interpolación parabólica. Si los beats siguen una recta (tempo estable) se devuelve
     * una rejilla fija de alta precisión (regresión lineal); si no, la lista completa de beats (rejilla dinámica).
     */
    fun analyzeGrid(onsetIn: FloatArray, n: Int, hopRate: Double, bpmHint: Float): GridResult? {
        if (n < hopRate * 12 || bpmHint <= 40f) return null
        // onset local: se resta la media de ~1 s y se normaliza por desviación
        val pre = DoubleArray(n + 1)
        for (i in 0 until n) pre[i + 1] = pre[i] + onsetIn[i]
        val w = max(3, hopRate.toInt())
        val o = FloatArray(n)
        var sq = 0.0
        for (i in 0 until n) {
            val a = max(0, i - w / 2); val b = min(n, i + w / 2 + 1)
            val m = (pre[b] - pre[a]) / (b - a)
            val v = max(0.0, onsetIn[i] - m).toFloat()
            o[i] = v; sq += v.toDouble() * v
        }
        val sd = sqrt(sq / n).toFloat().coerceAtLeast(1e-9f)
        for (i in 0 until n) o[i] /= sd

        val p = 60.0 / bpmHint * hopRate
        val tMin = max(1, (p * 0.75).toInt())
        val tMax = max(tMin + 1, (p * 1.33).toInt())
        val pen = FloatArray(tMax - tMin + 1) { val r = ln((it + tMin) / p); (400.0 * r * r).toFloat() }
        val cs = FloatArray(n)
        val bp = IntArray(n)
        for (t in 0 until n) {
            var best = 0f; var bi = 0
            var j = max(0, t - tMax)
            val hi = t - tMin
            while (j <= hi) {
                val v = cs[j] - pen[t - j - tMin]
                if (v > best) { best = v; bi = j + 1 }
                j++
            }
            cs[t] = o[t] + best
            bp[t] = bi
        }
        var end = max(0, n - tMax); var bestC = -1f
        for (t in max(0, n - tMax) until n) if (cs[t] > bestC) { bestC = cs[t]; end = t }
        val idx = ArrayList<Int>()
        var t = end
        while (true) {
            idx.add(t)
            val b = bp[t]
            if (b == 0) break
            t = b - 1
        }
        idx.reverse()
        if (idx.size < 8) return null
        // afinado sub-bin sobre el onset original
        val times = DoubleArray(idx.size) {
            val i = idx[it]
            var off = 0.0
            if (i in 1 until n - 1) {
                val a = onsetIn[i - 1]; val b = onsetIn[i]; val c = onsetIn[i + 1]
                val den = a - 2 * b + c
                if (den < -1e-9f) off = (0.5 * (a - c) / den).coerceIn(-0.5, 0.5)
            }
            (i + off) / hopRate
        }
        // regresión lineal robusta: t_k = a + k * period
        fun fit(use: BooleanArray): DoubleArray {
            var cnt = 0.0; var sk = 0.0; var st = 0.0; var skk = 0.0; var skt = 0.0
            for (k in times.indices) if (use[k]) { cnt++; sk += k; st += times[k]; skk += k.toDouble() * k; skt += k * times[k] }
            val den = cnt * skk - sk * sk
            val per = if (den != 0.0) (cnt * skt - sk * st) / den else 60.0 / bpmHint
            val a = (st - per * sk) / cnt
            return doubleArrayOf(a, per)
        }
        val use = BooleanArray(times.size) { true }
        var ab = fit(use)
        for (pass in 0..1) {
            var ss = 0.0
            for (k in times.indices) { val r = times[k] - (ab[0] + ab[1] * k); ss += r * r }
            val rms = sqrt(ss / times.size)
            for (k in times.indices) use[k] = abs(times[k] - (ab[0] + ab[1] * k)) <= max(0.012, 2.5 * rms)
            ab = fit(use)
        }
        var ss = 0.0; var cn = 0
        for (k in times.indices) if (use[k]) { val r = times[k] - (ab[0] + ab[1] * k); ss += r * r; cn++ }
        val rms = sqrt(ss / max(1, cn))
        val bpmFit = 60.0 / ab[1]
        val steady = rms < 0.012 && cn >= times.size * 0.8 && abs(bpmFit - bpmHint) / bpmHint < 0.03
        var first = ab[0] % ab[1]
        if (first < 0) first += ab[1]
        return if (steady) GridResult(true, bpmFit.toFloat(), first, doubleArrayOf())
        else {
            val dur = (times.last() - times.first()) / max(1, times.size - 1)
            GridResult(false, (60.0 / dur).toFloat(), times[0], times)
        }
    }

    // ------------------------------------------------------------------ KEY

    private val MAJOR = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val MINOR = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)
    // Camelot por clase de altura (0 = C)
    private val CAM_MAJOR = intArrayOf(8, 3, 10, 5, 12, 7, 2, 9, 4, 11, 6, 1)
    private val CAM_MINOR = intArrayOf(5, 12, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10)

    fun detectKey(pcm: ShortArray, frames: Int, srcRate: Int): String {
        val dec = 4
        val sr = srcRate / dec.toDouble()
        val nMono = frames / dec
        val winN = 8192
        if (nMono < winN * 4) return "--"
        val hann = FloatArray(winN) { (0.5 - 0.5 * cos(2 * PI * it / (winN - 1))).toFloat() }
        val chroma = DoubleArray(12)
        val windows = 40
        val buf = FloatArray(winN)
        val firstNote = 36; val lastNote = 83
        val coeffs = DoubleArray(lastNote - firstNote + 1) {
            val f = 440.0 * 2.0.pow((firstNote + it - 69) / 12.0)
            2 * cos(2 * PI * f / sr)
        }
        for (w in 0 until windows) {
            val startMono = ((0.1 + 0.8 * w / windows) * (nMono - winN)).toInt()
            for (i in 0 until winN) {
                var s = 0
                val base = (startMono + i) * dec
                for (k in 0 until dec) {
                    val idx = (base + k) * 2
                    s += pcm[idx] + pcm[idx + 1]
                }
                buf[i] = s * (1f / (32768f * dec * 2)) * hann[i]
            }
            for (ni in coeffs.indices) {
                val c = coeffs[ni]
                var s1 = 0.0; var s2 = 0.0
                for (i in 0 until winN) {
                    val s0 = buf[i] + c * s1 - s2
                    s2 = s1; s1 = s0
                }
                val power = s1 * s1 + s2 * s2 - c * s1 * s2
                chroma[(firstNote + ni) % 12] += sqrt(max(0.0, power))
            }
        }
        var bestCorr = -2.0; var bestPc = 0; var bestMinor = false
        for (pc in 0 until 12) {
            val cMaj = corr(chroma, MAJOR, pc)
            val cMin = corr(chroma, MINOR, pc)
            if (cMaj > bestCorr) { bestCorr = cMaj; bestPc = pc; bestMinor = false }
            if (cMin > bestCorr) { bestCorr = cMin; bestPc = pc; bestMinor = true }
        }
        return if (bestMinor) "${CAM_MINOR[bestPc]}A" else "${CAM_MAJOR[bestPc]}B"
    }

    private fun corr(chroma: DoubleArray, prof: DoubleArray, tonic: Int): Double {
        var mx = 0.0; var my = 0.0
        for (i in 0 until 12) { mx += chroma[(i + tonic) % 12]; my += prof[i] }
        mx /= 12; my /= 12
        var sxy = 0.0; var sxx = 0.0; var syy = 0.0
        for (i in 0 until 12) {
            val dx = chroma[(i + tonic) % 12] - mx
            val dy = prof[i] - my
            sxy += dx * dy; sxx += dx * dx; syy += dy * dy
        }
        return if (sxx <= 0 || syy <= 0) 0.0 else sxy / sqrt(sxx * syy)
    }

    private val NOTE_NAMES = arrayOf("C", "Db", "D", "Eb", "E", "F", "F#", "G", "Ab", "A", "Bb", "B")

    /** Nombre musical de una tonalidad Camelot: "8A" -> "Am", "8B" -> "C". */
    fun keyName(key: String): String {
        val n = key.dropLast(1).toIntOrNull() ?: return ""
        val minor = key.endsWith("A")
        val tbl = if (minor) CAM_MINOR else CAM_MAJOR
        val pc = tbl.indexOf(n)
        if (pc < 0) return ""
        return NOTE_NAMES[pc] + if (minor) "m" else ""
    }

    /** Color de la insignia de tonalidad según el número Camelot (rueda de color). */
    fun keyColor(key: String): Int {
        val n = key.dropLast(1).toIntOrNull() ?: return 0xFF555555.toInt()
        val hue = ((n - 1) * 30f + 15f) % 360f
        return android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.75f, 1f))
    }

}
