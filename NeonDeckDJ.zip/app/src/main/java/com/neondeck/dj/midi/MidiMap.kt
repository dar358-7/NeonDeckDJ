package com.neondeck.dj.midi

import org.json.JSONArray
import org.json.JSONObject

enum class Action(val label: String, val isCc: Boolean, val perDeck: Boolean) {
    PLAY("Play / Pausa", false, true),
    CUE("Cue", false, true),
    SYNC("Sync", false, true),
    SHIFT("Shift", false, true),
    VINYL("Vinyl (scratch)", false, true),
    LOOP_IN("Loop IN", false, true),
    LOOP_OUT("Loop OUT", false, true),
    PAD1("Pad 1", false, true),
    PAD2("Pad 2", false, true),
    PAD3("Pad 3", false, true),
    PAD4("Pad 4", false, true),
    MODE_HOTCUE("Modo Hot Cue", false, true),
    MODE_ROLL("Modo Roll", false, true),
    MODE_FX("Modo FX", false, true),
    MODE_SAMPLER("Modo Sampler", false, true),
    PFL("Cue auriculares (PFL)", false, true),
    LOAD("Cargar pista", false, true),
    JOG_TOUCH("Jog: toque", false, true),
    JOG("Jog: giro", true, true),
    PITCH("Fader de tempo", true, true),
    VOLUME("Fader de volumen", true, true),
    GAIN("Gain", true, true),
    EQ_HIGH("EQ agudos", true, true),
    EQ_MID("EQ medios", true, true),
    EQ_LOW("EQ graves", true, true),
    FILTER("Filtro", true, true),
    CROSSFADER("Crossfader", true, false),
    MASTER("Master", true, false),
    BROWSE("Browse: girar", true, false),
    BROWSE_PRESS("Browse: pulsar", false, false),
    ASSISTANT("Assistant (grabar)", false, false);
}

class Binding(
    val isCc: Boolean,
    val channel: Int,   // 0..15
    val number: Int,    // nota o CC
    val action: Action,
    val deck: Int       // 0 = A, 1 = B, -1 = global
)

/** Tabla de asignaciones MIDI -> acciones. Editable por el usuario y guardada como JSON. */
class MidiMap(var name: String = "Custom") {
    val bindings = mutableListOf<Binding>()
    private val index = HashMap<Int, Binding>()

    private fun key(isCc: Boolean, ch: Int, num: Int) = ((if (isCc) 1 else 0) shl 16) or (ch shl 8) or num

    private fun rebuild() {
        index.clear()
        for (b in bindings) index[key(b.isCc, b.channel, b.number)] = b
    }

    fun find(isCc: Boolean, ch: Int, num: Int): Binding? = index[key(isCc, ch, num)]

    fun bindingFor(a: Action, deck: Int): Binding? =
        bindings.firstOrNull { it.action == a && it.deck == deck }

    fun set(b: Binding) {
        bindings.removeAll { (it.action == b.action && it.deck == b.deck) ||
            (it.isCc == b.isCc && it.channel == b.channel && it.number == b.number) }
        bindings.add(b)
        rebuild()
    }

    /** Copia los controles del Deck A al Deck B (mismo número, canal + [chOffset]) sin pisar lo ya aprendido. */
    fun mirrorAtoB(chOffset: Int = 1) {
        val src = bindings.filter { it.deck == 0 && it.action.perDeck }
        for (b in src) {
            if (bindingFor(b.action, 1) != null) continue
            val ch = (b.channel + chOffset).coerceIn(0, 15)
            if (find(b.isCc, ch, b.number) != null) continue
            bindings.add(Binding(b.isCc, ch, b.number, b.action, 1))
            index[key(b.isCc, ch, b.number)] = bindings.last()
        }
    }

    fun toJson(): String {
        val arr = JSONArray()
        for (b in bindings) arr.put(
            JSONObject().put("t", if (b.isCc) "cc" else "note").put("ch", b.channel)
                .put("n", b.number).put("a", b.action.name).put("d", b.deck)
        )
        return JSONObject().put("name", name).put("bindings", arr).toString()
    }

    companion object {
        fun fromJson(json: String): MidiMap {
            val o = JSONObject(json)
            val m = MidiMap(o.optString("name", "Custom"))
            val arr = o.getJSONArray("bindings")
            for (i in 0 until arr.length()) {
                val e = arr.getJSONObject(i)
                val act = try { Action.valueOf(e.getString("a")) } catch (_: Exception) { continue }
                m.bindings.add(Binding(e.getString("t") == "cc", e.getInt("ch"), e.getInt("n"), act, e.optInt("d", -1)))
            }
            m.rebuild()
            return m
        }

        fun describe(b: Binding?): String {
            if (b == null) return "— sin asignar —"
            val kind = if (b.isCc) "CC" else "Nota"
            return "$kind ${b.number} (0x%02X) · canal ${b.channel + 1}".format(b.number)
        }
    }
}
