package com.neondeck.dj.audio

import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

/** Forma de onda que se va rellenando mientras la pista se decodifica (1 bin = Analyzer.BIN frames). */
class Waveform(estBins: Int) {
    @Volatile var peak = FloatArray(estBins)
    @Volatile var color = ByteArray(estBins)
    @Volatile var onset = FloatArray(estBins)
    @Volatile var bins = 0
    var overview by mutableStateOf<Bitmap?>(null)

    fun ensure(n: Int) {
        if (n > peak.size) {
            val m = n + n / 4 + 64
            peak = peak.copyOf(m); color = color.copyOf(m); onset = onset.copyOf(m)
        }
    }
}

/**
 * Pista cargada. Empieza a sonar en cuanto hay unos segundos decodificados;
 * el resto (onda, BPM, tonalidad) se completa en segundo plano.
 */
class LoadedTrack(
    val uriKey: String,
    title: String,
    val srcRate: Int,
    estFrames: Int,
    deckIndexInit: Int
) {
    val id: String get() = uriKey
    @Volatile var deckIndex: Int = deckIndexInit

    var title by mutableStateOf(title)
    var artist by mutableStateOf("")
    var art by mutableStateOf<Bitmap?>(null)

    @Volatile var pcm = ShortArray(estFrames * 2 + 16384)
    @Volatile var frames = estFrames
    @Volatile var decodedFrames = 0
    @Volatile var complete = false
    @Volatile var cancelled = false

    var bpm by mutableFloatStateOf(0f)           // 0 = aún sin analizar
    @Volatile var firstBeatFrame = 0.0
    var key by mutableStateOf("--")

    val wave = Waveform(estFrames / Analyzer.BIN + 64)

    val durationSec: Float get() = frames / srcRate.toFloat()
    val availFrames: Int get() = if (complete) frames else decodedFrames
    val effBpm: Float get() = if (bpm > 0f) bpm else 120f
    val beatLenFrames: Double get() = 60.0 / effBpm * srcRate

    // ---- rejilla de beats: fija (primer beat + BPM) o dinámica (posición de cada beat, sigue variaciones de tempo)
    @Volatile var beats: DoubleArray? = null      // frames ascendentes; null = rejilla fija
    @Volatile var dynamicGrid = false

    private fun idxAt(b: DoubleArray, pos: Double): Int {
        var lo = 0; var hi = b.size - 1; var r = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (b[mid] <= pos) { r = mid; lo = mid + 1 } else hi = mid - 1
        }
        return r
    }

    /** Fase dentro del beat en [0,1) en la posición dada (frames). */
    fun phaseAt(pos: Double): Double {
        val b = beats
        val x: Double
        if (b == null || b.size < 4) {
            x = (pos - firstBeatFrame) / beatLenFrames
        } else {
            val i = idxAt(b, pos)
            x = when {
                i < 0 -> (pos - b[0]) / beatLenFrames
                i >= b.size - 1 -> (pos - b[b.size - 1]) / beatLenFrames
                else -> (pos - b[i]) / (b[i + 1] - b[i])
            }
        }
        return x - kotlin.math.floor(x)
    }

    /** Duración del beat (frames) en esa posición. */
    fun beatLenAt(pos: Double): Double {
        val b = beats
        if (b == null || b.size < 4) return beatLenFrames
        val i = idxAt(b, pos)
        return if (i in 0 until b.size - 1) b[i + 1] - b[i] else beatLenFrames
    }

    /** Beat de la rejilla más cercano (frames). */
    fun nearestBeatFrame(pos: Double): Double {
        val b = beats
        if (b == null || b.size < 4) return firstBeatFrame + Math.rint((pos - firstBeatFrame) / beatLenFrames) * beatLenFrames
        val i = idxAt(b, pos)
        return when {
            i < 0 -> b[0] + Math.rint((pos - b[0]) / beatLenFrames) * beatLenFrames
            i >= b.size - 1 -> b[b.size - 1] + Math.rint((pos - b[b.size - 1]) / beatLenFrames) * beatLenFrames
            else -> if (pos - b[i] <= b[i + 1] - pos) b[i] else b[i + 1]
        }
    }

    /** Desplaza toda la rejilla (frames). */
    fun shiftGrid(delta: Double) {
        firstBeatFrame += delta
        val b = beats
        if (b != null) beats = DoubleArray(b.size) { b[it] + delta }
    }

    /** Añade PCM estéreo intercalado decodificado. */
    fun appendPcm(chunk: ShortArray, nFrames: Int) {
        val start = decodedFrames
        val need = (start + nFrames) * 2
        var arr = pcm
        if (need > arr.size) { arr = arr.copyOf(need + srcRate * 2 * 20); pcm = arr }
        System.arraycopy(chunk, 0, arr, start * 2, nFrames * 2)
        decodedFrames = start + nFrames
        if (decodedFrames > frames) frames = decodedFrames
    }
}
