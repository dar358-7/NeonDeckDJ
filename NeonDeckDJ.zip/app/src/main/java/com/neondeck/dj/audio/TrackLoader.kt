package com.neondeck.dj.audio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import com.neondeck.dj.Prefs
import java.io.BufferedInputStream
import java.io.InputStream
import java.nio.ByteOrder
import kotlin.concurrent.thread

/**
 * Carga de pistas casi instantánea: el audio se decodifica en streaming y la pista empieza a
 * poder sonar a los ~1.5 s; onda, BPM y tonalidad se completan en segundo plano.
 * Soporta WAV directamente (PCM 8/16/24/32 bits y float) y cualquier formato que Android decodifique.
 */
object TrackLoader {

    class Token { @Volatile var cancelled = false }

    abstract class PcmSink {
        abstract fun begin(sampleRate: Int, estFrames: Int)
        /** @return false para detener la decodificación */
        abstract fun chunk(pcm: ShortArray, frames: Int): Boolean
    }

    private val main = Handler(Looper.getMainLooper())
    private const val CHUNK = 16384

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0).substringBeforeLast('.')
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Track"
    }

    // ================================================================ WAV
    private fun readFully(ins: InputStream, buf: ByteArray, len: Int): Int {
        var n = 0
        while (n < len) {
            val r = ins.read(buf, n, len - n)
            if (r < 0) break
            n += r
        }
        return n
    }

    private fun skipFully(ins: InputStream, bytes: Long) {
        var left = bytes
        val tmp = ByteArray(8192)
        while (left > 0) {
            val s = ins.skip(left)
            if (s > 0) { left -= s; continue }
            val r = ins.read(tmp, 0, minOf(left, tmp.size.toLong()).toInt())
            if (r < 0) break
            left -= r
        }
    }

    private fun le16(b: ByteArray, o: Int) = (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8)
    private fun le32(b: ByteArray, o: Int) =
        (b[o].toInt() and 0xFF) or ((b[o + 1].toInt() and 0xFF) shl 8) or
            ((b[o + 2].toInt() and 0xFF) shl 16) or ((b[o + 3].toInt() and 0xFF) shl 24)

    /** @return true si era un WAV soportado y se procesó; false para probar con MediaCodec. */
    private fun decodeWav(ctx: Context, uri: Uri, startSec: Double, sink: PcmSink): Boolean {
        val raw = ctx.contentResolver.openInputStream(uri) ?: return false
        BufferedInputStream(raw, 1 shl 16).use { ins ->
            val h = ByteArray(12)
            if (readFully(ins, h, 12) < 12) return false
            if (String(h, 0, 4) != "RIFF" || String(h, 8, 4) != "WAVE") return false
            var fmtTag = 0; var channels = 2; var rate = 44100; var bits = 16; var align = 4
            var haveFmt = false
            val ch = ByteArray(8)
            while (true) {
                if (readFully(ins, ch, 8) < 8) return false
                val id = String(ch, 0, 4)
                val size = le32(ch, 4).toLong() and 0xFFFFFFFFL
                if (id == "fmt ") {
                    val f = ByteArray(size.toInt().coerceIn(16, 64))
                    if (readFully(ins, f, f.size) < f.size) return false
                    fmtTag = le16(f, 0); channels = le16(f, 2); rate = le32(f, 4)
                    align = le16(f, 12); bits = le16(f, 14)
                    if (fmtTag == 0xFFFE && f.size >= 26) fmtTag = le16(f, 24)
                    haveFmt = true
                    val extra = size - f.size
                    if (extra > 0) skipFully(ins, extra)
                    if (size % 2L == 1L) skipFully(ins, 1)
                } else if (id == "data") {
                    if (!haveFmt || channels < 1 || align < 1) return false
                    if (!((fmtTag == 1 && bits in intArrayOf(8, 16, 24, 32)) || (fmtTag == 3 && bits == 32))) return false
                    val bps = bits / 8
                    var remaining = if (size == 0L || size == 0xFFFFFFFFL) Long.MAX_VALUE else size
                    val totalFrames = if (remaining == Long.MAX_VALUE) rate * 360 else (remaining / align).toInt()
                    sink.begin(rate, totalFrames)
                    var skipFrames = (startSec * rate).toLong().coerceAtMost(totalFrames.toLong() - rate)
                    if (skipFrames > 0 && remaining != Long.MAX_VALUE) {
                        skipFully(ins, skipFrames * align); remaining -= skipFrames * align
                    }
                    val inBuf = ByteArray(align * CHUNK)
                    val out = ShortArray(CHUNK * 2)
                    while (remaining > 0) {
                        val want = minOf(inBuf.size.toLong(), remaining).toInt()
                        val got = readFully(ins, inBuf, want)
                        val frames = got / align
                        if (frames <= 0) break
                        for (i in 0 until frames) {
                            val o = i * align
                            var l: Short; var r: Short
                            when {
                                fmtTag == 3 -> {
                                    l = f2s(java.lang.Float.intBitsToFloat(le32(inBuf, o)))
                                    r = if (channels > 1) f2s(java.lang.Float.intBitsToFloat(le32(inBuf, o + bps))) else l
                                }
                                bits == 16 -> {
                                    l = le16(inBuf, o).toShort()
                                    r = if (channels > 1) le16(inBuf, o + 2).toShort() else l
                                }
                                bits == 8 -> {
                                    l = (((inBuf[o].toInt() and 0xFF) - 128) shl 8).toShort()
                                    r = if (channels > 1) (((inBuf[o + 1].toInt() and 0xFF) - 128) shl 8).toShort() else l
                                }
                                bits == 24 -> {
                                    l = le16(inBuf, o + 1).toShort()
                                    r = if (channels > 1) le16(inBuf, o + 4).toShort() else l
                                }
                                else -> { // 32 bits entero
                                    l = le16(inBuf, o + 2).toShort()
                                    r = if (channels > 1) le16(inBuf, o + 6).toShort() else l
                                }
                            }
                            out[2 * i] = l; out[2 * i + 1] = r
                        }
                        if (!sink.chunk(out, frames)) return true
                        if (remaining != Long.MAX_VALUE) remaining -= got
                        if (got < want) break
                    }
                    return true
                } else {
                    skipFully(ins, size + (size and 1L))
                }
            }
        }
        return false
    }

    private fun f2s(f: Float): Short = (f.coerceIn(-1f, 1f) * 32767f).toInt().toShort()

    // ================================================================ MediaCodec
    private fun decodeCodec(ctx: Context, uri: Uri, startSec: Double, sink: PcmSink) {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var idx = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { idx = i; fmt = f; break }
        }
        require(idx >= 0 && fmt != null) { "El archivo no contiene audio" }
        ex.selectTrack(idx)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L
        if (startSec > 0 && durUs > (startSec + 15) * 1_000_000) {
            ex.seekTo((startSec * 1_000_000).toLong(), MediaExtractor.SEEK_TO_CLOSEST_SYNC)
        }

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()
        val info = MediaCodec.BufferInfo()
        val out = ShortArray(CHUNK * 2)
        var outFrames = 0
        var begun = false
        var inputDone = false
        var outputDone = false
        var pcmFloat = false
        var stop = false

        fun flush() {
            if (outFrames == 0) return
            if (!begun) {
                val est = if (durUs > 0) (durUs / 1_000_000.0 * rate).toInt() else rate * 360
                sink.begin(rate, est); begun = true
            }
            if (!sink.chunk(out, outFrames)) stop = true
            outFrames = 0
        }

        try {
            while (!outputDone && !stop) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(2000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val sz = ex.readSampleData(buf, 0)
                        if (sz < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 2000)
                when {
                    oi >= 0 -> {
                        if (info.size > 0) {
                            val ob = codec.getOutputBuffer(oi)!!
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.order(ByteOrder.nativeOrder())
                            if (pcmFloat) {
                                val fb = ob.asFloatBuffer()
                                val total = fb.remaining()
                                var i = 0
                                while (i + ch <= total) {
                                    val l = fb.get(i)
                                    val r = if (ch > 1) fb.get(i + 1) else l
                                    out[2 * outFrames] = f2s(l); out[2 * outFrames + 1] = f2s(r)
                                    if (++outFrames == CHUNK) flush()
                                    i += ch
                                }
                            } else {
                                val sb = ob.asShortBuffer()
                                val total = sb.remaining()
                                var i = 0
                                while (i + ch <= total) {
                                    val l = sb.get(i)
                                    val r = if (ch > 1) sb.get(i + 1) else l
                                    out[2 * outFrames] = l; out[2 * outFrames + 1] = r
                                    if (++outFrames == CHUNK) flush()
                                    i += ch
                                }
                            }
                        }
                        codec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                    }
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = codec.outputFormat
                        rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        pcmFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    }
                }
            }
            if (!stop) flush()
        } finally {
            try { codec.stop() } catch (_: Exception) { }
            codec.release()
            ex.release()
        }
    }

    fun decodeStream(ctx: Context, uri: Uri, startSec: Double, sink: PcmSink) {
        var done = false
        try { done = decodeWav(ctx, uri, startSec, sink) } catch (_: Exception) { }
        if (!done) decodeCodec(ctx, uri, startSec, sink)
    }

    // ================================================================ carga para un deck
    private class Meta {
        @Volatile var artist = ""
        @Volatile var title: String? = null
        @Volatile var art: Bitmap? = null
        @Volatile var done = false
        var target: LoadedTrack? = null
        fun apply(t: LoadedTrack) {
            title?.let { t.title = it }
            t.artist = artist
            art?.let { t.art = it }
        }
    }

    private fun readMeta(ctx: Context, uri: Uri, meta: Meta) {
        try {
            val mmr = MediaMetadataRetriever()
            mmr.setDataSource(ctx, uri)
            meta.title = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }
            meta.artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
            mmr.embeddedPicture?.let { bytes ->
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                meta.art = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            }
            mmr.release()
        } catch (_: Exception) { }
        synchronized(meta) { meta.done = true; meta.target?.let { meta.apply(it) } }
    }

    /**
     * Bloquea el hilo actual hasta terminar de decodificar (llamar desde Dispatchers.Default).
     * [onReady] se invoca en el hilo principal en cuanto la pista puede sonar.
     */
    fun load(
        ctx: Context, uri: Uri, deckIndex: Int, prefs: Prefs, token: Token,
        onReady: (LoadedTrack) -> Unit, onError: (Throwable) -> Unit
    ) {
        val key = uri.toString()
        val meta = Meta()
        thread(name = "dj-meta") { readMeta(ctx, uri, meta) }
        val cached = prefs.getAnalysis(key)
        var track: LoadedTrack? = null
        var builder: Analyzer.WaveBuilder? = null
        var ready = false
        var earlyDone = cached != null

        val sink = object : PcmSink() {
            override fun begin(sampleRate: Int, estFrames: Int) {
                val t = LoadedTrack(key, displayName(ctx, uri), sampleRate, estFrames, deckIndex)
                if (cached != null) {
                    t.bpm = cached.bpm; t.firstBeatFrame = cached.firstBeatSec * sampleRate
                    if (cached.key != "--") t.key = cached.key
                }
                synchronized(meta) { meta.target = t; if (meta.done) meta.apply(t) }
                builder = Analyzer.WaveBuilder(t.wave, sampleRate)
                track = t
            }

            override fun chunk(pcm: ShortArray, frames: Int): Boolean {
                val t = track ?: return false
                if (token.cancelled || t.cancelled) return false
                t.appendPcm(pcm, frames)
                builder?.feed(t.pcm, t.decodedFrames)
                if (!ready && t.decodedFrames >= t.srcRate * 3 / 2) {
                    ready = true
                    main.post { onReady(t) }
                }
                if (!earlyDone && t.decodedFrames >= t.srcRate * 30) {
                    earlyDone = true
                    val hop = t.srcRate / Analyzer.BIN.toDouble()
                    val (bpm, first) = Analyzer.detectBpm(t.wave.onset, t.wave.bins, hop)
                    if (bpm > 0f) { t.firstBeatFrame = first * t.srcRate; t.bpm = bpm }
                }
                return true
            }
        }

        try {
            decodeStream(ctx, uri, 0.0, sink)
            val t = track
            if (t == null) { onError(IllegalStateException("No se pudo leer el audio")); return }
            if (token.cancelled || t.cancelled) return
            t.frames = t.decodedFrames
            t.complete = true
            builder?.feed(t.pcm, t.decodedFrames)
            if (!ready) { ready = true; main.post { onReady(t) } }
            val hop = t.srcRate / Analyzer.BIN.toDouble()
            if (cached == null) {
                val (bpm, first) = Analyzer.detectBpm(t.wave.onset, t.wave.bins, hop)
                if (bpm > 0f) { t.firstBeatFrame = first * t.srcRate; t.bpm = bpm }
            }
            // rejilla fina: seguimiento de beats sobre toda la pista (una rejilla fija "S" ya guardada/editada no se toca)
            var gridFlag = "S"
            if ((cached == null || cached.grid != "S") && t.bpm > 0f) {
                val g = try { Analyzer.analyzeGrid(t.wave.onset, t.wave.bins, hop, t.bpm) } catch (_: Throwable) { null }
                if (g != null) {
                    if (g.steady) {
                        t.beats = null; t.dynamicGrid = false
                        t.bpm = Math.round(g.bpm * 100f) / 100f
                        t.firstBeatFrame = g.firstSec * t.srcRate
                    } else {
                        t.beats = DoubleArray(g.beatsSec.size) { g.beatsSec[it] * t.srcRate }
                        t.dynamicGrid = true
                        t.bpm = Math.round(g.bpm * 100f) / 100f
                        t.firstBeatFrame = g.beatsSec[0] * t.srcRate
                        gridFlag = "D"
                    }
                }
            } else if (cached != null && cached.grid == "S") gridFlag = "S"
            if (t.key == "--") t.key = try { Analyzer.detectKey(t.pcm, t.frames, t.srcRate) } catch (_: Exception) { "--" }
            t.wave.overview = Analyzer.overviewBitmap(t.wave, t.deckIndex)
            if (t.bpm > 0f) prefs.putAnalysis(key, t.bpm, t.firstBeatFrame / t.srcRate, t.key, gridFlag)
            if (t.key != "--") prefs.setKey(key, t.key)
        } catch (e: Throwable) {
            if (!ready) onError(e)
        }
    }

    // ================================================================ análisis rápido (librería)
    class Quick(val bpm: Float?, val key: String?)

    /** BPM + tonalidad sin cargar la pista: decodifica ~40 s y analiza. */
    fun quickAnalyze(ctx: Context, uri: Uri, prefs: Prefs): Quick {
        val id = uri.toString()
        var bpm: Float? = prefs.bpmOf(id) ?: prefs.getAnalysis(id)?.bpm?.takeIf { it > 40f }
        var key: String? = prefs.knownKey(id)
        if (bpm != null && key != null) return Quick(bpm, key)
        fun run(start: Double): Pair<Float, String>? {
            var rate = 0
            var buf = ShortArray(0)
            var filled = 0
            var maxFrames = 0
            val sink = object : PcmSink() {
                override fun begin(sampleRate: Int, estFrames: Int) {
                    rate = sampleRate; maxFrames = sampleRate * 40
                    buf = ShortArray(maxFrames * 2)
                }
                override fun chunk(pcm: ShortArray, frames: Int): Boolean {
                    val n = minOf(frames, maxFrames - filled)
                    System.arraycopy(pcm, 0, buf, filled * 2, n * 2)
                    filled += n
                    return filled < maxFrames
                }
            }
            decodeStream(ctx, uri, start, sink)
            if (rate == 0 || filled < rate * 12) return null
            val w = Waveform(filled / Analyzer.BIN + 8)
            val wb = Analyzer.WaveBuilder(w, rate)
            wb.feed(buf, filled)
            val det = Analyzer.detectBpm(w.onset, w.bins, rate / Analyzer.BIN.toDouble())
            val k = try { Analyzer.detectKey(buf, filled, rate) } catch (_: Exception) { "--" }
            return Pair(det.first, k)
        }
        try {
            val r = run(20.0) ?: run(0.0)
            if (r != null) {
                if (bpm == null && r.first > 0f) { bpm = r.first; prefs.setBpm(id, r.first) }
                if (key == null && r.second != "--") { key = r.second; prefs.setKey(id, r.second) }
            }
        } catch (_: Throwable) { }
        return Quick(bpm, key)
    }

    fun decodeMono(ctx: Context, uri: Uri, outRate: Int, maxSeconds: Int = 20): FloatArray {
        var rate = 0
        var buf = ShortArray(0)
        var filled = 0
        var maxF = 0
        val sink = object : PcmSink() {
            override fun begin(sampleRate: Int, estFrames: Int) {
                rate = sampleRate; maxF = sampleRate * maxSeconds
                buf = ShortArray(maxF * 2)
            }
            override fun chunk(pcm: ShortArray, frames: Int): Boolean {
                val n = minOf(frames, maxF - filled)
                System.arraycopy(pcm, 0, buf, filled * 2, n * 2)
                filled += n
                return filled < maxF
            }
        }
        decodeStream(ctx, uri, 0.0, sink)
        require(rate > 0 && filled > 0) { "Audio vacío" }
        val ratio = rate.toDouble() / outRate
        val n = (filled / ratio).toInt()
        val o = FloatArray(n)
        for (i in 0 until n) {
            val p = i * ratio
            val i0 = p.toInt()
            if (i0 + 1 >= filled) break
            val fr = (p - i0).toFloat()
            val a = (buf[i0 * 2] + buf[i0 * 2 + 1]) * 0.5f
            val b = (buf[(i0 + 1) * 2] + buf[(i0 + 1) * 2 + 1]) * 0.5f
            o[i] = (a + (b - a) * fr) / 32768f
        }
        return o
    }
}
