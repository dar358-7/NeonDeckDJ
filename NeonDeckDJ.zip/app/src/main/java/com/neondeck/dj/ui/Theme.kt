package com.neondeck.dj.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Paleta NEON by DARVI'S: negro mate + carbón, acentos cian (deck A), naranja (deck B) y violeta eléctrico. */
object Neon {
    /** Modo día: más brillo y contraste para exteriores / pantallas con luz directa. */
    var day by androidx.compose.runtime.mutableStateOf(false)

    val Bg get() = if (day) Color(0xFF2C303C) else Color(0xFF121212)
    val Panel get() = if (day) Color(0xFF3B4050) else Color(0xFF1A1A1F)
    val Panel2 get() = if (day) Color(0xFF474D60) else Color(0xFF222228)
    val Carbon get() = if (day) Color(0xFF353A49) else Color(0xFF16161A)
    val Edge get() = if (day) Color(0xFF6A7188) else Color(0xFF2C2C35)
    val Button get() = if (day) Color(0xFF424859) else Color(0xFF1C1C21)
    val DeckA = Color(0xFF00F0FF)
    val DeckB = Color(0xFFFF6B00)
    val DeckABlue = Color(0xFF2979FF)   // aro del plato A
    val Violet = Color(0xFF8A2BE2)
    val PadFill = Color(0xFF8A2BE2)
    val PadFillDim = Color(0xFF1B1226)
    val PadBorder = Color(0xFF9D4EDD)
    val Gray get() = if (day) Color(0xFFD5D8E3) else Color(0xFF9A9AA6)
    val GrayDark get() = if (day) Color(0xFF7C839A) else Color(0xFF3A3A44)
    val Green = Color(0xFF39FF88)
    val Yellow = Color(0xFFFACC15)
    val Red = Color(0xFFFF3B3B)
    val Text = Color(0xFFF2F2F7)

    fun deck(i: Int) = if (i == 0) DeckA else DeckB
}

/** Texto legible sobre un color neón (oscuro sobre cian/verde, blanco sobre violeta/naranja oscuro). */
fun onNeon(c: Color): Color = if (c.luminance() > 0.38f) Color(0xFF07070A) else Color.White

/** Resplandor neón alrededor de un componente (capas translúcidas). */
fun Modifier.neonGlow(
    color: Color, on: Boolean, radius: Dp = 14.dp, corner: Dp = 14.dp, strength: Float = 1f
): Modifier = if (!on) this else this.drawBehind {
    val r = radius.toPx()
    val c = corner.toPx()
    for (i in 4 downTo 1) {
        val e = r * i / 4f
        drawRoundRect(
            color.copy(alpha = (0.07f * (5 - i) * strength).coerceAtMost(0.5f)),
            Offset(-e, -e), Size(size.width + 2 * e, size.height + 2 * e), CornerRadius(c + e)
        )
    }
}

@Composable
fun NeonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon.DeckA,
            secondary = Neon.DeckB,
            tertiary = Neon.Violet,
            background = Neon.Bg,
            surface = Neon.Panel,
            onSurface = Neon.Text,
            onBackground = Neon.Text
        ),
        content = content
    )
}
