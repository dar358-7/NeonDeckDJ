package com.neondeck.dj.midi

import android.content.Context
import android.media.midi.MidiDevice
import android.media.midi.MidiDeviceInfo
import android.media.midi.MidiInputPort
import android.media.midi.MidiManager
import android.media.midi.MidiOutputPort
import android.media.midi.MidiReceiver
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class MidiDeviceEntry(val info: MidiDeviceInfo, val name: String, val canReceive: Boolean, val canSend: Boolean)

/**
 * Conexión MIDI USB (clase estándar) mediante android.media.midi.
 * Recibe mensajes del controlador y puede enviar LEDs de vuelta.
 */
class MidiHost(
    private val ctx: Context,
    private val onMessage: (status: Int, d1: Int, d2: Int) -> Unit
) {
    private val manager: MidiManager? = ctx.getSystemService(Context.MIDI_SERVICE) as? MidiManager
    private val handler = Handler(Looper.getMainLooper())

    val available: Boolean get() = manager != null
    val devices = mutableStateListOf<MidiDeviceEntry>()
    var connectedName by mutableStateOf<String?>(null)
    var status by mutableStateOf("Sin controlador")

    private var device: MidiDevice? = null
    private var outPort: MidiOutputPort? = null
    private var inPort: MidiInputPort? = null
    private var connectedId = -1
    private var userDisconnected = false

    private val callback = object : MidiManager.DeviceCallback() {
        override fun onDeviceAdded(info: MidiDeviceInfo) { refresh(); autoConnect() }
        override fun onDeviceRemoved(info: MidiDeviceInfo) {
            if (info.id == connectedId) closeDevice()
            refresh()
        }
    }

    fun start() {
        val m = manager ?: run { status = "Este equipo no soporta MIDI"; return }
        m.registerDeviceCallback(callback, handler)
        refresh()
        autoConnect()
    }

    fun stop() {
        manager?.unregisterDeviceCallback(callback)
        closeDevice()
    }

    private fun nameOf(info: MidiDeviceInfo): String {
        val p = info.properties
        val n = p.getString(MidiDeviceInfo.PROPERTY_NAME)
            ?: p.getString(MidiDeviceInfo.PROPERTY_PRODUCT) ?: "MIDI #${info.id}"
        return n
    }

    fun refresh() {
        val m = manager ?: return
        devices.clear()
        for (info in m.devices) {
            // En la API, "outputPortCount" = puertos por los que el dispositivo ENVÍA datos a la app
            devices.add(MidiDeviceEntry(info, nameOf(info), info.outputPortCount > 0, info.inputPortCount > 0))
        }
    }

    /** Conecta automáticamente: primero Hercules/Inpulse, si no, el primer dispositivo con salida. */
    fun autoConnect() {
        if (device != null || userDisconnected) return
        val pick = devices.firstOrNull {
            it.canReceive && (it.name.contains("inpulse", true) || it.name.contains("hercules", true))
        } ?: devices.firstOrNull { it.canReceive }
        pick?.let { connect(it) }
    }

    fun connect(entry: MidiDeviceEntry) {
        val m = manager ?: return
        closeDevice()
        userDisconnected = false
        status = "Conectando a ${entry.name}…"
        m.openDevice(entry.info, { dev ->
            if (dev == null) {
                status = "No se pudo abrir ${entry.name}"
                return@openDevice
            }
            device = dev
            connectedId = entry.info.id
            if (entry.info.outputPortCount > 0) {
                val op = dev.openOutputPort(0)
                if (op != null) { outPort = op; op.connect(receiver) }
            }
            if (entry.info.inputPortCount > 0) inPort = dev.openInputPort(0)
            connectedName = entry.name
            status = "Conectado: ${entry.name}"
            send(0xB0, 0x7F, 0x7F)      // "request status": el Inpulse envía la posición actual de faders y knobs
        }, handler)
    }

    fun disconnectByUser() { userDisconnected = true; closeDevice() }

    private fun closeDevice() {
        try { outPort?.disconnect(receiver) } catch (_: Exception) { }
        try { outPort?.close() } catch (_: Exception) { }
        try { inPort?.close() } catch (_: Exception) { }
        try { device?.close() } catch (_: Exception) { }
        outPort = null; inPort = null; device = null; connectedId = -1
        connectedName = null
        status = "Sin controlador"
    }

    /** Envía una nota/CC al controlador (LEDs). */
    fun send(status: Int, d1: Int, d2: Int) {
        val p = inPort ?: return
        try { p.send(byteArrayOf(status.toByte(), d1.toByte(), d2.toByte()), 0, 3) } catch (_: Exception) { }
    }

    // ---------------------------------------------------------------- parser
    private var running = 0
    private val data = IntArray(2)
    private var dataCount = 0
    private var needed = 0
    private var inSysex = false

    private val receiver = object : MidiReceiver() {
        override fun onSend(msg: ByteArray, offset: Int, count: Int, timestamp: Long) {
            for (i in offset until offset + count) {
                val b = msg[i].toInt() and 0xFF
                when {
                    b >= 0xF8 -> { /* tiempo real: ignorar */ }
                    b == 0xF0 -> { inSysex = true }
                    b == 0xF7 -> { inSysex = false }
                    inSysex -> { }
                    b >= 0x80 -> {
                        running = b
                        dataCount = 0
                        needed = when (b and 0xF0) { 0xC0, 0xD0 -> 1; else -> 2 }
                        if (b >= 0xF0) running = 0
                    }
                    running != 0 -> {
                        data[dataCount++] = b
                        if (dataCount == needed) {
                            onMessage(running, data[0], if (needed > 1) data[1] else 0)
                            dataCount = 0
                        }
                    }
                }
            }
        }
    }
}
