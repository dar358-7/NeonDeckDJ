package com.neondeck.dj.midi

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.neondeck.dj.Prefs
import com.neondeck.dj.audio.AudioEngine
import com.neondeck.dj.audio.Deck
import com.neondeck.dj.audio.PadMode
import com.neondeck.dj.audio.Pads

interface UiHooks {
    fun requestLoad(deck: Int)
    fun browseMove(delta: Int)
    fun browsePress()
    fun loadSelected(deck: Int)
}

/** Traduce mensajes MIDI a acciones del DJ, soporta aprendizaje (MIDI learn) y LEDs de retorno. */
class MidiRouter(
    private val engine: AudioEngine,
    private val prefs: Prefs,
    private val hooks: UiHooks
) {
    var map: MidiMap = MidiMap("vacío")
    var host: MidiHost? = null

    // ---- monitor
    var monitorEnabled by mutableStateOf(false)
    val log = mutableStateListOf<String>()
    private var lastLogKey = -1
    private var lastLogTime = 0L

    // ---- aprendizaje
    var learning by mutableStateOf<Pair<Action, Int>?>(null)
    private var wizardQueue: List<Pair<Action, Int>> = emptyList()
    var wizardIndex by mutableIntStateOf(-1)
    val wizardActive: Boolean get() = wizardIndex >= 0
    val wizardTotal: Int get() = wizardQueue.size
    private val learnedKeys = HashSet<Int>()

    // ---- caché LEDs
    private val ledCache = HashMap<Int, Int>()

    fun loadMap(defaultJson: String) {
        // v1.4: mapa oficial; descarta mapas guardados por versiones anteriores (valores estimados)
        if (prefs.midiMapVer < 2) { prefs.midiMapJson = null; prefs.midiMapVer = 2 }
        map = try {
            MidiMap.fromJson(prefs.midiMapJson ?: defaultJson)
        } catch (_: Exception) {
            MidiMap.fromJson(defaultJson)
        }
    }

    fun resetMap(defaultJson: String) {
        map = MidiMap.fromJson(defaultJson)
        prefs.midiMapJson = null
        ledCache.clear()
    }

    private fun save() { prefs.midiMapJson = map.toJson() }

    // ---------------------------------------------------------------- aprendizaje
    fun startLearn(a: Action, deck: Int) {
        wizardIndex = -1
        learnedKeys.clear()
        learning = a to deck
    }

    /** Copia el mapa del Deck A al Deck B (canal + 1) para los controles aún sin asignar. */
    fun mirrorDecks() { map.mirrorAtoB(1); save(); ledCache.clear() }

    fun cancelLearn() { learning = null; wizardIndex = -1 }

    private var quickWizard = false

    /** quick = solo aprende el Deck A + globales y copia el Deck B automáticamente (canal + 1). */
    fun startWizard(quick: Boolean = false) {
        quickWizard = quick
        wizardQueue = Action.values().flatMap { a ->
            if (a.perDeck) (if (quick) listOf(a to 0) else listOf(a to 0, a to 1)) else listOf(a to -1)
        }
        learnedKeys.clear()
        wizardIndex = 0
        learning = wizardQueue[0]
    }

    fun wizardSkip() {
        if (!wizardActive) return
        advanceWizard()
    }

    private fun advanceWizard() {
        wizardIndex++
        if (wizardIndex >= wizardQueue.size) {
            wizardIndex = -1; learning = null
            if (quickWizard) { map.mirrorAtoB(1); save(); ledCache.clear() }
        }
        else learning = wizardQueue[wizardIndex]
    }

    private fun key(isCc: Boolean, ch: Int, n: Int) = ((if (isCc) 1 else 0) shl 16) or (ch shl 8) or n

    private fun learnMessage(isCc: Boolean, ch: Int, num: Int, noteOn: Boolean) {
        val target = learning ?: return
        if (!isCc && !noteOn) return
        val k = key(isCc, ch, num)
        if (k in learnedKeys) return                 // el mismo control sigue moviéndose
        if (target.first.isCc != isCc) return        // se esperaba otro tipo de mensaje
        map.set(Binding(isCc, ch, num, target.first, target.second))
        learnedKeys.add(k)
        save()
        ledCache.clear()
        if (wizardActive) advanceWizard() else learning = null
    }

    // ---------------------------------------------------------------- entrada
    fun onMessage(status: Int, d1: Int, d2: Int) {
        val type = status and 0xF0
        val ch = status and 0x0F
        val noteOn = type == 0x90 && d2 > 0
        val noteOff = type == 0x80 || (type == 0x90 && d2 == 0)
        val isCc = type == 0xB0
        if (!noteOn && !noteOff && !isCc) return

        if (monitorEnabled) logMessage(type, ch, d1, d2)
        if (learning != null) { learnMessage(isCc, ch, d1, noteOn); return }

        val b = map.find(isCc, ch, d1) ?: return
        dispatch(b, noteOn, d2)
    }

    private fun logMessage(type: Int, ch: Int, d1: Int, d2: Int) {
        val k = (type shl 16) or (ch shl 8) or d1
        val now = System.currentTimeMillis()
        if (k == lastLogKey && now - lastLogTime < 120) return
        lastLogKey = k; lastLogTime = now
        val name = when (type) { 0x90 -> "NOTE ON "; 0x80 -> "NOTE OFF"; else -> "CC      " }
        log.add(0, "%s ch%d  #%d (0x%02X)  val %d".format(name, ch + 1, d1, d1, d2))
        while (log.size > 14) log.removeAt(log.size - 1)
    }

    /** Encoders relativos del Inpulse: 01..3F = horario (más rápido hacia 3F), 7F..40 = antihorario. */
    private fun jogDelta(v: Int): Int = if (v < 0x40) v else v - 0x80

    private fun knob(v: Int): Float = if (v <= 64) v / 64f else 1f + (v - 64) / 63f * 0.5f

    /** El Inpulse envía notas distintas por modo de pad (00-03 hot cue, 10-13 roll, 20-23 FX, 30-33 sampler). */
    private fun pad(d: Deck, b: Binding, p: Int, down: Boolean) {
        if (down && b.channel >= 6 && b.number < 0x40) {
            d.padMode = when ((b.number shr 4) and 3) {
                0 -> PadMode.HOTCUE; 1 -> PadMode.ROLL; 2 -> PadMode.FX; else -> PadMode.SAMPLER
            }
        }
        Pads.press(engine, d, p, down)
    }

    private fun dispatch(b: Binding, down: Boolean, v: Int) {
        val d: Deck? = if (b.deck >= 0) engine.deck(b.deck) else null
        when (b.action) {
            Action.SHIFT -> d?.shiftHeld = down
            Action.PLAY -> if (down && d != null) {
                if (d.shiftHeld) { d.seekFrames(d.cuePoint); d.playing = true } else d.playPause()
            }
            Action.CUE -> if (d != null) {
                if (down) { if (d.shiftHeld) d.goToStart() else d.cueDown() } else d.cueUp()
            }
            Action.SYNC -> if (down && d != null) {
                if (d.syncOn || d.shiftHeld) d.syncOn = false else d.syncTo(engine.other(d))
            }
            Action.VINYL -> if (down && d != null) d.vinyl = !d.vinyl
            Action.LOOP_IN -> if (down && d != null) { if (d.shiftHeld) d.loopHalve() else d.setBeatLoop(d.loopBeats) }
            Action.LOOP_OUT -> if (down && d != null) { if (d.shiftHeld) d.loopDouble() else d.loopActive = false }
            Action.PAD1 -> if (d != null) pad(d, b, 0, down)
            Action.PAD2 -> if (d != null) pad(d, b, 1, down)
            Action.PAD3 -> if (d != null) pad(d, b, 2, down)
            Action.PAD4 -> if (d != null) pad(d, b, 3, down)
            Action.MODE_HOTCUE -> if (down && d != null) d.padMode = PadMode.HOTCUE
            Action.MODE_ROLL -> if (down && d != null) d.padMode = PadMode.ROLL
            Action.MODE_FX -> if (down && d != null) d.padMode = PadMode.FX
            Action.MODE_SAMPLER -> if (down && d != null) d.padMode = PadMode.SAMPLER
            Action.PFL -> if (down && d != null) d.pfl = !d.pfl
            Action.LOAD -> if (down) hooks.loadSelected(b.deck)
            Action.JOG_TOUCH -> if (d != null) { if (down) d.touchStart() else d.touchEnd() }
            Action.JOG -> if (d != null) {
                val ticks = jogDelta(v)
                if (d.shiftHeld) d.seekSeconds(ticks * 0.35)
                else d.scratchSeconds(ticks * prefs.jogSecPerTick.toDouble())
            }
            Action.PITCH -> if (d != null) {
                var x = v / 127f * 2f - 1f
                if (prefs.pitchInvert) x = -x
                d.userSetPitch(x)
            }
            Action.VOLUME -> d?.volume = v / 127f
            Action.GAIN -> d?.gain = v / 127f * 2f
            Action.EQ_HIGH -> d?.eqHigh = knob(v)
            Action.EQ_MID -> d?.eqMid = knob(v)
            Action.EQ_LOW -> d?.eqLow = knob(v)
            Action.FILTER -> if (d != null) {
                val x = ((v - 64) / 63f).coerceIn(-1f, 1f)
                d.filter = if (kotlin.math.abs(x) < 0.04f) 0f else x
            }
            Action.CROSSFADER -> engine.crossfader = v / 127f
            Action.MASTER -> engine.masterGain = v / 127f
            Action.BROWSE -> hooks.browseMove(jogDelta(v).coerceIn(-3, 3))
            Action.BROWSE_PRESS -> if (down) hooks.browsePress()
            Action.ASSISTANT -> if (down) engine.toggleRecording()
        }
    }

    // ---------------------------------------------------------------- LEDs
    private fun led(a: Action, deck: Int, on: Boolean, modeNibble: Int = -1) {
        val h = host ?: return
        for (b in map.bindings) {
            if (b.action != a || b.deck != deck || b.isCc) continue
            if ((b.number and 0x08) != 0 && modeNibble >= 0) continue            // notas de pad + SHIFT: sin LED propio
            if (modeNibble >= 0 && ((b.number shr 4) and 3) != modeNibble) continue
            val k = key(false, b.channel, b.number)
            val vel = if (on) 127 else 0
            if (ledCache[k] == vel) continue
            ledCache[k] = vel
            h.send(0x90 or b.channel, b.number, vel)
        }
    }

    /** Se llama ~15 veces por segundo para reflejar el estado en los LEDs del controlador. */
    fun updateLeds() {
        if (host?.connectedName == null) return
        for (i in 0..1) {
            val d = engine.deck(i)
            led(Action.PLAY, i, d.playing)
            led(Action.CUE, i, !d.playing && d.track != null)
            led(Action.SYNC, i, d.syncOn)
            led(Action.VINYL, i, d.vinyl)
            led(Action.LOOP_IN, i, d.loopActive)
            led(Action.PFL, i, d.pfl)
            led(Action.MODE_HOTCUE, i, d.padMode == PadMode.HOTCUE)
            led(Action.MODE_ROLL, i, d.padMode == PadMode.ROLL)
            led(Action.MODE_FX, i, d.padMode == PadMode.FX)
            led(Action.MODE_SAMPLER, i, d.padMode == PadMode.SAMPLER)
            val pads = arrayOf(Action.PAD1, Action.PAD2, Action.PAD3, Action.PAD4)
            for (p in 0..3) {
                val slot = d.padPage * 4 + p
                val on = when (d.padMode) {
                    PadMode.HOTCUE -> d.hotCues[slot] >= 0
                    PadMode.ROLL -> d.loopActive && d.loopBeats == Pads.ROLL_BEATS[p]
                    PadMode.FX -> d.fxType == p + 1
                    PadMode.SAMPLER -> engine.sampler.isPlaying(slot)
                }
                val mn = when (d.padMode) { PadMode.HOTCUE -> 0; PadMode.ROLL -> 1; PadMode.FX -> 2; PadMode.SAMPLER -> 3 }
                for (m in 0..3) led(pads[p], i, on && m == mn, m)
            }
        }
        led(Action.ASSISTANT, -1, engine.recording)
    }
}
