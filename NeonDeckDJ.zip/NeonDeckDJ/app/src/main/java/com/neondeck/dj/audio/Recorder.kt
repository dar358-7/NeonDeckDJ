package com.neondeck.dj.audio

import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.LinkedBlockingQueue

/** Grabador de la mezcla master a WAV 16 bit estéreo. */
class Recorder(private val sr: Int, private val dir: File) {
    @Volatile var recording = false
        private set
    @Volatile var file: File? = null
        private set
    @Volatile var seconds = 0f
        private set

    private val queue = LinkedBlockingQueue<ShortArray>(512)
    private val endMarker = ShortArray(0)
    private var thread: Thread? = null
    private var framesWritten = 0L

    fun start(): File {
        dir.mkdirs()
        val f = File(dir, "NeonDeck_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".wav")
        file = f
        framesWritten = 0
        seconds = 0f
        queue.clear()
        val t = Thread({
            val raf = RandomAccessFile(f, "rw")
            raf.setLength(0)
            raf.write(ByteArray(44))
            try {
                while (true) {
                    val chunk = queue.take()
                    if (chunk.isEmpty()) break
                    val bb = ByteBuffer.allocate(chunk.size * 2).order(ByteOrder.LITTLE_ENDIAN)
                    bb.asShortBuffer().put(chunk)
                    raf.write(bb.array())
                    framesWritten += chunk.size / 2
                    seconds = framesWritten / sr.toFloat()
                }
            } catch (_: InterruptedException) {
            }
            val dataLen = (framesWritten * 4).toInt()
            val h = ByteBuffer.allocate(44).order(ByteOrder.LITTLE_ENDIAN)
            h.put("RIFF".toByteArray()); h.putInt(36 + dataLen); h.put("WAVE".toByteArray())
            h.put("fmt ".toByteArray()); h.putInt(16); h.putShort(1); h.putShort(2)
            h.putInt(sr); h.putInt(sr * 4); h.putShort(4); h.putShort(16)
            h.put("data".toByteArray()); h.putInt(dataLen)
            raf.seek(0); raf.write(h.array()); raf.close()
        }, "dj-recorder")
        thread = t
        recording = true
        t.start()
        return f
    }

    fun stop(): File? {
        if (!recording) return file
        recording = false
        queue.put(endMarker)
        thread?.join(3000)
        thread = null
        return file
    }

    /** Llamado desde el hilo de audio. */
    fun feed(l: FloatArray, r: FloatArray, n: Int) {
        if (!recording) return
        val s = ShortArray(n * 2)
        for (i in 0 until n) {
            s[2 * i] = (l[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
            s[2 * i + 1] = (r[i].coerceIn(-1f, 1f) * 32767f).toInt().toShort()
        }
        queue.offer(s)
    }
}
