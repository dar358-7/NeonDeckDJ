package com.neondeck.dj.audio

import android.graphics.Bitmap

/** Datos de forma de onda precalculados (1 bin = Analyzer.BIN frames). */
class Waveform(
    val peak: FloatArray,      // 0..1
    val color: ByteArray,      // índice de color 0 until Analyzer.QCOLORS
    val overview: Bitmap?      // miniatura para la barra superior
)

/** Pista decodificada + análisis. pcm = estéreo intercalado 16 bit. */
class LoadedTrack(
    val title: String,
    val artist: String,
    val durationSec: Float,
    val pcm: ShortArray,
    val srcRate: Int,
    val frames: Int,
    val bpm: Float,
    val firstBeatFrame: Double,
    val key: String,
    val wave: Waveform,
    val art: Bitmap?
) {
    val beatLenFrames: Double get() = 60.0 / bpm * srcRate
}
