package com.neondeck.dj.audio

import androidx.compose.runtime.mutableStateListOf
import java.util.Random
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.min
import kotlin.math.sin

/** Sonidos de sampler generados proceduralmente (no requieren archivos). */
object SampleSynth {
    private fun fade(o: FloatArray, sr: Int, secs: Double = 0.03) {
        val f = (sr * secs).toInt().coerceAtMost(o.size)
        for (i in 0 until f) o[o.size - 1 - i] *= i / f.toFloat()
    }

    fun siren(sr: Int): FloatArray {
        val n = (sr * 2.4).toInt(); val o = FloatArray(n); var ph = 0.0
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            ph += 2 * PI * (700 + 450 * sin(2 * PI * 1.2 * t)) / sr
            o[i] = (sin(ph) * 0.55 + sin(ph * 2) * 0.15).toFloat() * min(1.0, t * 40).toFloat()
        }
        fade(o, sr, 0.15); return o
    }

    fun airHorn(sr: Int): FloatArray {
        val n = (sr * 1.6).toInt(); val o = FloatArray(n)
        val fs = doubleArrayOf(415.0, 523.0, 622.0)
        for (i in 0 until n) {
            val t = i / sr.toDouble(); var s = 0.0
            for (f in fs) for (h in 1..5) s += sin(2 * PI * f * h * t) / h
            val env = min(1.0, t * 60) * (if (t > 1.3) (1.6 - t) / 0.3 else 1.0)
            o[i] = (s * 0.18 * env).toFloat()
        }
        return o
    }

    fun kick(sr: Int): FloatArray {
        val n = (sr * 0.55).toInt(); val o = FloatArray(n); var ph = 0.0
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            ph += 2 * PI * (45 + 130 * exp(-t * 28)) / sr
            o[i] = (sin(ph) * exp(-t * 6.5)).toFloat() * 0.95f
        }
        return o
    }

    fun clap(sr: Int): FloatArray {
        val n = (sr * 0.4).toInt(); val o = FloatArray(n); val rnd = Random(7)
        var prev = 0f
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            var env = exp(-t * 18)
            for (b in 1..3) if (t > b * 0.011) env += exp(-(t - b * 0.011) * 40) * 0.8
            val w = rnd.nextFloat() * 2f - 1f
            val hp = w - prev * 0.6f; prev = w
            o[i] = hp * env.toFloat() * 0.45f
        }
        fade(o, sr); return o
    }

    fun laser(sr: Int): FloatArray {
        val n = (sr * 0.45).toInt(); val o = FloatArray(n); var ph = 0.0
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            ph += 2 * PI * (3200 * exp(-t * 9) + 220) / sr
            o[i] = (sin(ph) * exp(-t * 3)).toFloat() * 0.6f
        }
        fade(o, sr); return o
    }

    fun riser(sr: Int): FloatArray {
        val n = (sr * 4.0).toInt(); val o = FloatArray(n); val rnd = Random(3)
        var z = 0f
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            val a = (0.01 + 0.5 * (t / 4.0) * (t / 4.0)).toFloat()
            z += a * ((rnd.nextFloat() * 2f - 1f) - z)
            o[i] = z * (0.15f + (t / 4.0).toFloat()) * 1.6f
        }
        fade(o, sr, 0.05); return o
    }

    fun trapSiren(sr: Int): FloatArray {
        val n = (sr * 2.0).toInt(); val o = FloatArray(n); var ph = 0.0
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            val tri = abs(((t * 1.5) % 1.0) * 2 - 1)
            ph += 2 * PI * (500 + 700 * tri + 12 * sin(2 * PI * 7 * t)) / sr
            val s = sin(ph) + 0.4 * sin(ph * 3)
            o[i] = (s * 0.35).toFloat()
        }
        fade(o, sr, 0.1); return o
    }

    fun scratchFx(sr: Int): FloatArray {
        val n = (sr * 0.6).toInt(); val o = FloatArray(n)
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            val f = 180 + 500 * abs(sin(2 * PI * 3.2 * t))
            o[i] = (sin(2 * PI * f * t + 5 * sin(2 * PI * 9 * t)) * exp(-t * 2.5)).toFloat() * 0.6f
        }
        fade(o, sr); return o
    }
}

class SampleSlot(var name: String, var data: FloatArray) {
    @Volatile var playPos = -1      // -1 = parado
}

/** Sampler de 8 pads (4 por página en cada deck). Se mezcla en el master. */
class Sampler(private val sr: Int) {
    val slots = arrayOf(
        SampleSlot("SIREN", SampleSynth.siren(sr)),
        SampleSlot("AIR HORN", SampleSynth.airHorn(sr)),
        SampleSlot("KICK", SampleSynth.kick(sr)),
        SampleSlot("CLAP", SampleSynth.clap(sr)),
        SampleSlot("LASER", SampleSynth.laser(sr)),
        SampleSlot("RISER", SampleSynth.riser(sr)),
        SampleSlot("TRAP SIREN", SampleSynth.trapSiren(sr)),
        SampleSlot("SCRATCH FX", SampleSynth.scratchFx(sr))
    )
    val names = mutableStateListOf<String>().apply { slots.forEach { add(it.name) } }
    var volume = 0.9f

    fun trigger(i: Int) { if (i in slots.indices) slots[i].playPos = 0 }
    fun stop(i: Int) { if (i in slots.indices) slots[i].playPos = -1 }
    fun stopAll() { slots.forEach { it.playPos = -1 } }
    fun isPlaying(i: Int) = i in slots.indices && slots[i].playPos >= 0

    fun setSample(i: Int, name: String, data: FloatArray) {
        slots[i].playPos = -1
        slots[i].data = data
        slots[i].name = name
        names[i] = name
    }

    fun render(l: FloatArray, r: FloatArray, n: Int) {
        val v = volume
        for (s in slots) {
            var p = s.playPos
            if (p < 0) continue
            val d = s.data
            var i = 0
            while (i < n && p < d.size) {
                val x = d[p++] * v
                l[i] += x; r[i] += x
                i++
            }
            s.playPos = if (p >= d.size) -1 else p
        }
    }
}
