package com.neondeck.dj.audio

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.nio.ByteOrder

/** Decodifica cualquier formato soportado por Android (mp3, aac, flac, wav, ogg...) a PCM 16 bit estéreo. */
object TrackLoader {

    class Decoded(val pcm: ShortArray, val frames: Int, val sampleRate: Int)

    private class ShortBuf(cap: Int) {
        var a = ShortArray(cap)
        var n = 0
        fun add2(l: Short, r: Short) {
            if (n + 2 > a.size) a = a.copyOf(a.size + a.size / 2 + 8192)
            a[n++] = l; a[n++] = r
        }
    }

    fun displayName(ctx: Context, uri: Uri): String {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0).substringBeforeLast('.')
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "Track"
    }

    fun decode(ctx: Context, uri: Uri, onProgress: (Float) -> Unit = {}): Decoded {
        val ex = MediaExtractor()
        ex.setDataSource(ctx, uri, null)
        var idx = -1
        var fmt: MediaFormat? = null
        for (i in 0 until ex.trackCount) {
            val f = ex.getTrackFormat(i)
            if ((f.getString(MediaFormat.KEY_MIME) ?: "").startsWith("audio/")) { idx = i; fmt = f; break }
        }
        require(idx >= 0 && fmt != null) { "El archivo no contiene audio" }
        ex.selectTrack(idx)
        val mime = fmt.getString(MediaFormat.KEY_MIME)!!
        var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
        var ch = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val durUs = if (fmt.containsKey(MediaFormat.KEY_DURATION)) fmt.getLong(MediaFormat.KEY_DURATION) else 0L

        val codec = MediaCodec.createDecoderByType(mime)
        codec.configure(fmt, null, null, 0)
        codec.start()

        val estFrames = (durUs / 1_000_000.0 * rate).toInt().coerceIn(44100, 60_000_000)
        val out = ShortBuf(estFrames * 2 + 8192)
        val info = MediaCodec.BufferInfo()
        var inputDone = false
        var outputDone = false
        var pcmFloat = false
        var lastReport = 0L
        try {
            while (!outputDone) {
                if (!inputDone) {
                    val ii = codec.dequeueInputBuffer(5000)
                    if (ii >= 0) {
                        val buf = codec.getInputBuffer(ii)!!
                        val sz = ex.readSampleData(buf, 0)
                        if (sz < 0) {
                            codec.queueInputBuffer(ii, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(ii, 0, sz, ex.sampleTime, 0)
                            ex.advance()
                        }
                    }
                }
                val oi = codec.dequeueOutputBuffer(info, 5000)
                when {
                    oi >= 0 -> {
                        if (info.size > 0) {
                            val ob = codec.getOutputBuffer(oi)!!
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.order(ByteOrder.nativeOrder())
                            if (pcmFloat) {
                                val fb = ob.asFloatBuffer()
                                val total = fb.remaining()
                                var i = 0
                                while (i + ch <= total) {
                                    val l = fb.get(i)
                                    val r = if (ch > 1) fb.get(i + 1) else l
                                    out.add2(f2s(l), f2s(r))
                                    i += ch
                                }
                            } else {
                                val sb = ob.asShortBuffer()
                                val total = sb.remaining()
                                var i = 0
                                while (i + ch <= total) {
                                    val l = sb.get(i)
                                    val r = if (ch > 1) sb.get(i + 1) else l
                                    out.add2(l, r)
                                    i += ch
                                }
                            }
                        }
                        codec.releaseOutputBuffer(oi, false)
                        if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outputDone = true
                        if (durUs > 0 && info.presentationTimeUs - lastReport > 500_000) {
                            lastReport = info.presentationTimeUs
                            onProgress((info.presentationTimeUs.toFloat() / durUs).coerceIn(0f, 1f))
                        }
                    }
                    oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                        val of = codec.outputFormat
                        rate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                        ch = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                        pcmFloat = of.containsKey(MediaFormat.KEY_PCM_ENCODING) &&
                            of.getInteger(MediaFormat.KEY_PCM_ENCODING) == AudioFormat.ENCODING_PCM_FLOAT
                    }
                }
            }
        } finally {
            try { codec.stop() } catch (_: Exception) { }
            codec.release()
            ex.release()
        }
        val frames = out.n / 2
        return Decoded(out.a, frames, rate)
    }

    private fun f2s(f: Float): Short = (f.coerceIn(-1f, 1f) * 32767f).toInt().toShort()

    /** Decodifica y convierte a mono float al sample-rate de salida (para el sampler). */
    fun decodeMono(ctx: Context, uri: Uri, outRate: Int, maxSeconds: Int = 20): FloatArray {
        val d = decode(ctx, uri)
        val maxFrames = (maxSeconds * d.sampleRate).coerceAtMost(d.frames)
        val ratio = d.sampleRate.toDouble() / outRate
        val n = (maxFrames / ratio).toInt()
        val o = FloatArray(n)
        for (i in 0 until n) {
            val p = i * ratio
            val i0 = p.toInt()
            if (i0 + 1 >= maxFrames) break
            val fr = (p - i0).toFloat()
            val a = (d.pcm[i0 * 2] + d.pcm[i0 * 2 + 1]) * 0.5f
            val b = (d.pcm[(i0 + 1) * 2] + d.pcm[(i0 + 1) * 2 + 1]) * 0.5f
            o[i] = (a + (b - a) * fr) / 32768f
        }
        return o
    }

    suspend fun load(
        ctx: Context,
        uri: Uri,
        onProgress: (Float) -> Unit
    ): LoadedTrack = withContext(Dispatchers.Default) {
        var title = displayName(ctx, uri)
        var artist = ""
        var art: Bitmap? = null
        try {
            val mmr = MediaMetadataRetriever()
            mmr.setDataSource(ctx, uri)
            mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() }?.let { title = it }
            artist = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: ""
            mmr.embeddedPicture?.let { bytes ->
                val o = BitmapFactory.Options().apply { inSampleSize = 4 }
                art = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, o)
            }
            mmr.release()
        } catch (_: Exception) { }

        val d = decode(ctx, uri) { onProgress(it * 0.8f) }
        require(d.frames > d.sampleRate) { "Pista demasiado corta" }
        onProgress(0.82f)
        val wr = Analyzer.waveform(d.pcm, d.frames, d.sampleRate)
        onProgress(0.9f)
        val hopRate = d.sampleRate / Analyzer.BIN.toDouble()
        val (bpm, firstBeatSec) = Analyzer.detectBpm(wr.onset, hopRate)
        onProgress(0.95f)
        val key = try { Analyzer.detectKey(d.pcm, d.frames, d.sampleRate) } catch (_: Exception) { "--" }
        val overview = Analyzer.overviewBitmap(wr)
        onProgress(1f)
        LoadedTrack(
            title = title, artist = artist,
            durationSec = d.frames / d.sampleRate.toFloat(),
            pcm = d.pcm, srcRate = d.sampleRate, frames = d.frames,
            bpm = bpm, firstBeatFrame = firstBeatSec * d.sampleRate,
            key = key, wave = Waveform(wr.peak, wr.color, overview), art = art
        )
    }
}
