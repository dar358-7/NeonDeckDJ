package com.neondeck.dj.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object Neon {
    val Bg = Color(0xFF000000)
    val Panel = Color(0xFF0F0F12)
    val Panel2 = Color(0xFF17171C)
    val Button = Color(0xFF1A1A1F)
    val DeckA = Color(0xFF1E88E5)
    val DeckB = Color(0xFFFF3E9D)
    val PadFill = Color(0xFF6D28D9)
    val PadFillDim = Color(0xFF4C1D95)
    val PadBorder = Color(0xFFA78BFA)
    val Gray = Color(0xFF8E8E93)
    val GrayDark = Color(0xFF3A3A40)
    val Green = Color(0xFF4ADE80)
    val Yellow = Color(0xFFFACC15)
    val Red = Color(0xFFEF4444)
    val Text = Color(0xFFF2F2F7)

    fun deck(i: Int) = if (i == 0) DeckA else DeckB
}

@Composable
fun NeonTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Neon.DeckA,
            secondary = Neon.DeckB,
            background = Neon.Bg,
            surface = Neon.Panel,
            onSurface = Neon.Text,
            onBackground = Neon.Text
        ),
        content = content
    )
}
