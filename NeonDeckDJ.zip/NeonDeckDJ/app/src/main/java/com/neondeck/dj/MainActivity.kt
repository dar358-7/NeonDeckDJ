package com.neondeck.dj

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.neondeck.dj.ui.DjScreen
import com.neondeck.dj.ui.NeonTheme

class MainActivity : ComponentActivity() {
    private lateinit var session: DjSession
    private var pendingDeck = 0
    private var pendingSlot = 0

    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) {
        session.scanLibrary()
    }
    private val trackPicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            session.loadTrack(pendingDeck, uri)
            session.libraryOpen = false
        }
    }
    private val folderPicker = registerForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri: Uri? ->
        if (uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) { }
            session.addFolder(uri)
        }
    }
    private val samplePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) session.loadSampleIntoSlot(pendingSlot, uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        CrashLog.install(applicationContext)
        session = DjSession(applicationContext)
        session.pickTrackHandler = { deck -> pendingDeck = deck; trackPicker.launch(arrayOf("audio/*")) }
        session.pickSampleHandler = { slot -> pendingSlot = slot; samplePicker.launch(arrayOf("audio/*")) }
        session.pickFolderHandler = { folderPicker.launch(null) }
        session.start()

        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(perm) == android.content.pm.PackageManager.PERMISSION_GRANTED) session.scanLibrary()
        else permLauncher.launch(perm)

        setContent { NeonTheme { DjScreen(session) } }
    }

    override fun onDestroy() {
        session.stop()
        super.onDestroy()
    }
}
