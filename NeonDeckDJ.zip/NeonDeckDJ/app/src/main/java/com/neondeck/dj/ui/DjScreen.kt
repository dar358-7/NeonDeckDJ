package com.neondeck.dj.ui

import android.content.Context
import android.os.BatteryManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neondeck.dj.DjSession
import com.neondeck.dj.audio.Analyzer
import com.neondeck.dj.audio.Deck
import com.neondeck.dj.audio.PadMode
import com.neondeck.dj.audio.Pads
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun DjScreen(s: DjSession) {
    val frame = remember { mutableLongStateOf(0L) }
    LaunchedEffect(Unit) {
        while (true) withFrameNanos { frame.longValue = it }
    }
    val frameState: State<Long> = frame
    val a = s.engine.deckA
    val b = s.engine.deckB

    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF04050A), Color(0xFF0B0E1A), Color(0xFF06070D))))) {
        Column(Modifier.fillMaxSize().safeDrawingPadding()) {
            TopBar(s, a, b, frameState)
            BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                val platter = minOf(maxHeight - 4.dp, maxWidth * 0.27f)
                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    SideStrip(a, frameState, Modifier.width(62.dp).fillMaxHeight().padding(vertical = 4.dp), mirrored = false)
                    Platter(a, frameState, Modifier.size(platter))
                    CenterWaveforms(
                        a, b, s, frameState,
                        Modifier.weight(1f).fillMaxHeight().padding(horizontal = 4.dp, vertical = 2.dp)
                            .border(1.dp, Color(0xFF1E2233), RoundedCornerShape(18.dp))
                    )
                    Platter(b, frameState, Modifier.size(platter))
                    SideStrip(b, frameState, Modifier.width(62.dp).fillMaxHeight().padding(vertical = 4.dp), mirrored = true)
                }
            }
            ControlBar(s, a, b)
            PadsBar(s, a, b)
        }

        if (s.mixerOpen) MixerSheet(s, frameState)
        if (s.libraryOpen) LibrarySheet(s)
        if (s.settingsOpen) SettingsSheet(s)

        val msg = s.message
        if (msg != null) {
            LaunchedEffect(msg) { delay(3500); if (s.message == msg) s.message = null }
            Box(Modifier.fillMaxSize().padding(bottom = 90.dp), contentAlignment = Alignment.BottomCenter) {
                Text(
                    msg, color = Color.White, fontSize = 13.sp,
                    modifier = Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xEE222228))
                        .padding(horizontal = 18.dp, vertical = 10.dp)
                )
            }
        }
    }
}

// ============================================================================ barra superior

@Composable
private fun TopBar(s: DjSession, a: Deck, b: Deck, frame: State<Long>) {
    Row(
        Modifier.fillMaxWidth().height(58.dp).padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ClockBattery(Modifier.width(74.dp))
        DeckHeader(a, frame, onLoad = { s.requestLoad(0) }, modifier = Modifier.weight(1f), artOnLeft = true)
        Column(
            Modifier.width(160.dp).padding(horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(brush = Brush.horizontalGradient(listOf(Neon.DeckA, Color(0xFF22D3EE), Neon.DeckB)))) { append("NEON") }
                },
                style = TextStyle(fontSize = 19.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
            )
            Text("by DARVI'S", color = Neon.Gray, fontSize = 9.sp, fontWeight = FontWeight.SemiBold, letterSpacing = 2.sp)
            Spacer(Modifier.height(3.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                val midiOn = s.midi.connectedName != null
                Pill(if (midiOn) "● MIDI" else "○ MIDI", if (midiOn) Neon.Green else Neon.Gray) { s.settingsOpen = true }
                val rec = s.engine.recording
                Pill(if (rec) "■ REC" else "● REC", if (rec) Neon.Red else Neon.Gray) {
                    val f = s.engine.toggleRecording()
                    s.toast(if (s.engine.recording) "Grabando…" else "Grabación guardada: ${f?.name ?: ""}")
                }
            }
        }
        DeckHeader(b, frame, onLoad = { s.requestLoad(1) }, modifier = Modifier.weight(1f), artOnLeft = false)
        Box(
            Modifier.size(40.dp).clickable { s.settingsOpen = true },
            contentAlignment = Alignment.Center
        ) { Text("⚙", color = Neon.Gray, fontSize = 24.sp) }
    }
}

@Composable
private fun Pill(text: String, color: Color, onClick: () -> Unit) {
    Text(
        text, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).border(1.2.dp, color, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).padding(horizontal = 8.dp, vertical = 3.dp)
    )
}

@Composable
private fun ClockBattery(modifier: Modifier) {
    val ctx = LocalContext.current
    val clock by produceState("--:--") {
        val fmt = SimpleDateFormat("h:mm a", Locale.getDefault())
        while (true) { value = fmt.format(Date()); delay(15_000) }
    }
    val battery by produceState(100) {
        val bm = ctx.getSystemService(Context.BATTERY_SERVICE) as BatteryManager
        while (true) {
            value = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY).coerceIn(0, 100)
            delay(60_000)
        }
    }
    Column(modifier, verticalArrangement = Arrangement.Center) {
        Text(clock, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(3.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(22.dp, 11.dp).border(1.dp, Neon.Gray, RoundedCornerShape(3.dp)).padding(1.5.dp)
            ) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(battery / 100f)
                        .clip(RoundedCornerShape(2.dp))
                        .background(if (battery > 20) Color.White else Neon.Red)
                )
            }
            Spacer(Modifier.width(4.dp))
            Text("$battery%", color = Neon.Gray, fontSize = 9.sp)
        }
    }
}

@Composable
private fun DeckHeader(deck: Deck, frame: State<Long>, onLoad: () -> Unit, modifier: Modifier, artOnLeft: Boolean) {
    val t = deck.track
    val accent = Neon.deck(deck.index)
    val art = remember(t) { t?.art?.asImageBitmap() }
    val artBox: @Composable () -> Unit = {
        Box(
            Modifier.size(42.dp).clip(RoundedCornerShape(4.dp)).background(Neon.Panel2).clickable(onClick = onLoad),
            contentAlignment = Alignment.Center
        ) {
            if (art != null) Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            else Text(if (deck.index == 0) "A" else "B", color = accent, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
    Row(modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        if (artOnLeft) { artBox(); Spacer(Modifier.width(6.dp)) }
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f).clickable(onClick = onLoad)) {
                    val title = when {
                        deck.loading -> "Cargando…"
                        t != null -> t.title
                        else -> "Toca para cargar"
                    }
                    Text(title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(t?.artist ?: "", color = Neon.Gray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (t != null) {
                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            "%d:%02d".format((t.durationSec / 60).toInt(), (t.durationSec % 60).toInt()),
                            color = Neon.Gray, fontSize = 11.sp
                        )
                        Text(if (t.bpm > 0f) "${t.bpm.toInt()} BPM" else "… BPM", color = if (t.bpm > 0f) Color.White else Neon.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(5.dp))
                    Text(
                        t.key, color = Color.Black, fontSize = 10.sp, fontWeight = FontWeight.Black,
                        modifier = Modifier.clip(RoundedCornerShape(3.dp)).background(Color(Analyzer.keyColor(t.key)))
                            .padding(horizontal = 5.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(Modifier.height(3.dp))
            Overview(deck, frame, Modifier.fillMaxWidth().height(15.dp).clip(RoundedCornerShape(2.dp)))
        }
        if (!artOnLeft) { Spacer(Modifier.width(6.dp)); artBox() }
    }
}

// ============================================================================ laterales: fader + vúmetro

@Composable
private fun SideStrip(deck: Deck, frame: State<Long>, modifier: Modifier, mirrored: Boolean) {
    var bpmMode by remember { mutableStateOf(false) }
    val accent = Neon.deck(deck.index)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Column(
            Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFF1B1B20))
                .clickable { bpmMode = !bpmMode }.padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("VOL", color = if (!bpmMode) accent else Neon.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text("BPM", color = if (bpmMode) accent else Neon.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(6.dp))
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            val meter: @Composable () -> Unit = {
                LedMeter({ deck.level }, frame, Modifier.width(9.dp).fillMaxHeight().padding(vertical = 2.dp))
            }
            val fader: @Composable () -> Unit = {
                VFader(
                    value = if (bpmMode) (deck.pitch + 1f) / 2f else deck.volume,
                    onChange = { v -> if (bpmMode) deck.userSetPitch(v * 2f - 1f) else deck.volume = v },
                    modifier = Modifier.width(40.dp).fillMaxHeight(),
                    accent = accent,
                    tickColor = if (bpmMode && kotlin.math.abs(deck.pitch) < 0.004f) Neon.Green else Color(0xFFE5E7EB)
                )
            }
            if (!mirrored) { meter(); fader() } else { fader(); meter() }
        }
        Spacer(Modifier.height(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            NudgeButton("−") { deck.userSetPitch(deck.pitch - 0.005f / deck.range) }
            NudgeButton("+") { deck.userSetPitch(deck.pitch + 0.005f / deck.range) }
        }
    }
}

@Composable
private fun NudgeButton(label: String, onTap: () -> Unit) {
    PressArea(Modifier.size(26.dp), onDown = onTap) { pressed ->
        Box(
            Modifier.fillMaxSize().clip(RoundedCornerShape(6.dp)).background(if (pressed) Neon.GrayDark else Color(0xFF232327)),
            contentAlignment = Alignment.Center
        ) { Text(label, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
    }
}

// ============================================================================ transporte

private val LOOP_SIZES = doubleArrayOf(0.25, 0.5, 1.0, 2.0, 4.0, 8.0, 16.0, 32.0)

private fun loopLabel(b: Double): String = when {
    b < 1.0 -> "1/${(1.0 / b).toInt()}"
    else -> "${b.toInt()}"
}

@Composable
private fun LoopButton(deck: Deck) {
    val accent = Neon.deck(deck.index)
    var pressed by remember { mutableStateOf(false) }
    val scale by animateFloatAsState(if (pressed) 0.9f else 1f, spring(0.45f, Spring.StiffnessMedium), label = "loop")
    Box(
        Modifier.size(50.dp).graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(CircleShape)
            .background(if (deck.loopActive) accent else Color(0xFF0A0A0C))
            .border(2.dp, if (deck.loopActive) accent else Neon.GrayDark, CircleShape)
            .pointerInput(deck) {
                detectTapGestures(
                    onPress = { pressed = true; tryAwaitRelease(); pressed = false },
                    onTap = { deck.beatLoopToggle() },
                    onLongPress = {
                        val i = LOOP_SIZES.indexOfFirst { it >= deck.loopBeats }.let { if (it < 0) 0 else it }
                        deck.loopBeats = LOOP_SIZES[(i + 1) % LOOP_SIZES.size]
                        if (deck.loopActive) deck.setBeatLoop(deck.loopBeats, quantize = false)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text("⟲", color = Color.White, fontSize = 11.sp, lineHeight = 11.sp)
            Text(loopLabel(deck.loopBeats), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold, lineHeight = 13.sp)
        }
    }
}

@Composable
private fun ControlBar(s: DjSession, a: Deck, b: Deck) {
    val e = s.engine
    Row(
        Modifier.fillMaxWidth().height(62.dp)
            .background(Brush.verticalGradient(listOf(Color(0xFF151827), Color(0xFF0D0F19))), RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp))
            .padding(horizontal = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        MixerButton(48.dp) { s.mixerOpen = !s.mixerOpen }
        PlayButton(56.dp, a.playing, Neon.DeckA) { a.playPause() }
        RoundButton(50.dp, "CUE", false, Neon.DeckA, onDown = { a.cueDown() }, onUp = { a.cueUp() })
        RoundButton(50.dp, "SYNC", a.syncOn, Neon.DeckA, onDown = {
            if (a.syncOn) a.syncOn = false else a.syncTo(b)
        }, fontSize = 11)
        LoopButton(a)
        Crossfader(e.crossfader, { e.crossfader = it }, Modifier.weight(1f).height(40.dp))
        LoopButton(b)
        RoundButton(50.dp, "SYNC", b.syncOn, Neon.DeckB, onDown = {
            if (b.syncOn) b.syncOn = false else b.syncTo(a)
        }, fontSize = 11)
        RoundButton(50.dp, "CUE", false, Neon.DeckB, onDown = { b.cueDown() }, onUp = { b.cueUp() })
        PlayButton(56.dp, b.playing, Neon.DeckB) { b.playPause() }
        MixerButton(48.dp) { s.mixerOpen = !s.mixerOpen }
    }
}

// ============================================================================ pads

private val PAD_MODES = PadMode.values()

@Composable
private fun PadsBar(s: DjSession, a: Deck, b: Deck) {
    Row(
        Modifier.fillMaxWidth().height(60.dp).background(Color(0xFF0D0F19)).padding(start = 6.dp, end = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        PadsHalf(s, a, Modifier.weight(1f), modeFirst = true)
        PadsHalf(s, b, Modifier.weight(1f), modeFirst = false)
    }
}

@Composable
private fun PadsHalf(s: DjSession, deck: Deck, modifier: Modifier, modeFirst: Boolean) {
    Row(modifier.fillMaxHeight(), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
        val modeBtn: @Composable () -> Unit = {
            Column(
                Modifier.width(58.dp).fillMaxHeight().clip(RoundedCornerShape(8.dp)).background(Color(0xFF1A1A1E))
                    .clickable { deck.padMode = PAD_MODES[(deck.padMode.ordinal + 1) % PAD_MODES.size] },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                Text("PADS", color = Neon.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                Text(deck.padMode.label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            }
        }
        val dots: @Composable () -> Unit = {
            Column(
                Modifier.width(16.dp).fillMaxHeight().clickable { deck.padPage = 1 - deck.padPage },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
            ) {
                for (i in 0..1) {
                    Box(Modifier.padding(2.dp).size(6.dp).clip(CircleShape)
                        .background(if (deck.padPage == i) Neon.deck(deck.index) else Neon.GrayDark))
                }
            }
        }
        if (modeFirst) modeBtn()
        if (!modeFirst) dots()
        for (p in 0..3) PadView(s, deck, p, Modifier.weight(1f).fillMaxHeight())
        if (modeFirst) dots()
        if (!modeFirst) modeBtn()
    }
}

@Composable
private fun PadView(s: DjSession, deck: Deck, pad: Int, modifier: Modifier) {
    val e = s.engine
    val slot = deck.padPage * 4 + pad
    var pressed by remember { mutableStateOf(false) }
    val lit: Boolean
    val label: String
    val sub: String
    var tint = Neon.PadFill
    when (deck.padMode) {
        PadMode.SAMPLER -> {
            lit = e.sampler.isPlaying(slot)
            label = e.sampler.names[slot]; sub = "${slot + 1}"
        }
        PadMode.HOTCUE -> {
            val f = deck.hotCues[slot]
            lit = f >= 0
            label = if (f >= 0) "CUE ${slot + 1}" else "SET ${slot + 1}"
            sub = if (f >= 0) fmtTime(f / (deck.track?.srcRate ?: 44100)) else ""
            if (f >= 0) tint = Color(cueColor(slot))
        }
        PadMode.ROLL -> {
            lit = deck.loopActive && deck.loopBeats == Pads.ROLL_BEATS[pad]
            label = "ROLL"; sub = Pads.ROLL_LABELS[pad]
        }
        PadMode.FX -> {
            lit = deck.fxType == pad + 1
            label = Pads.FX_LABELS[pad]; sub = if (pad < 3) "FX" else ""
        }
    }
    val isLit = lit || pressed
    val fill by animateColorAsState(if (isLit) tint else Neon.PadFillDim.copy(alpha = 0.9f), label = "padfill")
    val scale by animateFloatAsState(if (pressed) 0.93f else 1f, spring(0.45f, Spring.StiffnessMedium), label = "padscale")
    val latestSlot by rememberUpdatedState(slot)
    Box(
        modifier.graphicsLayer { scaleX = scale; scaleY = scale }
            .clip(RoundedCornerShape(10.dp))
            .background(Brush.verticalGradient(listOf(fill, fill.copy(alpha = 0.72f))))
            .border(if (isLit) 2.dp else 1.2.dp, if (isLit) Color.White else Neon.PadBorder.copy(alpha = 0.8f), RoundedCornerShape(10.dp))
            .pointerInput(deck, deck.padMode) {
                detectTapGestures(
                    onPress = {
                        pressed = true
                        Pads.press(e, deck, pad, true)
                        tryAwaitRelease()
                        pressed = false
                        Pads.press(e, deck, pad, false)
                    },
                    onLongPress = {
                        if (deck.padMode == PadMode.SAMPLER) s.pickSample(latestSlot)
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center)
            if (sub.isNotEmpty()) Text(sub, color = Color.White.copy(alpha = 0.75f), fontSize = 9.sp)
        }
    }
}
