package com.neondeck.dj.audio

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.round

enum class PadMode(val label: String) {
    HOTCUE("HOT CUE"), ROLL("ROLL"), FX("FX"), SAMPLER("SAMPLER")
}

/**
 * Un deck de DJ. Los campos con estado de Compose son los que ve la UI;
 * el hilo de audio los lee una vez por bloque.
 */
class Deck(val index: Int, private val outRate: Int) {

    // ------------------------------------------------------------ estado visible
    var track by mutableStateOf<LoadedTrack?>(null)
    var loading by mutableStateOf(false)
    var loadProgress by mutableFloatStateOf(0f)
    var playing by mutableStateOf(false)
    var pitch by mutableFloatStateOf(0f)           // -1..1 (arriba = más rápido)
    var range by mutableFloatStateOf(0.08f)        // 0.08 / 0.16 / 0.50
    var vinyl by mutableStateOf(true)
    var syncOn by mutableStateOf(false)
    var volume by mutableFloatStateOf(1f)          // fader de canal 0..1
    var gain by mutableFloatStateOf(1f)            // trim 0..2
    var eqHigh by mutableFloatStateOf(1f)          // 0..1.5 (1 = plano)
    var eqMid by mutableFloatStateOf(1f)
    var eqLow by mutableFloatStateOf(1f)
    var filter by mutableFloatStateOf(0f)          // -1 (LP) .. 1 (HP)
    var fxType by mutableIntStateOf(0)             // 0 off, 1 echo, 2 flanger, 3 reverb
    var fxAmount by mutableFloatStateOf(0.5f)
    var pfl by mutableStateOf(false)               // pre-fader listen (auriculares)
    var padMode by mutableStateOf(PadMode.SAMPLER)
    var padPage by mutableIntStateOf(0)
    var loopActive by mutableStateOf(false)
    var loopBeats by mutableDoubleStateOf(4.0)
    var cuePoint by mutableDoubleStateOf(0.0)
    var shiftHeld by mutableStateOf(false)
    val hotCues = mutableStateListOf(-1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0)

    // ------------------------------------------------------------ estado de audio
    @Volatile var pos = 0.0                 // posición en frames de la pista
    @Volatile var loopInPos = 0.0
    @Volatile var loopOutPos = 0.0
    @Volatile var level = 0f                // vúmetro 0..1
    @Volatile var touched = false

    private val lock = Any()
    private var scratchAcc = 0.0
    private var pendingSeek = Double.NaN
    private var pendingAdd = 0.0
    @Volatile private var bendVal = 0.0
    private var speed = 0.0
    private var scratchTgt = 0.0
    private var wasScratching = false
    private var prevVol = 1f
    private var cuePreview = false
    private var padStarted = false
    @Volatile private var slipActive = false
    @Volatile private var slipPos = 0.0

    private val eqL = EqChannel(outRate)
    private val eqR = EqChannel(outRate)
    private val fltL = SweepFilter()
    private val fltR = SweepFilter()
    private val fx = FxUnit(outRate)

    private val kNorm = 1.0 - exp(-1.0 / (0.012 * outRate))
    private val kScratch = 1.0 - exp(-1.0 / (0.010 * outRate))

    // ------------------------------------------------------------ utilidades
    fun tempoRate(): Double = 1.0 + pitch * range
    fun currentBpm(): Float = (track?.bpm ?: 0f) * tempoRate().toFloat()
    fun durationSec(): Float = track?.durationSec ?: 0f
    fun posSec(): Double { val t = track ?: return 0.0; return pos / t.srcRate }
    fun progress(): Float { val t = track ?: return 0f; return (pos / t.frames).toFloat().coerceIn(0f, 1f) }

    fun beatPhase(): Double {
        val t = track ?: return 0.0
        val x = (pos - t.firstBeatFrame) / t.beatLenFrames
        return x - floor(x)
    }

    private fun nearestBeat(frame: Double): Double {
        val t = track ?: return frame
        val bl = t.beatLenFrames
        return t.firstBeatFrame + round((frame - t.firstBeatFrame) / bl) * bl
    }

    // ------------------------------------------------------------ carga
    fun load(t: LoadedTrack) {
        playing = false
        synchronized(lock) { scratchAcc = 0.0; pendingAdd = 0.0; pendingSeek = Double.NaN }
        speed = 0.0
        loopActive = false
        slipActive = false
        for (i in 0 until 8) hotCues[i] = -1.0
        val old = track
        if (old != null && old !== t) old.cancelled = true
        val start = if (t.firstBeatFrame in 0.0..(t.frames / 2.0)) t.firstBeatFrame else 0.0
        pos = start
        cuePoint = start
        pitch = 0f
        syncOn = false
        track = t
    }

    fun eject() {
        playing = false
        track = null
        pos = 0.0
        loopActive = false
        syncOn = false
    }

    // ------------------------------------------------------------ transporte
    fun playPause() {
        if (track == null) return
        playing = !playing
        cuePreview = false
    }

    fun cueDown() {
        val t = track ?: return
        if (playing) {
            playing = false
            seekFrames(cuePoint)
        } else if (abs(pos - cuePoint) < t.srcRate * 0.03) {
            playing = true
            cuePreview = true
        } else {
            cuePoint = nearestBeat(pos).coerceIn(0.0, t.frames - 2.0)
            if (abs(cuePoint - pos) > t.srcRate * 0.2) cuePoint = pos
        }
    }

    fun cueUp() {
        if (cuePreview) {
            cuePreview = false
            playing = false
            seekFrames(cuePoint)
        }
    }

    fun goToStart() { seekFrames(0.0); playing = false }

    fun seekFrames(f: Double) {
        val t = track ?: return
        synchronized(lock) { pendingSeek = f.coerceIn(0.0, t.frames - 2.0); pendingAdd = 0.0 }
    }

    fun seekFraction(fr: Float) {
        val t = track ?: return
        seekFrames(fr.coerceIn(0f, 1f) * t.frames.toDouble())
    }

    fun seekSeconds(deltaSec: Double) {
        val t = track ?: return
        synchronized(lock) { pendingAdd += deltaSec * t.srcRate }
    }

    // ------------------------------------------------------------ jog / scratch
    fun touchStart() { touched = true }
    fun touchEnd() { touched = false }

    /** Mueve el disco: segundos de audio (positivo = adelante). En vinilo = scratch, si no = pitch bend. */
    fun scratchSeconds(sec: Double) {
        val t = track ?: return
        if (vinyl && touched) {
            synchronized(lock) { scratchAcc += sec * t.srcRate }
        } else {
            bendVal = (bendVal + sec * 4.0).coerceIn(-0.4, 0.4)
        }
    }

    // ------------------------------------------------------------ hot cues
    fun hotCueDown(i: Int) {
        val t = track ?: return
        if (hotCues[i] < 0) {
            hotCues[i] = nearestBeat(pos).let { if (abs(it - pos) < t.srcRate * 0.15) it else pos }.coerceIn(0.0, t.frames - 2.0)
        } else {
            seekFrames(hotCues[i])
            if (!playing) { playing = true; padStarted = true }
        }
    }

    fun hotCueUp(i: Int) {
        if (padStarted) {
            padStarted = false
            playing = false
            if (hotCues[i] >= 0) seekFrames(hotCues[i])
        }
    }

    fun deleteHotCue(i: Int) { hotCues[i] = -1.0 }

    // ------------------------------------------------------------ loops
    fun setBeatLoop(beats: Double, quantize: Boolean = true) {
        val t = track ?: return
        loopBeats = beats
        val start = if (quantize) nearestBeat(pos) else pos
        loopInPos = start
        loopOutPos = start + beats * t.beatLenFrames
        loopActive = true
    }

    fun beatLoopToggle() { if (loopActive) loopActive = false else setBeatLoop(loopBeats) }
    fun loopHalve() { loopBeats = max(1.0 / 32, loopBeats / 2); if (loopActive) retimeLoop() }
    fun loopDouble() { loopBeats = min(64.0, loopBeats * 2); if (loopActive) retimeLoop() }
    private fun retimeLoop() {
        val t = track ?: return
        loopOutPos = loopInPos + loopBeats * t.beatLenFrames
    }

    fun loopInSet() { loopInPos = pos; if (loopActive) loopActive = false }
    fun loopOutSet() {
        if (pos > loopInPos + 100) { loopOutPos = pos; loopActive = true }
    }

    fun rollStart(beats: Double) {
        val t = track ?: return
        slipPos = pos
        slipActive = true
        loopBeats = beats
        loopInPos = pos
        loopOutPos = pos + beats * t.beatLenFrames
        loopActive = true
    }

    fun rollEnd() {
        if (!slipActive) return
        loopActive = false
        slipActive = false
        seekFrames(slipPos)
    }

    // ------------------------------------------------------------ sync / pitch
    fun userSetPitch(v: Float) { pitch = v.coerceIn(-1f, 1f); syncOn = false }

    fun cycleRange() {
        range = when {
            range < 0.1f -> 0.16f
            range < 0.2f -> 0.5f
            else -> 0.08f
        }
        pitch = pitch.coerceIn(-1f, 1f)
    }

    fun syncTo(other: Deck) {
        val t = track ?: return
        if (other.track == null) return
        val target = other.currentBpm()
        if (t.bpm <= 0f || target <= 0f) return
        val needed = target / t.bpm - 1f
        var r = range
        if (abs(needed) > r) r = listOf(0.08f, 0.16f, 0.5f).firstOrNull { abs(needed) <= it } ?: 0.5f
        range = r
        pitch = (needed / r).coerceIn(-1f, 1f)
        if (other.playing && playing) {
            var d = other.beatPhase() - beatPhase()
            if (d > 0.5) d -= 1.0
            if (d < -0.5) d += 1.0
            synchronized(lock) { pendingAdd += d * t.beatLenFrames }
        }
        syncOn = true
    }

    /** Llamado por el motor cada bloque: un deck sincronizado sigue el tempo del otro. */
    fun followTempo(other: Deck) {
        val t = track ?: return
        if (!syncOn || other.track == null || other.syncOn || t.bpm <= 0f || other.currentBpm() <= 0f) return
        val needed = other.currentBpm() / t.bpm - 1f
        val p = (needed / range).coerceIn(-1f, 1f)
        if (abs(p - pitch) > 1e-4f) pitch = p
    }

    // ------------------------------------------------------------ render (hilo de audio)
    fun render(outL: FloatArray, outR: FloatArray, n: Int) {
        java.util.Arrays.fill(outL, 0, n, 0f)
        java.util.Arrays.fill(outR, 0, n, 0f)
        val t = track
        if (t == null) { level *= 0.85f; return }

        val decoded = t.decodedFrames          // primero esto, luego el array (puede crecer en otro hilo)
        val pcm = t.pcm
        val frames = t.frames
        val complete = t.complete
        val limit = if (complete) frames - 1 else decoded - 4
        val ratio = t.srcRate.toDouble() / outRate
        val normalSpeed = ratio * tempoRate()
        val isPlaying = playing
        val bendNow = bendVal
        bendVal = bendNow * 0.96
        val scratching = touched && vinyl

        var p: Double
        var acc: Double
        var seeked: Boolean
        synchronized(lock) {
            p = pos
            seeked = false
            if (!pendingSeek.isNaN()) { p = pendingSeek; pendingSeek = Double.NaN; seeked = true }
            if (pendingAdd != 0.0) { p += pendingAdd; pendingAdd = 0.0; seeked = true }
            acc = scratchAcc; scratchAcc = 0.0
        }
        // Scratch: la cabeza de lectura SIGUE una posición objetivo con suavizado,
        // así el movimiento es continuo aunque los eventos del dedo/jog lleguen a ráfagas.
        if (scratching) {
            if (!wasScratching || seeked) scratchTgt = p
            scratchTgt += acc
        }
        wasScratching = scratching

        val target = if (isPlaying) normalSpeed * (1.0 + bendNow) else 0.0
        val kk = kNorm
        val kp = kScratch
        val loopOn = loopActive && loopOutPos > loopInPos + 64
        val lIn = loopInPos
        val lOut = loopOutPos
        val lLen = lOut - lIn
        var sp = speed
        val last = limit
        val minSp = ratio * 0.06
        val inv = 1f / 32768f

        for (i in 0 until n) {
            if (scratching) {
                val np = p + (scratchTgt - p) * kp
                sp = np - p
            } else {
                sp += (target - sp) * kk
            }
            var l = 0f
            var r = 0f
            val asp = abs(sp)
            if (asp > 1e-7) {
                val ip = floor(p).toInt()
                if (ip >= 0 && ip < last) {
                    val fr = (p - ip).toFloat()
                    val i0 = if (ip > 0) ip - 1 else 0
                    val i2 = ip + 1
                    val i3 = if (ip + 2 <= last) ip + 2 else last
                    l = hermite(pcm[i0 * 2].toFloat(), pcm[ip * 2].toFloat(), pcm[i2 * 2].toFloat(), pcm[i3 * 2].toFloat(), fr) * inv
                    r = hermite(pcm[i0 * 2 + 1].toFloat(), pcm[ip * 2 + 1].toFloat(), pcm[i2 * 2 + 1].toFloat(), pcm[i3 * 2 + 1].toFloat(), fr) * inv
                    if (asp < minSp) { val g = (asp / minSp).toFloat(); l *= g; r *= g }
                }
                p += sp
                if (!complete && p >= last) { p = last.toDouble(); sp = 0.0 }
                if (loopOn && !scratching) {
                    if (sp > 0 && p >= lOut) p = lIn + (p - lIn) % lLen
                    else if (sp < 0 && p < lIn) p += lLen
                }
            }
            outL[i] = l
            outR[i] = r
        }
        speed = sp

        if (slipActive && isPlaying) slipPos += normalSpeed * n
        if (p >= frames - 2) {
            p = frames - 2.0
            if (isPlaying) playing = false
            speed = 0.0
        }
        if (p < 0) { p = 0.0; speed = 0.0 }
        pos = p

        // ---- cadena de señal: trim -> EQ -> filtro -> FX -> fader
        val g = gain
        val gl = eqLow; val gm = eqMid; val gh = eqHigh
        for (i in 0 until n) {
            outL[i] = eqL.process(outL[i] * g, gl, gm, gh)
            outR[i] = eqR.process(outR[i] * g, gl, gm, gh)
        }
        val f = filter
        if (f < -0.03f) {
            val fc = 20000f * Math.pow(220.0 / 20000.0, (-f).toDouble()).toFloat()
            fltL.setup(fc, outRate, 1.1f); fltR.setup(fc, outRate, 1.1f)
            for (i in 0 until n) { outL[i] = fltL.lowpass(outL[i]); outR[i] = fltR.lowpass(outR[i]) }
        } else if (f > 0.03f) {
            val fc = 25f * Math.pow(9000.0 / 25.0, f.toDouble()).toFloat()
            fltL.setup(fc, outRate, 1.1f); fltR.setup(fc, outRate, 1.1f)
            for (i in 0 until n) { outL[i] = fltL.highpass(outL[i]); outR[i] = fltR.highpass(outR[i]) }
        }
        fx.process(outL, outR, n, fxType, fxAmount, max(40f, currentBpm()))

        val vol = volume
        var pk = 0f
        for (i in 0 until n) {
            val v = prevVol + (vol - prevVol) * ((i + 1f) / n)
            outL[i] *= v; outR[i] *= v
            val a = max(abs(outL[i]), abs(outR[i]))
            if (a > pk) pk = a
        }
        prevVol = vol
        level = max(pk, level * 0.88f)
    }
}

private fun hermite(y0: Float, y1: Float, y2: Float, y3: Float, x: Float): Float {
    val c1 = 0.5f * (y2 - y0)
    val c2 = y0 - 2.5f * y1 + 2f * y2 - 0.5f * y3
    val c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2)
    return ((c3 * x + c2) * x + c1) * x + y1
}
