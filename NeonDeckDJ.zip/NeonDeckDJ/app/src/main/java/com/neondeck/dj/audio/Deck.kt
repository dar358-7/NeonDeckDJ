package com.neondeck.dj.audio

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.max
import kotlin.math.min
import kotlin.math.PI
import kotlin.math.round
import kotlin.math.sin

enum class PadMode(val label: String) {
    HOTCUE("HOT CUE"), ROLL("ROLL"), FX("FX"), SAMPLER("SAMPLER"), JUMP("BEAT JUMP")
}

/**
 * Un deck de DJ. Los campos con estado de Compose son los que ve la UI;
 * el hilo de audio los lee una vez por bloque.
 */
class Deck(val index: Int, private val outRate: Int) {

    // ------------------------------------------------------------ estado visible
    var track by mutableStateOf<LoadedTrack?>(null)
    var loading by mutableStateOf(false)
    var loadProgress by mutableFloatStateOf(0f)
    var playing by mutableStateOf(false)
    var pitch by mutableFloatStateOf(0f)           // -1..1 (arriba = más rápido)
    var range by mutableFloatStateOf(0.08f)        // 0.08 / 0.16 / 0.50
    var vinyl by mutableStateOf(true)
    var syncOn by mutableStateOf(false)
    var volume by mutableFloatStateOf(1f)          // fader de canal 0..1
    var gain by mutableFloatStateOf(1f)            // trim 0..2
    var eqHigh by mutableFloatStateOf(1f)          // 0..1.5 (1 = plano)
    var eqMid by mutableFloatStateOf(1f)
    var eqLow by mutableFloatStateOf(1f)
    var filter by mutableFloatStateOf(0f)          // -1 (LP) .. 1 (HP)
    var fxType by mutableIntStateOf(0)             // 0 off, 1 echo, 2 flanger, 3 reverb, 4 ping-pong, 5 phaser, 6 crush, 7 gate, 8 auto-pan
    var fxAmount by mutableFloatStateOf(0.5f)
    var pfl by mutableStateOf(false)               // pre-fader listen (auriculares)
    var padMode by mutableStateOf(PadMode.SAMPLER)
    var padPage by mutableIntStateOf(0)
    var loopActive by mutableStateOf(false)
    var loopBeats by mutableDoubleStateOf(4.0)
    var cuePoint by mutableDoubleStateOf(0.0)
    var shiftHeld by mutableStateOf(false)
    var keyLock by mutableStateOf(false)           // Master Tempo: el tono no cambia al variar el pitch/tempo
    var stemMode by mutableIntStateOf(0)           // 0 normal, 1 sin voz (aprox.), 2 solo voz (aprox.)
    val hotCues = mutableStateListOf(-1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0, -1.0)

    // ------------------------------------------------------------ estado de audio
    @Volatile var pos = 0.0                 // posición en frames de la pista
    @Volatile var loopInPos = 0.0
    @Volatile var loopOutPos = 0.0
    @Volatile var level = 0f                // vúmetro 0..1
    @Volatile var touched = false

    private val lock = Any()
    private var scratchAcc = 0.0
    private var pendingSeek = Double.NaN
    private var pendingAdd = 0.0
    @Volatile private var bendVal = 0.0
    @Volatile private var phaseTrim = 0.0       // corrección fina de fase cuando SYNC está activo
    // ---- salida pre-fader (PFL): señal tras EQ/filtro/FX pero ANTES del fader de canal
    val preL = FloatArray(2048)
    val preR = FloatArray(2048)
    // ---- lanzamiento cuantizado (SYNC activo + otro deck sonando): espera al sub-beat exacto
    @Volatile var partner: Deck? = null
    @Volatile private var qPending = false
    @Volatile private var qPos = 0.0
    @Volatile private var qPhase = 0.0
    @Volatile var snapPos = 0.0                 // posición y velocidad al inicio del bloque (el motor las toma antes de renderizar)
    @Volatile var snapSpeed = 0.0
    val launchWaiting: Boolean get() = qPending
    // ---- compensación de latencia: lo que se ve debe coincidir con lo que se oye
    @Volatile var latencyOutFrames = 0.0
    var gridBusy by mutableStateOf(0)           // se incrementa al editar la rejilla (para refrescar la UI)
    var onGridEdit: (() -> Unit)? = null

    // ---- Master Tempo (WSOLA): granos con ventana de Hann, 2 voces solapadas
    private val hs = 1024
    private val win = FloatArray(hs * 2) { val s = sin(PI * (it + 0.5) / (hs * 2)); (s * s).toFloat() }
    private val vSrc = DoubleArray(2)
    private val vIdx = intArrayOf(-1, -1)
    private var vNext = 0
    private var hopCount = 0
    private var klActive = false
    // ---- stems aproximados (cancelación del centro / banda de voz)
    private var stLow = 0f; private var stVoc = 0f
    private val stA = (1.0 - exp(-2.0 * PI * 180.0 / outRate)).toFloat()
    private val stB = (1.0 - exp(-2.0 * PI * 4500.0 / outRate)).toFloat()
    private var speed = 0.0
    private var scratchTgt = 0.0
    private var wasScratching = false
    private var prevVol = 1f
    private var cuePreview = false
    private var padStarted = false
    @Volatile private var slipActive = false
    @Volatile private var slipPos = 0.0

    private val eqL = EqChannel(outRate)
    private val eqR = EqChannel(outRate)
    private val fltL = SweepFilter()
    private val fltR = SweepFilter()
    private val fx = FxUnit(outRate)

    private val kNorm = 1.0 - exp(-1.0 / (0.012 * outRate))
    private val kScratch = 1.0 - exp(-1.0 / (0.010 * outRate))

    // ------------------------------------------------------------ utilidades
    fun tempoRate(): Double = 1.0 + pitch * range
    fun currentBpm(): Float = (track?.bpm ?: 0f) * tempoRate().toFloat()
    fun durationSec(): Float = track?.durationSec ?: 0f
    fun posSec(): Double { val t = track ?: return 0.0; return pos / t.srcRate }
    fun progress(): Float { val t = track ?: return 0f; return (pos / t.frames).toFloat().coerceIn(0f, 1f) }

    fun beatPhase(): Double {
        val t = track ?: return 0.0
        return t.phaseAt(pos)
    }

    private fun nearestBeat(frame: Double): Double {
        val t = track ?: return frame
        return t.nearestBeatFrame(frame)
    }

    /** Posición que se ESCUCHA ahora (la que ya salió por el altavoz): pos menos lo que queda en el búfer de salida. */
    fun viewPos(): Double {
        val sp = speed
        return (pos - sp * latencyOutFrames).coerceAtLeast(0.0)
    }

    fun snapshotBlock() { snapPos = pos; snapSpeed = speed }

    // ---- ajuste manual de rejilla / BPM (pasos microscópicos, sin cortar el flujo de audio)
    /** Sube/baja el BPM mostrado (tempo de reproducción) en pasos finos, p. ej. ±0.01. */
    fun nudgeBpm(delta: Float) {
        val t = track ?: return
        if (t.bpm <= 0f) return
        val want = (currentBpm() + delta) / t.bpm
        val p = ((want - 1f) / range).coerceIn(-1f, 1f)
        pitch = p
    }

    /** Corrige el BPM de la REJILLA de la pista (análisis), manteniendo fijo el beat más cercano a la posición actual. */
    fun nudgeGridBpm(delta: Float) {
        val t = track ?: return
        if (t.bpm <= 0f) return
        val anchor = nearestBeat(pos)
        val k = round((anchor - t.firstBeatFrame) / t.beatLenFrames)
        t.beats = null; t.dynamicGrid = false
        t.bpm = (Math.round((t.bpm + delta) * 100f) / 100f).coerceIn(40f, 240f)
        t.firstBeatFrame = anchor - k * t.beatLenFrames
        gridBusy++; onGridEdit?.invoke()
    }

    /** Desplaza la rejilla `ms` milisegundos (positivo = más tarde). */
    fun shiftGridMs(ms: Double) {
        val t = track ?: return
        t.shiftGrid(ms / 1000.0 * t.srcRate)
        gridBusy++; onGridEdit?.invoke()
    }

    /** Marca la posición actual como un beat (primer tiempo): alinea la rejilla a donde estás. */
    fun setBeatHere() {
        val t = track ?: return
        val d = pos - nearestBeat(pos)
        t.shiftGrid(d)
        gridBusy++; onGridEdit?.invoke()
    }

    // ------------------------------------------------------------ carga
    fun load(t: LoadedTrack) {
        playing = false
        synchronized(lock) { scratchAcc = 0.0; pendingAdd = 0.0; pendingSeek = Double.NaN }
        speed = 0.0
        loopActive = false
        slipActive = false
        for (i in 0 until 8) hotCues[i] = -1.0
        val old = track
        if (old != null && old !== t) old.cancelled = true
        val start = if (t.firstBeatFrame in 0.0..(t.frames / 2.0)) t.firstBeatFrame else 0.0
        pos = start
        cuePoint = start
        pitch = 0f
        syncOn = false
        track = t
    }

    fun eject() {
        playing = false
        track = null
        pos = 0.0
        loopActive = false
        syncOn = false
    }

    // ------------------------------------------------------------ transporte
    /** Si SYNC está activo y el otro deck suena, el arranque espera al sub-beat exacto (cuantización 1/4 de beat). */
    private fun startQuantized(): Boolean {
        val t = track ?: return false
        val o = partner
        val ot0 = o?.track
        if (!syncOn || o == null || ot0 == null || !o.playing || o.launchWaiting || t.bpm <= 0f || ot0.bpm <= 0f) return false
        val ph = t.phaseAt(pos)
        val bl = t.beatLenAt(pos)
        val beatStart = pos - ph * bl
        val qph = round(ph * 4.0) / 4.0
        val qp = (beatStart + qph * bl).coerceIn(0.0, t.frames - 2.0)
        qPos = qp
        qPhase = qph - floor(qph)
        synchronized(lock) { pendingSeek = qp; pendingAdd = 0.0 }
        pos = qp
        qPending = true
        return true
    }

    fun playPause() {
        if (track == null) return
        if (qPending) {                                                      // espera de arranque cuantizado
            if (cuePreview) cuePreview = false else qPending = false          // CUE mantenido + PLAY: se engancha; si no, cancela
            return
        }
        if (!playing && startQuantized()) { cuePreview = false; return }
        if (cuePreview && playing) {
            // CUE mantenido + PLAY: la reproducción queda enganchada y sigue al soltar CUE
            cuePreview = false
            return
        }
        playing = !playing
        cuePreview = false
    }

    fun cueDown() {
        val t = track ?: return
        if (playing) {
            playing = false
            seekFrames(cuePoint)
        } else if (abs(pos - cuePoint) < t.srcRate * 0.03) {
            cuePreview = true
            if (!startQuantized()) playing = true
        } else {
            cuePoint = nearestBeat(pos).coerceIn(0.0, t.frames - 2.0)
            if (abs(cuePoint - pos) > t.srcRate * 0.2) cuePoint = pos
        }
    }

    fun cueUp() {
        if (qPending && cuePreview) { qPending = false; cuePreview = false; seekFrames(cuePoint); return }
        if (cuePreview) {
            cuePreview = false
            playing = false
            seekFrames(cuePoint)
        }
    }

    fun goToStart() { seekFrames(0.0); playing = false }

    fun seekFrames(f: Double) {
        val t = track ?: return
        synchronized(lock) { pendingSeek = f.coerceIn(0.0, t.frames - 2.0); pendingAdd = 0.0 }
    }

    fun seekFraction(fr: Float) {
        val t = track ?: return
        seekFrames(fr.coerceIn(0f, 1f) * t.frames.toDouble())
    }

    fun seekSeconds(deltaSec: Double) {
        val t = track ?: return
        synchronized(lock) { pendingAdd += deltaSec * t.srcRate }
    }

    // ------------------------------------------------------------ jog / scratch
    fun touchStart() { touched = true }
    fun touchEnd() { touched = false }

    /** Mueve el disco: segundos de audio (positivo = adelante). En vinilo = scratch, si no = pitch bend. */
    fun scratchSeconds(sec: Double) {
        val t = track ?: return
        if (vinyl && touched) {
            synchronized(lock) { scratchAcc += sec * t.srcRate }
        } else {
            bendVal = (bendVal + sec * 4.0).coerceIn(-0.4, 0.4)
        }
    }

    // ------------------------------------------------------------ hot cues
    fun hotCueDown(i: Int) {
        val t = track ?: return
        if (hotCues[i] < 0) {
            hotCues[i] = nearestBeat(pos).let { if (abs(it - pos) < t.srcRate * 0.15) it else pos }.coerceIn(0.0, t.frames - 2.0)
        } else {
            seekFrames(hotCues[i])
            if (!playing) { playing = true; padStarted = true }
        }
    }

    fun hotCueUp(i: Int) {
        if (padStarted) {
            padStarted = false
            playing = false
            if (hotCues[i] >= 0) seekFrames(hotCues[i])
        }
    }

    fun deleteHotCue(i: Int) { hotCues[i] = -1.0 }

    // ------------------------------------------------------------ loops
    fun setBeatLoop(beats: Double, quantize: Boolean = true) {
        val t = track ?: return
        loopBeats = beats
        val start = if (quantize) nearestBeat(pos) else pos
        loopInPos = start
        loopOutPos = start + beats * t.beatLenFrames
        loopActive = true
    }

    fun beatLoopToggle() { if (loopActive) loopActive = false else setBeatLoop(loopBeats) }
    fun loopHalve() { loopBeats = max(1.0 / 32, loopBeats / 2); if (loopActive) retimeLoop() }
    fun loopDouble() { loopBeats = min(64.0, loopBeats * 2); if (loopActive) retimeLoop() }
    private fun retimeLoop() {
        val t = track ?: return
        loopOutPos = loopInPos + loopBeats * t.beatLenFrames
    }

    fun loopInSet() { loopInPos = pos; if (loopActive) loopActive = false }
    fun loopOutSet() {
        if (pos > loopInPos + 100) { loopOutPos = pos; loopActive = true }
    }

    fun rollStart(beats: Double) {
        val t = track ?: return
        slipPos = pos
        slipActive = true
        loopBeats = beats
        loopInPos = pos
        loopOutPos = pos + beats * t.beatLenFrames
        loopActive = true
    }

    fun rollEnd() {
        if (!slipActive) return
        loopActive = false
        slipActive = false
        seekFrames(slipPos)
    }

    // ------------------------------------------------------------ sync / pitch
    fun userSetPitch(v: Float) { pitch = v.coerceIn(-1f, 1f); syncOn = false }

    fun cycleRange() {
        range = when {
            range < 0.1f -> 0.16f
            range < 0.2f -> 0.5f
            else -> 0.08f
        }
        pitch = pitch.coerceIn(-1f, 1f)
    }

    fun syncTo(other: Deck) {
        val t = track ?: return
        if (other.track == null) return
        val target = other.currentBpm()
        if (t.bpm <= 0f || target <= 0f) return
        val needed = target / t.bpm - 1f
        var r = range
        if (abs(needed) > r) r = listOf(0.08f, 0.16f, 0.5f).firstOrNull { abs(needed) <= it } ?: 0.5f
        range = r
        pitch = (needed / r).coerceIn(-1f, 1f)
        if (other.playing && playing) {
            var d = other.beatPhase() - beatPhase()
            if (d > 0.5) d -= 1.0
            if (d < -0.5) d += 1.0
            synchronized(lock) { pendingAdd += d * t.beatLenAt(pos) }
        }
        syncOn = true
    }

    /** Llamado por el motor cada bloque: un deck sincronizado sigue el tempo del otro. */
    fun followTempo(other: Deck) {
        val t = track
        if (t == null || qPending || !syncOn || other.track == null || other.syncOn || t.bpm <= 0f || other.currentBpm() <= 0f) { phaseTrim = 0.0; return }
        val needed = other.currentBpm() / t.bpm - 1f
        val p = (needed / range).coerceIn(-1f, 1f)
        if (abs(p - pitch) > 1e-4f) pitch = p
        // enganche de fase continuo (PLL): corrige derivas y cambios de tempo de la pista en tiempo real
        if (playing && other.playing && !touched) {
            var d = other.beatPhase() - beatPhase()
            if (d > 0.5) d -= 1.0
            if (d < -0.5) d += 1.0
            phaseTrim = if (abs(d) < 0.0015 || abs(d) > 0.45) 0.0 else (d * 0.03).coerceIn(-0.004, 0.004)
        } else phaseTrim = 0.0
    }

    /** Salto por beats (positivo = adelante). Mantiene la fase de la rejilla; en pausa se cuantiza al beat más cercano. */
    fun beatJump(beats: Double) {
        val t = track ?: return
        if (t.bpm <= 0f) { seekSeconds(beats * 0.5); return }
        val bl = t.beatLenAt(pos)
        val raw = pos + beats * bl
        val target = (if (playing) raw else nearestBeat(raw)).coerceIn(0.0, t.frames - 2.0)
        val delta = target - pos
        seekFrames(target)
        if (loopActive) { loopInPos += delta; loopOutPos += delta }
    }

    // ------------------------------------------------------------ Master Tempo (WSOLA)
    private var klL = 0f
    private var klR = 0f

    private fun grain(
        p: Double, sp: Double, ratio: Double, pcm: ShortArray, last: Int,
        loopOn: Boolean, lIn: Double, lOut: Double, lLen: Double
    ) {
        if (!klActive || hopCount >= hs) {
            val gLen = 2.0 * hs * ratio
            var pa = p + hs * (sp - ratio)                 // centro del grano = posición de transporte futura
            val prev = 1 - vNext
            if (klActive && vIdx[prev] >= 0 && !loopOn) {
                val ref = vSrc[prev] + hs * ratio          // continuación natural del grano anterior
                var best = pa
                var bestScore = -1e30f
                var c = -384
                while (c <= 384) {
                    val cand = pa + c
                    if (cand >= 1 && cand + gLen < last && ref >= 1 && ref + hs * ratio < last) {
                        var dot = 0f
                        var e = 1e-6f
                        var j = 0
                        while (j < hs) {
                            val a = pcm[2 * round(cand + j * ratio).toInt()].toFloat()
                            val b = pcm[2 * round(ref + j * ratio).toInt()].toFloat()
                            dot += a * b; e += a * a
                            j += 8
                        }
                        val score = dot / kotlin.math.sqrt(e)
                        if (score > bestScore) { bestScore = score; best = cand }
                    }
                    c += 4
                }
                pa = best
            }
            vSrc[vNext] = pa.coerceIn(1.0, max(1.0, last - gLen - 4.0))
            vIdx[vNext] = 0
            vNext = 1 - vNext
            hopCount = 0
            klActive = true
        }
        var l = 0f
        var r = 0f
        for (k in 0..1) {
            val idx = vIdx[k]
            if (idx < 0) continue
            var q = vSrc[k] + idx * ratio
            if (loopOn && q >= lOut) q = lIn + (q - lIn) % lLen
            val ip = floor(q).toInt()
            if (ip >= 1 && ip + 2 <= last) {
                val fr = (q - ip).toFloat()
                val w = win[idx]
                l += hermite(pcm[(ip - 1) * 2].toFloat(), pcm[ip * 2].toFloat(), pcm[(ip + 1) * 2].toFloat(), pcm[(ip + 2) * 2].toFloat(), fr) * w
                r += hermite(pcm[(ip - 1) * 2 + 1].toFloat(), pcm[ip * 2 + 1].toFloat(), pcm[(ip + 1) * 2 + 1].toFloat(), pcm[(ip + 2) * 2 + 1].toFloat(), fr) * w
            }
            vIdx[k] = if (idx + 1 >= hs * 2) -1 else idx + 1
        }
        hopCount++
        klL = l; klR = r
    }

    // ------------------------------------------------------------ render (hilo de audio)
    fun render(outL: FloatArray, outR: FloatArray, n: Int) {
        java.util.Arrays.fill(outL, 0, n, 0f)
        java.util.Arrays.fill(outR, 0, n, 0f)
        val t = track
        if (t == null) {
            level *= 0.85f
            java.util.Arrays.fill(preL, 0, n, 0f); java.util.Arrays.fill(preR, 0, n, 0f)
            return
        }

        val decoded = t.decodedFrames          // primero esto, luego el array (puede crecer en otro hilo)
        val pcm = t.pcm
        val frames = t.frames
        val complete = t.complete
        val limit = if (complete) frames - 1 else decoded - 4
        val ratio = t.srcRate.toDouble() / outRate
        val normalSpeed = ratio * tempoRate()
        // lanzamiento cuantizado: si el otro deck se detuvo, arrancamos ya
        var waiting = qPending
        val o = partner
        val ot = o?.track
        if (waiting && (o == null || !o.playing || ot == null)) { qPending = false; waiting = false; playing = true }
        var isPlaying = playing && !waiting
        var ph0 = 0.0; var dph = 0.0; var k0 = 0.0
        if (waiting && o != null && ot != null) {
            ph0 = ot.phaseAt(o.snapPos)
            dph = o.snapSpeed / ot.beatLenAt(o.snapPos)
            k0 = floor(ph0 - qPhase)
        }
        val bendNow = bendVal
        bendVal = bendNow * 0.96
        val scratching = touched && vinyl

        var p: Double
        var acc: Double
        var seeked: Boolean
        synchronized(lock) {
            p = pos
            seeked = false
            if (!pendingSeek.isNaN()) { p = pendingSeek; pendingSeek = Double.NaN; seeked = true }
            if (pendingAdd != 0.0) { p += pendingAdd; pendingAdd = 0.0; seeked = true }
            acc = scratchAcc; scratchAcc = 0.0
        }
        // Scratch: la cabeza de lectura SIGUE una posición objetivo con suavizado,
        // así el movimiento es continuo aunque los eventos del dedo/jog lleguen a ráfagas.
        if (scratching) {
            if (!wasScratching || seeked) scratchTgt = p
            scratchTgt += acc
        }
        wasScratching = scratching

        var target = if (isPlaying) normalSpeed * (1.0 + bendNow + phaseTrim) else 0.0
        if (waiting) { p = qPos; speed = 0.0 }
        val kl = keyLock && !scratching
        if (seeked || !kl) { klActive = false; vIdx[0] = -1; vIdx[1] = -1; hopCount = 0 }
        val kk = kNorm
        val kp = kScratch
        val loopOn = loopActive && loopOutPos > loopInPos + 64
        val lIn = loopInPos
        val lOut = loopOutPos
        val lLen = lOut - lIn
        var sp = speed
        val last = limit
        val minSp = ratio * 0.06
        val inv = 1f / 32768f

        for (i in 0 until n) {
            if (waiting) {
                // ¿el otro deck cruza justo ahora el sub-beat de arranque? entonces arrancamos en ESTA muestra, a velocidad plena
                if (floor(ph0 + dph * i - qPhase) > k0) {
                    waiting = false; qPending = false
                    isPlaying = true; playing = true
                    target = normalSpeed * (1.0 + bendNow + phaseTrim)
                    sp = target
                } else { outL[i] = 0f; outR[i] = 0f; continue }
            }
            if (scratching) {
                val np = p + (scratchTgt - p) * kp
                sp = np - p
            } else {
                sp += (target - sp) * kk
            }
            var l = 0f
            var r = 0f
            val asp = abs(sp)
            if (asp > 1e-7 && kl) {
                grain(p, sp, ratio, pcm, last, loopOn, lIn, lOut, lLen)
                var g = 1f
                if (!isPlaying) g = min(1.0, asp / (ratio * 0.3)).toFloat()
                l = klL * inv * g; r = klR * inv * g
                p += sp
                if (!complete && p >= last) { p = last.toDouble(); sp = 0.0 }
                if (loopOn) {
                    if (sp > 0 && p >= lOut) p = lIn + (p - lIn) % lLen
                    else if (sp < 0 && p < lIn) p += lLen
                }
            } else if (asp > 1e-7) {
                val ip = floor(p).toInt()
                if (ip >= 0 && ip < last) {
                    val fr = (p - ip).toFloat()
                    val i0 = if (ip > 0) ip - 1 else 0
                    val i2 = ip + 1
                    val i3 = if (ip + 2 <= last) ip + 2 else last
                    l = hermite(pcm[i0 * 2].toFloat(), pcm[ip * 2].toFloat(), pcm[i2 * 2].toFloat(), pcm[i3 * 2].toFloat(), fr) * inv
                    r = hermite(pcm[i0 * 2 + 1].toFloat(), pcm[ip * 2 + 1].toFloat(), pcm[i2 * 2 + 1].toFloat(), pcm[i3 * 2 + 1].toFloat(), fr) * inv
                    if (asp < minSp) { val g = (asp / minSp).toFloat(); l *= g; r *= g }
                }
                p += sp
                if (!complete && p >= last) { p = last.toDouble(); sp = 0.0 }
                if (loopOn && !scratching) {
                    if (sp > 0 && p >= lOut) p = lIn + (p - lIn) % lLen
                    else if (sp < 0 && p < lIn) p += lLen
                }
            }
            outL[i] = l
            outR[i] = r
        }
        speed = sp
        if (waiting) p = qPos

        if (slipActive && isPlaying) slipPos += normalSpeed * n
        if (p >= frames - 2) {
            p = frames - 2.0
            if (isPlaying) playing = false
            speed = 0.0
        }
        if (p < 0) { p = 0.0; speed = 0.0 }
        pos = p

        // ---- cadena de señal: trim -> EQ -> filtro -> FX -> fader
        val g = gain
        val gl = eqLow; val gm = eqMid; val gh = eqHigh
        for (i in 0 until n) {
            outL[i] = eqL.process(outL[i] * g, gl, gm, gh)
            outR[i] = eqR.process(outR[i] * g, gl, gm, gh)
        }
        val sm = stemMode
        if (sm != 0) {
            for (i in 0 until n) {
                val m = (outL[i] + outR[i]) * 0.5f
                stLow += stA * (m - stLow)
                val hi = m - stLow                       // centro sin graves: ahí vive la voz
                if (sm == 1) {                           // sin voz (aprox.): cancela el centro > 180 Hz
                    outL[i] -= 0.9f * hi; outR[i] -= 0.9f * hi
                } else {                                 // solo voz (aprox.): banda 180 Hz - 4.5 kHz del centro
                    stVoc += stB * (hi - stVoc)
                    val v = stVoc * 1.5f
                    outL[i] = v; outR[i] = v
                }
            }
        }
        val f = filter
        if (f < -0.03f) {
            val fc = 20000f * Math.pow(220.0 / 20000.0, (-f).toDouble()).toFloat()
            fltL.setup(fc, outRate, 1.1f); fltR.setup(fc, outRate, 1.1f)
            for (i in 0 until n) { outL[i] = fltL.lowpass(outL[i]); outR[i] = fltR.lowpass(outR[i]) }
        } else if (f > 0.03f) {
            val fc = 25f * Math.pow(9000.0 / 25.0, f.toDouble()).toFloat()
            fltL.setup(fc, outRate, 1.1f); fltR.setup(fc, outRate, 1.1f)
            for (i in 0 until n) { outL[i] = fltL.highpass(outL[i]); outR[i] = fltR.highpass(outR[i]) }
        }
        fx.process(outL, outR, n, fxType, fxAmount, max(40f, currentBpm()))

        System.arraycopy(outL, 0, preL, 0, n); System.arraycopy(outR, 0, preR, 0, n)
        val vol = volume
        var pk = 0f
        for (i in 0 until n) {
            val v = prevVol + (vol - prevVol) * ((i + 1f) / n)
            outL[i] *= v; outR[i] *= v
            val a = max(abs(outL[i]), abs(outR[i]))
            if (a > pk) pk = a
        }
        prevVol = vol
        level = max(pk, level * 0.88f)
    }
}

private fun hermite(y0: Float, y1: Float, y2: Float, y3: Float, x: Float): Float {
    val c1 = 0.5f * (y2 - y0)
    val c2 = y0 - 2.5f * y1 + 2f * y2 - 0.5f * y3
    val c3 = 0.5f * (y3 - y0) + 1.5f * (y1 - y2)
    return ((c3 * x + c2) * x + c1) * x + y1
}
