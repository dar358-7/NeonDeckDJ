package com.neondeck.dj.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

/** Zona táctil con animación de rebote y callbacks de pulsar/soltar (necesarios para CUE, pads, rolls...). */
@Composable
fun PressArea(
    modifier: Modifier = Modifier,
    onDown: () -> Unit,
    onUp: () -> Unit = {},
    content: @Composable (Boolean) -> Unit
) {
    var pressed by remember { mutableStateOf(false) }
    val down by rememberUpdatedState(onDown)
    val up by rememberUpdatedState(onUp)
    val scale by animateFloatAsState(
        if (pressed) 0.92f else 1f,
        spring(dampingRatio = 0.45f, stiffness = Spring.StiffnessMedium), label = "press"
    )
    Box(
        modifier
            .graphicsLayer { scaleX = scale; scaleY = scale }
            .pointerInput(Unit) {
                detectTapGestures(onPress = {
                    pressed = true
                    down()
                    try { tryAwaitRelease() } finally { pressed = false; up() }
                })
            }
    ) { content(pressed) }
}

/** Botón circular neón: oscuro en reposo; activo = borde, texto y resplandor del color del deck. */
@Composable
fun RoundButton(
    size: Dp,
    label: String,
    active: Boolean,
    activeColor: Color,
    onDown: () -> Unit,
    onUp: () -> Unit = {},
    fontSize: Int = 12
) {
    PressArea(Modifier.size(size).neonGlow(activeColor, active, 12.dp, size / 2, 0.9f), onDown, onUp) { pressed ->
        val top = if (active) activeColor.copy(alpha = 0.22f).compositeOver(Color(0xFF26262E)) else if (pressed) Color(0xFF35353F) else Color(0xFF2A2A31)
        val bottom = if (active) activeColor.copy(alpha = 0.10f).compositeOver(Color(0xFF101014)) else Color(0xFF131317)
        Box(
            Modifier.fillMaxSize().clip(CircleShape)
                .background(Brush.verticalGradient(listOf(top, bottom)))
                .border(2.dp, if (active || pressed) activeColor else Neon.Edge, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Text(
                label, color = if (active) activeColor else Color(0xFFE6E6EE), fontSize = fontSize.sp,
                fontWeight = FontWeight.Bold, letterSpacing = 0.5.sp
            )
        }
    }
}

@Composable
fun PlayButton(size: Dp, playing: Boolean, color: Color, onDown: () -> Unit) {
    PressArea(Modifier.size(size), onDown) { pressed ->
        Box(
            Modifier.fillMaxSize().clip(CircleShape)
                .background(
                    if (playing) Brush.verticalGradient(listOf(color, color))
                    else Brush.verticalGradient(listOf(Color(0xFF2A2A32), Color(0xFF111115)))
                )
                .border(2.dp, if (playing) color else if (pressed) color else Neon.Edge, CircleShape)
                .drawBehind {
                    val c = center
                    val s = this.size.minDimension * 0.17f
                    val ic = if (playing) onNeon(color) else color
                    if (playing) {
                        drawRoundRect(ic, Offset(c.x - s * 0.95f, c.y - s), Size(s * 0.7f, s * 2f), CornerRadius(2f))
                        drawRoundRect(ic, Offset(c.x + s * 0.25f, c.y - s), Size(s * 0.7f, s * 2f), CornerRadius(2f))
                    } else {
                        val p = Path().apply {
                            moveTo(c.x - s * 0.7f, c.y - s * 1.1f)
                            lineTo(c.x + s * 1.2f, c.y)
                            lineTo(c.x - s * 0.7f, c.y + s * 1.1f)
                            close()
                        }
                        drawPath(p, ic)
                    }
                }
        )
    }
}

/** Icono de ecualizador (tres fader) usado para abrir el mezclador. */
@Composable
fun MixerButton(size: Dp, onClick: () -> Unit) {
    val click by rememberUpdatedState(onClick)
    PressArea(Modifier.size(size), onDown = { click() }) { pressed ->
        Box(
            Modifier.fillMaxSize().clip(CircleShape)
                .background(if (pressed) Neon.Panel2 else Color(0xFF232327))
                .drawBehind {
                    val w = this.size.width; val h = this.size.height
                    val xs = floatArrayOf(0.34f, 0.5f, 0.66f)
                    val ys = floatArrayOf(0.62f, 0.4f, 0.55f)
                    for (i in 0..2) {
                        drawLine(Color(0xFFBBBBC0), Offset(w * xs[i], h * 0.28f), Offset(w * xs[i], h * 0.72f), 3f, StrokeCap.Round)
                        drawRoundRect(Color.White, Offset(w * xs[i] - 6f, h * ys[i] - 3f), Size(12f, 6f), CornerRadius(2f))
                    }
                }
        )
    }
}

/**
 * Fader vertical (0 abajo .. 1 arriba) con asa estilo hardware.
 * Una marca horizontal en el centro indica la posición del BPM original de la pista.
 */
@Composable
fun VFader(
    value: Float,
    onChange: (Float) -> Unit,
    modifier: Modifier = Modifier,
    thumbHeight: Dp = 28.dp,
    accent: Color = Color.White,
    tickColor: Color = Color(0xFFE5E7EB)
) {
    val change by rememberUpdatedState(onChange)
    Canvas(
        modifier.pointerInput(Unit) {
            fun set(y: Float) {
                val th = thumbHeight.toPx()
                val v = 1f - ((y - th / 2f) / (size.height - th))
                change(v.coerceIn(0f, 1f))
            }
            detectDragGestures(onDragStart = { set(it.y) }) { c, _ -> set(c.position.y); c.consume() }
        }
    ) {
        val th = thumbHeight.toPx()
        val w = size.width
        val cx = w / 2f
        // ranura
        drawRoundRect(Color(0xFF14151D), Offset(cx - 5f, 0f), Size(10f, size.height), CornerRadius(5f))
        drawRoundRect(Color(0xFF262838), Offset(cx - 5f, 0f), Size(10f, size.height), CornerRadius(5f), style = Stroke(1.5f))
        // marca central = BPM original (a ambos lados del asa para que siempre se vea)
        val my = size.height / 2f
        drawLine(tickColor, Offset(0f, my), Offset(w * 0.14f, my), 3f, StrokeCap.Round)
        drawLine(tickColor, Offset(w * 0.86f, my), Offset(w, my), 3f, StrokeCap.Round)
        drawLine(tickColor.copy(alpha = 0.55f), Offset(cx - 9f, my), Offset(cx + 9f, my), 2f, StrokeCap.Round)
        // asa
        val y = (1f - value.coerceIn(0f, 1f)) * (size.height - th)
        val tl = Offset(w * 0.15f, y)
        val tw = w * 0.7f
        drawRoundRect(
            Brush.verticalGradient(listOf(Color(0xFFF4F4F8), Color(0xFFB9BBC6)), startY = y, endY = y + th),
            tl, Size(tw, th), CornerRadius(7f)
        )
        drawRoundRect(accent.copy(alpha = 0.9f), Offset(tl.x + tw * 0.14f, y + th / 2f - 1.5f), Size(tw * 0.72f, 3f), CornerRadius(2f))
    }
}

/** Crossfader horizontal sencillo: carril oscuro y asa clara con línea central. Doble toque = centro. */
@Composable
fun Crossfader(value: Float, onChange: (Float) -> Unit, modifier: Modifier = Modifier) {
    val change by rememberUpdatedState(onChange)
    Canvas(
        modifier.pointerInput(Unit) {
            fun set(x: Float) {
                val tw = 44.dp.toPx()
                change(((x - tw / 2f) / (size.width - tw)).coerceIn(0f, 1f))
            }
            detectDragGestures(onDragStart = { set(it.x) }) { c, _ -> set(c.position.x); c.consume() }
        }.pointerInput(Unit) {
            detectTapGestures(onDoubleTap = { change(0.5f) })
        }
    ) {
        val h = size.height
        val tw = 44.dp.toPx()
        drawRoundRect(Color(0xFF0A0A0C), Offset(0f, h * 0.22f), Size(size.width, h * 0.56f), CornerRadius(h * 0.28f))
        drawRoundRect(Color(0xFF2A2A30), Offset(0f, h * 0.22f), Size(size.width, h * 0.56f), CornerRadius(h * 0.28f), style = Stroke(2f))
        val x = value.coerceIn(0f, 1f) * (size.width - tw) + tw / 2f
        val tx = x - tw / 2f
        drawRoundRect(Color(0xFFD9D9DE), Offset(tx, 3f), Size(tw, h - 6f), CornerRadius(8f))
        drawLine(Color(0xFF3A3A44), Offset(tx + tw / 2f, h * 0.2f), Offset(tx + tw / 2f, h * 0.8f), 3f, StrokeCap.Round)
    }
}

/** Vúmetro de LEDs verticales (verde -> amarillo -> rojo). */
@Composable
fun LedMeter(level: () -> Float, frame: State<Long>, modifier: Modifier = Modifier, segments: Int = 18) {
    Canvas(modifier) {
        @Suppress("UNUSED_VARIABLE") val f = frame.value
        val lv = level().coerceIn(0f, 1f)
        val gap = 2f
        val h = (size.height - gap * (segments - 1)) / segments
        val lit = (lv * segments + 0.3f).toInt()
        for (i in 0 until segments) {
            val y = size.height - (i + 1) * h - i * gap
            val on = i < lit
            val base = when {
                i >= segments - 2 -> Neon.Red
                i >= segments - 6 -> Neon.Yellow
                else -> Neon.Green
            }
            drawRoundRect(if (on) base else base.copy(alpha = 0.16f), Offset(0f, y), Size(size.width, h), CornerRadius(1.5f))
        }
    }
}

/** Potenciómetro rotativo: arrastra verticalmente; doble toque = valor por defecto. */
@Composable
fun Knob(
    value: Float,
    min: Float,
    max: Float,
    default: Float,
    label: String,
    color: Color,
    onChange: (Float) -> Unit,
    size: Dp = 50.dp,
    bipolarCenter: Boolean = false
) {
    val change by rememberUpdatedState(onChange)
    val curValue by rememberUpdatedState(value)
    Box(Modifier.size(size + 18.dp, size + 18.dp), contentAlignment = Alignment.TopCenter) {
        Canvas(
            Modifier.size(size)
                .pointerInput(Unit) {
                    detectDragGestures { c, drag ->
                        val nv = curValue - drag.y / 220f * (max - min)
                        change(nv.coerceIn(min, max))
                        c.consume()
                    }
                }
                .pointerInput(Unit) { detectTapGestures(onDoubleTap = { change(default) }) }
        ) {
            val r = this.size.minDimension / 2f
            val sw = r * 0.16f
            val start = 135f
            val sweep = 270f
            val tl = Offset(sw, sw)
            val sz = Size(this.size.width - 2 * sw, this.size.height - 2 * sw)
            drawArc(Color(0xFF2A2A30), start, sweep, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            val frac = ((curValue - min) / (max - min)).coerceIn(0f, 1f)
            if (bipolarCenter) {
                val mid = 0.5f
                val a0 = start + sweep * minOf(mid, frac)
                val sp = sweep * abs(frac - mid)
                drawArc(color, a0, sp, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            } else {
                drawArc(color, start, sweep * frac, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
            drawCircle(Color(0xFF1B1B20), r * 0.62f, center)
            val ang = (start + sweep * frac) * PI.toFloat() / 180f
            drawLine(
                Color.White, Offset(center.x + cos(ang) * r * 0.2f, center.y + sin(ang) * r * 0.2f),
                Offset(center.x + cos(ang) * r * 0.58f, center.y + sin(ang) * r * 0.58f), 3f, StrokeCap.Round
            )
        }
        Text(
            label, color = Neon.Gray, fontSize = 9.sp, fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center, modifier = Modifier.align(Alignment.BottomCenter)
        )
    }
}

fun Modifier.panel(color: Color = Neon.Panel, radius: Int = 12): Modifier =
    this.clip(RoundedCornerShape(radius.dp)).background(color)
