package com.neondeck.dj.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Environment
import android.os.Process
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh

/** Mezclador + salida de audio de baja latencia. */
class AudioEngine(private val ctx: Context) {

    val outRate: Int
    val blockFrames: Int
    val deckA: Deck
    val deckB: Deck
    val sampler: Sampler
    val recorder: Recorder

    // ---- estado del mezclador (visible a la UI y al MIDI)
    var crossfader by mutableFloatStateOf(0.5f)      // 0 = A, 1 = B
    var crossfaderCurve by mutableIntStateOf(0)      // 0 mix, 1 corte (scratch), 2 potencia constante
    var masterGain by mutableFloatStateOf(0.85f)
    var headphoneSplit by mutableStateOf(false)      // L = cue, R = master (cable splitter)
    var recording by mutableStateOf(false)

    @Volatile var masterLevelL = 0f
    @Volatile var masterLevelR = 0f
    @Volatile var underruns = 0

    private var audioTrack: AudioTrack? = null
    private var thread: Thread? = null
    @Volatile private var running = false

    init {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        outRate = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        val fpb = am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256
        blockFrames = fpb.coerceIn(128, 1024)
        deckA = Deck(0, outRate)
        deckB = Deck(1, outRate)
        sampler = Sampler(outRate)
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir
        recorder = Recorder(outRate, File(dir, "Recordings"))
    }

    fun deck(i: Int) = if (i == 0) deckA else deckB
    fun other(d: Deck) = if (d.index == 0) deckB else deckA

    fun start() {
        if (running) return
        val minBuf = AudioTrack.getMinBufferSize(outRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT)
        val bufBytes = max(minBuf, blockFrames * 2 * 4 * 3)
        val at = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(outRate)
                    .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufBytes)
            .build()
        audioTrack = at
        running = true
        at.play()
        thread = Thread({ loop(at) }, "dj-audio").also { it.start() }
    }

    fun stop() {
        running = false
        thread?.join(1000)
        thread = null
        audioTrack?.let { try { it.stop() } catch (_: Exception) { }; it.release() }
        audioTrack = null
        if (recorder.recording) { recorder.stop(); recording = false }
    }

    fun toggleRecording(): File? {
        return if (recorder.recording) {
            recording = false
            recorder.stop()
        } else {
            recording = true
            recorder.start()
        }
    }

    // -------------------------------------------------------------- render loop
    private fun loop(at: AudioTrack) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val n = blockFrames
        val aL = FloatArray(n); val aR = FloatArray(n)
        val bL = FloatArray(n); val bR = FloatArray(n)
        val mL = FloatArray(n); val mR = FloatArray(n)
        val cL = FloatArray(n)
        val out = FloatArray(n * 2)
        var prevGA = 0f; var prevGB = 0f
        var first = true
        var prevMaster = masterGain
        var lastUnderruns = 0

        while (running) {
            deckA.followTempo(deckB)
            deckB.followTempo(deckA)
            deckA.render(aL, aR, n)
            deckB.render(bL, bR, n)

            val (gA, gB) = crossGains(crossfader, crossfaderCurve)
            if (first) { prevGA = gA; prevGB = gB; first = false }
            val mg = masterGain
            val cueA = deckA.pfl; val cueB = deckB.pfl
            java.util.Arrays.fill(mL, 0f); java.util.Arrays.fill(mR, 0f)
            for (i in 0 until n) {
                val t = (i + 1f) / n
                val ga = prevGA + (gA - prevGA) * t
                val gb = prevGB + (gB - prevGB) * t
                mL[i] = aL[i] * ga + bL[i] * gb
                mR[i] = aR[i] * ga + bR[i] * gb
                cL[i] = (if (cueA) (aL[i] + aR[i]) * 0.5f else 0f) + (if (cueB) (bL[i] + bR[i]) * 0.5f else 0f)
            }
            prevGA = gA; prevGB = gB
            sampler.render(mL, mR, n)

            var pl = 0f; var pr = 0f
            val split = headphoneSplit
            val anyCue = cueA || cueB
            for (i in 0 until n) {
                val g = prevMaster + (mg - prevMaster) * ((i + 1f) / n)
                val l = softClip(mL[i] * g)
                val r = softClip(mR[i] * g)
                mL[i] = l; mR[i] = r
                if (abs(l) > pl) pl = abs(l)
                if (abs(r) > pr) pr = abs(r)
                if (split) {
                    val master = (l + r) * 0.5f
                    out[2 * i] = if (anyCue) softClip(cL[i]) else master
                    out[2 * i + 1] = master
                } else {
                    out[2 * i] = l; out[2 * i + 1] = r
                }
            }
            prevMaster = mg
            masterLevelL = max(pl, masterLevelL * 0.88f)
            masterLevelR = max(pr, masterLevelR * 0.88f)
            recorder.feed(mL, mR, n)

            val w = at.write(out, 0, n * 2, AudioTrack.WRITE_BLOCKING)
            if (w < 0) break
            val u = at.underrunCount
            if (u != lastUnderruns) { underruns = u; lastUnderruns = u }
        }
    }

    private fun softClip(x: Float): Float {
        val a = abs(x)
        if (a < 0.8f) return x
        val y = 0.8f + 0.2f * tanh((a - 0.8f) / 0.2f)
        return if (x < 0) -y else y
    }

    companion object {
        /** Curvas del crossfader. x: 0 = deck A, 1 = deck B. */
        fun crossGains(x: Float, curve: Int): Pair<Float, Float> = when (curve) {
            1 -> Pair(min(1f, (1f - x) * 12f), min(1f, x * 12f))
            2 -> Pair(cos(x * PI.toFloat() / 2f), sin(x * PI.toFloat() / 2f))
            else -> Pair(min(1f, (1f - x) * 2f), min(1f, x * 2f))
        }
    }
}
