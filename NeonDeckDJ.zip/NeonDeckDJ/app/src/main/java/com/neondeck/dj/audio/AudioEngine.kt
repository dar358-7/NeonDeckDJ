package com.neondeck.dj.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioTrack
import android.os.Environment
import android.os.Process
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.io.File
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tanh

/** Una salida de audio disponible (altavoz, cable, USB, Bluetooth…). */
class AudioOut(val key: String, val label: String, val info: AudioDeviceInfo)

/** Mezclador + salida de audio de baja latencia. */
class AudioEngine(private val ctx: Context) {

    val outRate: Int
    val blockFrames: Int
    val deckA: Deck
    val deckB: Deck
    val sampler: Sampler
    val recorder: Recorder

    // ---- estado del mezclador (visible a la UI y al MIDI)
    var crossfader by mutableFloatStateOf(0.5f)      // 0 = A, 1 = B
    var crossfaderCurve by mutableIntStateOf(0)      // 0 mix, 1 corte (scratch), 2 potencia constante
    var masterGain by mutableFloatStateOf(0.85f)
    var headphoneSplit by mutableStateOf(false)      // L = cue, R = master (cable splitter)
    var recording by mutableStateOf(false)

    // ---- salidas: principal y pre-escucha (auriculares) en dispositivos distintos
    var outputs by mutableStateOf<List<AudioOut>>(emptyList())
    var masterKey by mutableStateOf("")              // "" = automático (el sistema decide)
    var cueKey by mutableStateOf("")                 // "" = sin salida de pre-escucha propia
    var cueVolume by mutableFloatStateOf(0.9f)
    var cueMix by mutableFloatStateOf(0f)            // 0 = solo cue, 1 = solo master en los auriculares
    @Volatile private var cueTrack: AudioTrack? = null
    /** true cuando la salida es de 4 canales hacia el controlador USB: 1-2 = master, 3-4 = auriculares. */
    var quadActive by mutableStateOf(false)
    var quadStatus by mutableStateOf("")
    private var lastQuadAttempt = false
    private val am: AudioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val deviceCb = object : AudioDeviceCallback() {
        override fun onAudioDevicesAdded(added: Array<out AudioDeviceInfo>?) { refreshOutputs(); applyOutputs() }
        override fun onAudioDevicesRemoved(removed: Array<out AudioDeviceInfo>?) { refreshOutputs(); applyOutputs() }
    }

    @Volatile var masterLevelL = 0f
    @Volatile var masterLevelR = 0f
    @Volatile var underruns = 0

    private var audioTrack: AudioTrack? = null
    private var thread: Thread? = null
    @Volatile private var running = false

    init {
        val am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        outRate = am.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE)?.toIntOrNull() ?: 48000
        val fpb = am.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER)?.toIntOrNull() ?: 256
        blockFrames = fpb.coerceIn(128, 1024)
        deckA = Deck(0, outRate)
        deckB = Deck(1, outRate)
        sampler = Sampler(outRate)
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MUSIC) ?: ctx.filesDir
        recorder = Recorder(outRate, File(dir, "Recordings"))
    }

    private fun typeLabel(t: Int): String? = when (t) {
        AudioDeviceInfo.TYPE_BUILTIN_SPEAKER -> "Altavoz del teléfono"
        AudioDeviceInfo.TYPE_WIRED_HEADPHONES, AudioDeviceInfo.TYPE_WIRED_HEADSET -> "Cable / auriculares (jack)"
        AudioDeviceInfo.TYPE_USB_DEVICE, AudioDeviceInfo.TYPE_USB_HEADSET, AudioDeviceInfo.TYPE_USB_ACCESSORY -> "USB"
        AudioDeviceInfo.TYPE_BLUETOOTH_A2DP -> "Bluetooth"
        AudioDeviceInfo.TYPE_HDMI -> "HDMI"
        AudioDeviceInfo.TYPE_LINE_ANALOG, AudioDeviceInfo.TYPE_LINE_DIGITAL, AudioDeviceInfo.TYPE_AUX_LINE -> "Línea"
        AudioDeviceInfo.TYPE_DOCK -> "Dock"
        else -> if (android.os.Build.VERSION.SDK_INT >= 31 &&
            (t == AudioDeviceInfo.TYPE_BLE_HEADSET || t == AudioDeviceInfo.TYPE_BLE_SPEAKER || t == AudioDeviceInfo.TYPE_BLE_BROADCAST)
        ) "Bluetooth LE" else null
    }

    fun refreshOutputs() {
        val list = ArrayList<AudioOut>()
        for (d in am.getDevices(AudioManager.GET_DEVICES_OUTPUTS)) {
            val tl = typeLabel(d.type) ?: continue
            val name = d.productName?.toString()?.takeIf { it.isNotBlank() }
            val addr = if (android.os.Build.VERSION.SDK_INT >= 28) d.address else ""
            val label = if (name != null && d.type != AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) "$tl · $name" else tl
            list.add(AudioOut("${d.type}|${name ?: ""}|$addr", label, d))
        }
        outputs = list
    }

    private fun find(key: String): AudioOut? =
        if (key.isEmpty()) null else outputs.firstOrNull { it.key == key }
            ?: outputs.firstOrNull { it.key.substringBefore('|') == key.substringBefore('|') && key.substringBefore('|') != "" &&
                it.key.split('|').getOrNull(1) == key.split('|').getOrNull(1) }

    /** Aplica la salida principal y la de pre-escucha elegidas (se puede llamar en caliente). */
    fun applyOutputs() {
        val wq = wantQuad()
        if (running && wq != lastQuadAttempt) {
            stopOutput()
            startOutput(wq)
        }
        try { audioTrack?.setPreferredDevice(find(masterKey)?.info) } catch (_: Exception) { }
        val cue = if (cueKey == CUE_CH34) null else find(cueKey)
        if (cue == null) {
            val old = cueTrack
            cueTrack = null
            if (old != null) try { old.stop(); old.release() } catch (_: Exception) { }
        } else {
            var ct = cueTrack
            if (ct == null) {
                ct = try { buildTrack(false).also { it.play() } } catch (_: Exception) { null }
                cueTrack = ct
            }
            try { ct?.setPreferredDevice(cue.info) } catch (_: Exception) { }
        }
    }

    private fun buildTrack(lowLatency: Boolean, channels: Int = 2): AudioTrack {
        val minBuf = if (channels == 2) AudioTrack.getMinBufferSize(outRate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_FLOAT) else 0
        val bufBytes = max(minBuf, blockFrames * channels * 4 * (if (lowLatency) 3 else 8))
        val fmt = AudioFormat.Builder().setSampleRate(outRate).setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
        if (channels == 2) fmt.setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
        else fmt.setChannelIndexMask((1 shl channels) - 1)       // canales 1..4 del dispositivo USB tal cual
        return AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
            )
            .setAudioFormat(fmt.build())
            .setPerformanceMode(if (lowLatency) AudioTrack.PERFORMANCE_MODE_LOW_LATENCY else AudioTrack.PERFORMANCE_MODE_NONE)
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setBufferSizeInBytes(bufBytes)
            .build()
    }

    fun deck(i: Int) = if (i == 0) deckA else deckB
    fun other(d: Deck) = if (d.index == 0) deckB else deckA

    private fun isUsb(o: AudioOut) = o.info.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
        o.info.type == AudioDeviceInfo.TYPE_USB_HEADSET || o.info.type == AudioDeviceInfo.TYPE_USB_ACCESSORY

    fun firstUsb(): AudioOut? = outputs.firstOrNull { isUsb(it) }
    fun masterIsUsb(): Boolean = find(masterKey)?.let { isUsb(it) } == true

    /** ¿Se pide la salida de 4 canales y el dispositivo USB la ofrece? */
    private fun wantQuad(): Boolean {
        if (cueKey != CUE_CH34) return false
        val m = find(masterKey) ?: return false
        if (!isUsb(m)) return false
        val cc = m.info.channelCounts
        return cc.isEmpty() || cc.any { it >= 4 }
    }

    private fun startOutput(quad: Boolean) {
        lastQuadAttempt = quad
        var chn = 2
        var at: AudioTrack? = null
        if (quad) {
            at = try { buildTrack(true, 4).takeIf { it.state == AudioTrack.STATE_INITIALIZED } } catch (_: Throwable) { null }
            if (at != null) { chn = 4; quadStatus = "" }
            else quadStatus = "este teléfono no abrió 4 canales en ese dispositivo; se usa estéreo"
        }
        if (at == null) at = buildTrack(true, 2)
        audioTrack = at
        quadActive = chn == 4
        running = true
        at.play()
        try { at.setPreferredDevice(find(masterKey)?.info) } catch (_: Exception) { }
        val track = at
        thread = Thread({ loop(track, chn) }, "dj-audio").also { it.start() }
    }

    private fun stopOutput() {
        running = false
        thread?.join(1000)
        thread = null
        audioTrack?.let { try { it.stop() } catch (_: Exception) { }; it.release() }
        audioTrack = null
    }

    fun start() {
        if (running) return
        refreshOutputs()
        try { am.registerAudioDeviceCallback(deviceCb, null) } catch (_: Exception) { }
        startOutput(wantQuad())
        applyOutputs()
    }

    fun stop() {
        try { am.unregisterAudioDeviceCallback(deviceCb) } catch (_: Exception) { }
        stopOutput()
        cueTrack?.let { try { it.stop() } catch (_: Exception) { }; it.release() }
        cueTrack = null
        if (recorder.recording) { recorder.stop(); recording = false }
    }

    fun toggleRecording(): File? {
        return if (recorder.recording) {
            recording = false
            recorder.stop()
        } else {
            recording = true
            recorder.start()
        }
    }

    // -------------------------------------------------------------- render loop
    private fun loop(at: AudioTrack, chn: Int) {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)
        val n = blockFrames
        val aL = FloatArray(n); val aR = FloatArray(n)
        val bL = FloatArray(n); val bR = FloatArray(n)
        val mL = FloatArray(n); val mR = FloatArray(n)
        val cL = FloatArray(n)
        val out = FloatArray(n * chn)
        val cueOut = FloatArray(n * 2)
        var prevGA = 0f; var prevGB = 0f
        var first = true
        var prevMaster = masterGain
        var lastUnderruns = 0

        while (running) {
            deckA.followTempo(deckB)
            deckB.followTempo(deckA)
            deckA.render(aL, aR, n)
            deckB.render(bL, bR, n)

            val (gA, gB) = crossGains(crossfader, crossfaderCurve)
            if (first) { prevGA = gA; prevGB = gB; first = false }
            val mg = masterGain
            val cueA = deckA.pfl; val cueB = deckB.pfl
            java.util.Arrays.fill(mL, 0f); java.util.Arrays.fill(mR, 0f)
            for (i in 0 until n) {
                val t = (i + 1f) / n
                val ga = prevGA + (gA - prevGA) * t
                val gb = prevGB + (gB - prevGB) * t
                mL[i] = aL[i] * ga + bL[i] * gb
                mR[i] = aR[i] * ga + bR[i] * gb
                cL[i] = (if (cueA) (aL[i] + aR[i]) * 0.5f else 0f) + (if (cueB) (bL[i] + bR[i]) * 0.5f else 0f)
            }
            prevGA = gA; prevGB = gB
            sampler.render(mL, mR, n)

            var pl = 0f; var pr = 0f
            val ct = cueTrack
            val split = headphoneSplit && ct == null && chn == 2
            val cv = cueVolume; val cm = cueMix
            val anyCue = cueA || cueB
            for (i in 0 until n) {
                val g = prevMaster + (mg - prevMaster) * ((i + 1f) / n)
                val l = softClip(mL[i] * g)
                val r = softClip(mR[i] * g)
                mL[i] = l; mR[i] = r
                if (abs(l) > pl) pl = abs(l)
                if (abs(r) > pr) pr = abs(r)
                if (split) {
                    val master = (l + r) * 0.5f
                    out[2 * i] = if (anyCue) softClip(cL[i]) else master
                    out[2 * i + 1] = master
                } else {
                    out[2 * i] = l; out[2 * i + 1] = r
                }
            }
            prevMaster = mg
            masterLevelL = max(pl, masterLevelL * 0.88f)
            masterLevelR = max(pr, masterLevelR * 0.88f)
            recorder.feed(mL, mR, n)

            if (ct != null) {
                // pre-escucha: cue (o master si no hay PFL) por su propia salida, sin bloquear el hilo principal
                for (i in 0 until n) {
                    val l = mL[i]; val r = mR[i]
                    if (anyCue) {
                        val c = cL[i] * (1f - cm) + (l + r) * 0.5f * cm
                        val x = softClip(c) * cv
                        cueOut[2 * i] = x; cueOut[2 * i + 1] = x
                    } else {
                        cueOut[2 * i] = l * cv; cueOut[2 * i + 1] = r * cv
                    }
                }
                try { ct.write(cueOut, 0, n * 2, AudioTrack.WRITE_NON_BLOCKING) } catch (_: Exception) { }
            }
            if (chn == 4) {
                // controlador USB: canales 1-2 = master, 3-4 = auriculares (cue o mezcla)
                for (i in 0 until n) {
                    val l = mL[i]; val r = mR[i]
                    val cl: Float; val cr: Float
                    if (anyCue) {
                        val c = softClip(cL[i] * (1f - cm) + (l + r) * 0.5f * cm) * cv
                        cl = c; cr = c
                    } else { cl = l * cv; cr = r * cv }
                    out[4 * i] = l; out[4 * i + 1] = r; out[4 * i + 2] = cl; out[4 * i + 3] = cr
                }
            }
            val w = at.write(out, 0, n * chn, AudioTrack.WRITE_BLOCKING)
            if (w < 0) break
            val u = at.underrunCount
            if (u != lastUnderruns) { underruns = u; lastUnderruns = u }
        }
    }

    private fun softClip(x: Float): Float {
        val a = abs(x)
        if (a < 0.8f) return x
        val y = 0.8f + 0.2f * tanh((a - 0.8f) / 0.2f)
        return if (x < 0) -y else y
    }

    companion object {
        const val CUE_CH34 = "ch34"

        /** Curvas del crossfader. x: 0 = deck A, 1 = deck B. */
        fun crossGains(x: Float, curve: Int): Pair<Float, Float> = when (curve) {
            1 -> Pair(min(1f, (1f - x) * 12f), min(1f, x * 12f))
            2 -> Pair(cos(x * PI.toFloat() / 2f), sin(x * PI.toFloat() / 2f))
            else -> Pair(min(1f, (1f - x) * 2f), min(1f, x * 2f))
        }
    }
}
