package com.neondeck.dj.audio

import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.floor
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.tan
import kotlin.math.round

/** EQ de 3 bandas sin fase (graves <250 Hz, medios, agudos >2.5 kHz); ganancia 0 = kill. */
class EqChannel(sr: Int) {
    private val aL = (1.0 - exp(-2.0 * PI * 250.0 / sr)).toFloat()
    private val aH = (1.0 - exp(-2.0 * PI * 2500.0 / sr)).toFloat()
    private var l1 = 0f; private var l2 = 0f; private var h1 = 0f; private var h2 = 0f
    fun process(x: Float, gl: Float, gm: Float, gh: Float): Float {
        l1 += aL * (x - l1); l2 += aL * (l1 - l2)
        h1 += aH * (x - h1); h2 += aH * (h1 - h2)
        return l2 * gl + (h2 - l2) * gm + (x - h2) * gh
    }
}

/** Filtro de barrido (LP a la izquierda del centro, HP a la derecha), SVF TPT. */
class SweepFilter {
    private var ic1 = 0f; private var ic2 = 0f
    private var a1 = 0f; private var a2 = 0f; private var a3 = 0f; private var k = 1f
    fun setup(fc: Float, sr: Int, q: Float) {
        val g = tan(PI.toFloat() * min(fc, sr * 0.45f) / sr)
        k = 1f / q
        a1 = 1f / (1f + g * (g + k)); a2 = g * a1; a3 = g * a2
    }
    fun lowpass(v0: Float): Float {
        val v3 = v0 - ic2
        val v1 = a1 * ic1 + a2 * v3
        val v2 = ic2 + a2 * ic1 + a3 * v3
        ic1 = 2f * v1 - ic1; ic2 = 2f * v2 - ic2
        return v2
    }
    fun highpass(v0: Float): Float {
        val v3 = v0 - ic2
        val v1 = a1 * ic1 + a2 * v3
        val v2 = ic2 + a2 * ic1 + a3 * v3
        ic1 = 2f * v1 - ic1; ic2 = 2f * v2 - ic2
        return v0 - k * v1 - v2
    }
}

private class Comb(size: Int) {
    private val buf = FloatArray(size); private var idx = 0; private var store = 0f
    fun process(x: Float, fb: Float, damp: Float): Float {
        val o = buf[idx]
        store = o * (1f - damp) + store * damp
        buf[idx] = x + store * fb
        if (++idx >= buf.size) idx = 0
        return o
    }
}

private class Allpass(size: Int) {
    private val buf = FloatArray(size); private var idx = 0
    fun process(x: Float): Float {
        val b = buf[idx]
        val o = -x + b
        buf[idx] = x + b * 0.5f
        if (++idx >= buf.size) idx = 0
        return o
    }
}

/** Unidad de efectos por deck: 1 = Echo (beat sync), 2 = Flanger, 3 = Reverb. */
class FxUnit(private val sr: Int) {
    private val echoSize = sr * 2
    private val echoL = FloatArray(echoSize)
    private val echoR = FloatArray(echoSize)
    private var echoW = 0

    private val flSize = (sr * 0.02).toInt() + 8
    private val flL = FloatArray(flSize)
    private val flR = FloatArray(flSize)
    private var flW = 0
    private var lfo = 0.0

    private val scale = sr / 44100f
    private val combsL = intArrayOf(1116, 1188, 1277, 1356).map { Comb((it * scale).toInt()) }
    private val combsR = intArrayOf(1139, 1211, 1300, 1379).map { Comb((it * scale).toInt()) }
    private val apL = intArrayOf(556, 441).map { Allpass((it * scale).toInt()) }
    private val apR = intArrayOf(579, 464).map { Allpass((it * scale).toInt()) }

    private var lastType = 0

    // estado de los efectos nuevos
    private val phZ = FloatArray(8)            // 4 etapas all-pass x 2 canales
    private var phLfo = 0.0
    private var holdCnt = 0
    private var heldL = 0f
    private var heldR = 0f
    private var gateN = 0L
    private var gateEnv = 1f
    private var panLfo = 0.0

    fun process(l: FloatArray, r: FloatArray, n: Int, type: Int, amount: Float, bpm: Float) {
        if (type != lastType) {
            echoL.fill(0f); echoR.fill(0f); flL.fill(0f); flR.fill(0f); phZ.fill(0f); holdCnt = 0; gateN = 0; gateEnv = 1f
            lastType = type
        }
        if (type == 0 || amount <= 0.001f) return
        when (type) {
            1 -> echo(l, r, n, amount, bpm)
            2 -> flanger(l, r, n, amount)
            3 -> reverb(l, r, n, amount)
            4 -> pingPong(l, r, n, amount, bpm)
            5 -> phaser(l, r, n, amount)
            6 -> crush(l, r, n, amount)
            7 -> gate(l, r, n, amount, bpm)
            8 -> autoPan(l, r, n, amount, bpm)
        }
    }

    private fun echo(l: FloatArray, r: FloatArray, n: Int, amount: Float, bpm: Float) {
        val delay = (60f / bpm.coerceIn(40f, 220f) * 0.75f * sr).toInt().coerceIn(1, echoSize - 1)
        for (i in 0 until n) {
            val rp = (echoW - delay + echoSize) % echoSize
            val dl = echoL[rp]; val dr = echoR[rp]
            echoL[echoW] = l[i] + dl * 0.5f
            echoR[echoW] = r[i] + dr * 0.5f
            l[i] += dl * amount
            r[i] += dr * amount
            if (++echoW >= echoSize) echoW = 0
        }
    }

    private fun flanger(l: FloatArray, r: FloatArray, n: Int, amount: Float) {
        val base = sr * 0.0035f
        val depth = sr * 0.0028f
        val inc = 2 * PI * 0.3 / sr
        for (i in 0 until n) {
            val d = base + depth * sin(lfo).toFloat()
            lfo += inc
            if (lfo > 2 * PI) lfo -= 2 * PI
            var rp = flW - d
            if (rp < 0) rp += flSize
            val i0 = floor(rp).toInt() % flSize
            val i1 = (i0 + 1) % flSize
            val fr = rp - floor(rp)
            val yl = flL[i0] * (1 - fr) + flL[i1] * fr
            val yr = flR[i0] * (1 - fr) + flR[i1] * fr
            flL[flW] = l[i] + yl * 0.5f
            flR[flW] = r[i] + yr * 0.5f
            l[i] = l[i] * (1f - 0.4f * amount) + yl * amount * 0.8f
            r[i] = r[i] * (1f - 0.4f * amount) + yr * amount * 0.8f
            if (++flW >= flSize) flW = 0
        }
    }

    /** Eco que rebota entre izquierda y derecha (corchea). */
    private fun pingPong(l: FloatArray, r: FloatArray, n: Int, amount: Float, bpm: Float) {
        val delay = (60f / bpm.coerceIn(40f, 220f) * 0.5f * sr).toInt().coerceIn(1, echoSize - 1)
        for (i in 0 until n) {
            val rp = (echoW - delay + echoSize) % echoSize
            val dl = echoL[rp]; val dr = echoR[rp]
            val inp = (l[i] + r[i]) * 0.5f
            echoL[echoW] = inp + dr * 0.55f
            echoR[echoW] = dl * 0.55f
            l[i] += dl * amount
            r[i] += dr * amount
            if (++echoW >= echoSize) echoW = 0
        }
    }

    /** Phaser de 4 etapas all-pass con LFO lento. */
    private fun phaser(l: FloatArray, r: FloatArray, n: Int, amount: Float) {
        val inc = 2 * PI * 0.35 / sr
        for (i in 0 until n) {
            val fc = 300.0 + 1900.0 * (0.5 + 0.5 * sin(phLfo))
            phLfo += inc
            if (phLfo > 2 * PI) phLfo -= 2 * PI
            val t = tan(PI * fc / sr).toFloat()
            val a = (t - 1f) / (t + 1f)
            var yl = l[i]; var yr = r[i]
            for (s in 0 until 4) {
                val ol = a * yl + phZ[s]
                phZ[s] = yl - a * ol
                yl = ol
                val orr = a * yr + phZ[4 + s]
                phZ[4 + s] = yr - a * orr
                yr = orr
            }
            val norm = 1f / (1f + 0.5f * amount)
            l[i] = (l[i] + yl * amount) * norm
            r[i] = (r[i] + yr * amount) * norm
        }
    }

    /** Reducción de bits y de frecuencia de muestreo. */
    private fun crush(l: FloatArray, r: FloatArray, n: Int, amount: Float) {
        val bits = 12f - 8f * amount
        val levels = Math.pow(2.0, (bits - 1f).toDouble()).toFloat()
        val hold = 1 + (amount * 14f).toInt()
        val w = min(1f, amount * 2f)
        for (i in 0 until n) {
            if (holdCnt <= 0) {
                heldL = round(l[i] * levels) / levels
                heldR = round(r[i] * levels) / levels
                holdCnt = hold
            }
            holdCnt--
            l[i] = l[i] * (1f - w) + heldL * w
            r[i] = r[i] * (1f - w) + heldR * w
        }
    }

    /** Gate rítmico a corcheas (efecto trance). */
    private fun gate(l: FloatArray, r: FloatArray, n: Int, amount: Float, bpm: Float) {
        val period = (60f / bpm.coerceIn(40f, 220f) * 0.5f * sr).toLong().coerceAtLeast(2)
        for (i in 0 until n) {
            val ph = (gateN % period).toFloat() / period
            gateN++
            val target = if (ph < 0.55f) 1f else 0f
            gateEnv += (target - gateEnv) * 0.01f
            val g = 1f - amount + amount * gateEnv
            l[i] *= g; r[i] *= g
        }
    }

    /** Panorama automático: va de un lado al otro cada 2 tiempos. */
    private fun autoPan(l: FloatArray, r: FloatArray, n: Int, amount: Float, bpm: Float) {
        val inc = 2 * PI * (bpm.coerceIn(40f, 220f) / 60.0 / 2.0) / sr
        for (i in 0 until n) {
            val s = sin(panLfo).toFloat()
            panLfo += inc
            if (panLfo > 2 * PI) panLfo -= 2 * PI
            l[i] *= 1f - amount * (0.5f + 0.5f * s)
            r[i] *= 1f - amount * (0.5f - 0.5f * s)
        }
    }

    private fun reverb(l: FloatArray, r: FloatArray, n: Int, amount: Float) {
        for (i in 0 until n) {
            val inp = (l[i] + r[i]) * 0.03f
            var wl = 0f; var wr = 0f
            for (c in combsL) wl += c.process(inp, 0.84f, 0.2f)
            for (c in combsR) wr += c.process(inp, 0.84f, 0.2f)
            for (a in apL) wl = a.process(wl)
            for (a in apR) wr = a.process(wr)
            l[i] += wl * amount * 2.5f
            r[i] += wr * amount * 2.5f
        }
    }
}
