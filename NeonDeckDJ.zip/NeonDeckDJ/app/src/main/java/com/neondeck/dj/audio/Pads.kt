package com.neondeck.dj.audio

/** Lógica de los 4 pads de cada deck; la comparten la pantalla táctil y el controlador MIDI. */
object Pads {
    val ROLL_BEATS = doubleArrayOf(0.5, 1.0, 2.0, 4.0)
    val ROLL_LABELS = arrayOf("1/2", "1", "2", "4")
    val FX_LABELS = arrayOf("ECHO", "FLANGER", "REVERB", "FX OFF")

    fun press(engine: AudioEngine, deck: Deck, pad: Int, down: Boolean) {
        val slot = deck.padPage * 4 + pad
        when (deck.padMode) {
            PadMode.HOTCUE -> {
                if (down) { if (deck.shiftHeld) deck.deleteHotCue(slot) else deck.hotCueDown(slot) }
                else deck.hotCueUp(slot)
            }
            PadMode.ROLL -> if (down) deck.rollStart(ROLL_BEATS[pad]) else deck.rollEnd()
            PadMode.FX -> if (down) {
                if (pad < 3) deck.fxType = if (deck.fxType == pad + 1) 0 else pad + 1 else deck.fxType = 0
            }
            PadMode.SAMPLER -> if (down) {
                if (deck.shiftHeld) engine.sampler.stop(slot) else engine.sampler.trigger(slot)
            }
        }
    }
}
