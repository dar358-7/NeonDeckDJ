package com.neondeck.dj

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("neondeck", Context.MODE_PRIVATE)

    private val ana = ctx.getSharedPreferences("neondeck_analysis", Context.MODE_PRIVATE)
    fun bpmOf(id: String): Float? = if (ana.contains("b:$id")) ana.getFloat("b:$id", 0f).takeIf { it > 40f } else null
    fun keyOf(id: String): String? = ana.getString("k:$id", null)
    fun knownKey(id: String): String? =
        (keyOf(id) ?: getAnalysis(id)?.key)?.takeIf { it.isNotEmpty() && it != "--" }
    fun setBpm(id: String, v: Float) { ana.edit().putFloat("b:$id", v).apply() }
    fun setKey(id: String, v: String) { ana.edit().putString("k:$id", v).apply() }

    var outMaster: String
        get() = sp.getString("out_master", "") ?: ""
        set(v) { sp.edit().putString("out_master", v).apply() }
    var outCue: String
        get() = sp.getString("out_cue", "") ?: ""
        set(v) { sp.edit().putString("out_cue", v).apply() }
    var cueVolume: Float
        get() = sp.getFloat("cue_vol", 0.9f)
        set(v) { sp.edit().putFloat("cue_vol", v).apply() }
    var cueMix: Float
        get() = sp.getFloat("cue_mix", 0f)
        set(v) { sp.edit().putFloat("cue_mix", v).apply() }

    var dayMode: Boolean
        get() = sp.getBoolean("day_mode", false)
        set(v) { sp.edit().putBoolean("day_mode", v).apply() }

    var midiMapVer: Int
        get() = sp.getInt("midi_map_ver", 0)
        set(v) { sp.edit().putInt("midi_map_ver", v).apply() }

    var midiMapJson: String?
        get() = sp.getString("midi_map", null)
        set(v) { sp.edit().putString("midi_map", v).apply() }

    /** Segundos de audio por "tick" del jog del controlador. */
    var jogSecPerTick: Float
        get() = sp.getFloat("jog_sec_tick", 0.0018f)
        set(v) { sp.edit().putFloat("jog_sec_tick", v).apply() }

    var pitchInvert: Boolean
        get() = sp.getBoolean("pitch_invert", false)
        set(v) { sp.edit().putBoolean("pitch_invert", v).apply() }

    var crossfaderCurve: Int
        get() = sp.getInt("xf_curve", 0)
        set(v) { sp.edit().putInt("xf_curve", v).apply() }

    var headphoneSplit: Boolean
        get() = sp.getBoolean("hp_split", false)
        set(v) { sp.edit().putBoolean("hp_split", v).apply() }

    var zoomIndex: Int
        get() = sp.getInt("zoom_idx", 1)
        set(v) { sp.edit().putInt("zoom_idx", v).apply() }

    // ---- caché de análisis (BPM / rejilla / tonalidad) por pista
    private val ap = ctx.getSharedPreferences("analysis", Context.MODE_PRIVATE)

    init {
        // v1.7.5: nuevo detector de BPM -> se descartan los BPM guardados (las tonalidades se conservan)
        if (sp.getInt("ana_ver", 0) < 2) {
            val e = ana.edit()
            for ((k, v) in ana.all) if (k.startsWith("b:")) e.remove(k)
            for ((k, v) in ap.all) {
                val key = (v as? String)?.split("|")?.getOrNull(2)
                if (!key.isNullOrEmpty() && key != "--" && !ana.contains("k:$k")) e.putString("k:$k", key)
            }
            e.apply()
            ap.edit().clear().apply()
            sp.edit().putInt("ana_ver", 2).apply()
        }
    }

    class Analysis(val bpm: Float, val firstBeatSec: Double, val key: String, val grid: String = "")

    fun getAnalysis(uriKey: String): Analysis? {
        val v = ap.getString(uriKey, null) ?: return null
        val p = v.split("|")
        if (p.size < 3) return null
        return try { Analysis(p[0].toFloat(), p[1].toDouble(), p[2], p.getOrElse(3) { "" }) } catch (_: Exception) { null }
    }

    /** grid: "S" = rejilla fija (puede haberla editado el usuario), "D" = dinámica (se recalcula al cargar). */
    fun putAnalysis(uriKey: String, bpm: Float, firstBeatSec: Double, key: String, grid: String = "S") {
        ap.edit().putString(uriKey, "$bpm|$firstBeatSec|$key|$grid").apply()
    }

    // ---- carpetas añadidas manualmente (SAF)
    var treeUris: Set<String>
        get() = sp.getStringSet("tree_uris", emptySet()) ?: emptySet()
        set(v) { sp.edit().putStringSet("tree_uris", v).apply() }
}
