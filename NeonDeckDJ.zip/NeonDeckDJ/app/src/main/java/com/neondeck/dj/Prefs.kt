package com.neondeck.dj

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("neondeck", Context.MODE_PRIVATE)

    var midiMapJson: String?
        get() = sp.getString("midi_map", null)
        set(v) { sp.edit().putString("midi_map", v).apply() }

    /** Segundos de audio por "tick" del jog del controlador. */
    var jogSecPerTick: Float
        get() = sp.getFloat("jog_sec_tick", 0.0018f)
        set(v) { sp.edit().putFloat("jog_sec_tick", v).apply() }

    var pitchInvert: Boolean
        get() = sp.getBoolean("pitch_invert", false)
        set(v) { sp.edit().putBoolean("pitch_invert", v).apply() }

    var crossfaderCurve: Int
        get() = sp.getInt("xf_curve", 0)
        set(v) { sp.edit().putInt("xf_curve", v).apply() }

    var headphoneSplit: Boolean
        get() = sp.getBoolean("hp_split", false)
        set(v) { sp.edit().putBoolean("hp_split", v).apply() }

    var zoomIndex: Int
        get() = sp.getInt("zoom_idx", 1)
        set(v) { sp.edit().putInt("zoom_idx", v).apply() }
}
