package com.neondeck.dj.ui

import android.graphics.Paint
import android.graphics.Path
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import com.neondeck.dj.DjSession
import com.neondeck.dj.audio.Analyzer
import com.neondeck.dj.audio.Deck
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

val ZOOMS = floatArrayOf(4f, 8f, 16f)
private val CUE_COLORS = intArrayOf(
    0xFFFF3B30.toInt(), 0xFFFF9500.toInt(), 0xFFFFD60A.toInt(), 0xFF34C759.toInt(),
    0xFF30B0C7.toInt(), 0xFF0A84FF.toInt(), 0xFFBF5AF2.toInt(), 0xFFFF2D92.toInt()
)
fun cueColor(i: Int) = CUE_COLORS[i % 8]

private class WaveBuffers {
    val paints = Array(Analyzer.QCOLORS) { i ->
        Paint().apply { color = Analyzer.waveColor(i); style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT }
    }
    val buckets = Array(Analyzer.QCOLORS) { FloatArray(4 * 1400) }
    val counts = IntArray(Analyzer.QCOLORS)
    val fill = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
    val line = Paint().apply { isAntiAlias = false; style = Paint.Style.STROKE }
    val text = Paint().apply { isAntiAlias = true; color = 0xFF77777C.toInt() }
    val tri = Path()
}

private class Scrub { var deck: Deck? = null }

/** Ondas centrales: deck A arriba, rejilla de beats al centro (para igualar), deck B abajo. */
@Composable
fun CenterWaveforms(a: Deck, b: Deck, session: DjSession, frame: State<Long>, modifier: Modifier = Modifier) {
    val buf = remember { WaveBuffers() }
    val scrub = remember { Scrub() }
    Canvas(
        modifier
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = {
                    session.zoomIndex = (session.zoomIndex + 1) % ZOOMS.size
                    session.prefs.zoomIndex = session.zoomIndex
                })
            }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { o ->
                        val d = if (o.y < size.height / 2f) a else b
                        scrub.deck = d
                        d.touchStart()
                    },
                    onDragEnd = { scrub.deck?.touchEnd(); scrub.deck = null },
                    onDragCancel = { scrub.deck?.touchEnd(); scrub.deck = null }
                ) { change, drag ->
                    val d = scrub.deck
                    if (d != null) {
                        val window = ZOOMS[session.zoomIndex] * d.tempoRate()
                        d.scratchSeconds(-drag.x / size.width * window)
                    }
                    change.consume()
                }
            }
    ) {
        @Suppress("UNUSED_VARIABLE") val tick = frame.value
        val w = size.width
        val h = size.height
        val win = ZOOMS[session.zoomIndex]
        val topH = h * 0.42f
        val midH = h * 0.16f
        drawIntoCanvas { cv ->
            val nc = cv.nativeCanvas
            drawZoom(nc, a, w, 0f, topH, win, buf)
            drawZoom(nc, b, w, topH + midH, h - topH - midH, win, buf)
            // franja central de beats
            buf.fill.color = 0xFF0B0B0E.toInt()
            nc.drawRect(0f, topH, w, topH + midH, buf.fill)
            drawBeats(nc, a, w, topH, midH / 2f, win, buf, 0xFF3FA2FF.toInt())
            drawBeats(nc, b, w, topH + midH / 2f, midH / 2f, win, buf, 0xFFFF5C93.toInt())
            // cabezal
            buf.line.color = 0xFFFFFFFF.toInt(); buf.line.strokeWidth = 2f
            nc.drawLine(w / 2f, 0f, w / 2f, h, buf.line)
            if (a.track == null && b.track == null) {
                buf.text.textSize = h * 0.07f
                buf.text.textAlign = Paint.Align.CENTER
                nc.drawText("Toca el título de un deck para cargar una pista", w / 2f, h / 2f, buf.text)
            }
        }
    }
}

private fun drawZoom(
    nc: android.graphics.Canvas, deck: Deck, w: Float, top: Float, h: Float,
    windowSec: Float, buf: WaveBuffers
) {
    val t = deck.track ?: return
    val wave = t.wave
    val n = wave.peak.size
    if (n == 0) return
    val rate = deck.tempoRate()
    val binsPerSec = t.srcRate / Analyzer.BIN.toDouble()
    val spanBins = windowSec * rate * binsPerSec
    val pos = deck.pos
    val posBin = pos / Analyzer.BIN
    val startBin = posBin - spanBins / 2
    val binsPerPx = spanBins / w
    val cy = top + h / 2f
    val step = 2f
    java.util.Arrays.fill(buf.counts, 0)

    var x = 0f
    while (x < w) {
        val b0 = startBin + x * binsPerPx
        val b1 = b0 + step * binsPerPx
        val i0 = max(0, floor(b0).toInt())
        val i1 = minOf(n, ceil(b1).toInt())
        if (i1 > i0) {
            var best = 0f; var bi = i0
            for (i in i0 until i1) if (wave.peak[i] > best) { best = wave.peak[i]; bi = i }
            if (best > 0.01f) {
                val ci = wave.color[bi].toInt().coerceIn(0, Analyzer.QCOLORS - 1)
                val k = buf.counts[ci]
                val arr = buf.buckets[ci]
                if (k + 4 <= arr.size) {
                    val hh = best * h * 0.47f
                    arr[k] = x + step / 2f; arr[k + 1] = cy - hh
                    arr[k + 2] = x + step / 2f; arr[k + 3] = cy + hh
                    buf.counts[ci] = k + 4
                }
            }
        }
        x += step
    }
    for (ci in 0 until Analyzer.QCOLORS) {
        val c = buf.counts[ci]
        if (c > 0) {
            buf.paints[ci].strokeWidth = step - 0.3f
            nc.drawLines(buf.buckets[ci], 0, c, buf.paints[ci])
        }
    }

    val framesPerPx = (windowSec * rate * t.srcRate) / w
    fun xOf(frame: Double) = (w / 2f + ((frame - pos) / framesPerPx)).toFloat()

    // loop
    if (deck.loopActive) {
        val x0 = xOf(deck.loopInPos); val x1 = xOf(deck.loopOutPos)
        buf.fill.color = 0x3300FF88
        nc.drawRect(x0.coerceIn(0f, w), top, x1.coerceIn(0f, w), top + h, buf.fill)
    }
    // hot cues y cue
    buf.line.strokeWidth = 2f
    for (i in 0 until 8) {
        val f = deck.hotCues[i]
        if (f < 0) continue
        val hx = xOf(f)
        if (hx < -4 || hx > w + 4) continue
        buf.line.color = cueColor(i)
        nc.drawLine(hx, top, hx, top + h, buf.line)
        buf.fill.color = cueColor(i)
        nc.drawRect(hx, top, hx + h * 0.1f, top + h * 0.14f, buf.fill)
    }
    val cx = xOf(deck.cuePoint)
    if (cx in 0f..w) {
        buf.line.color = 0xFFFFA000.toInt()
        nc.drawLine(cx, top, cx, top + h, buf.line)
    }
}

private fun drawBeats(
    nc: android.graphics.Canvas, deck: Deck, w: Float, top: Float, h: Float,
    windowSec: Float, buf: WaveBuffers, color: Int
) {
    val t = deck.track ?: return
    val rate = deck.tempoRate()
    val pos = deck.pos
    val bl = t.beatLenFrames
    val framesPerPx = (windowSec * rate * t.srcRate) / w
    val half = (w / 2f) * framesPerPx
    val k0 = ceil((pos - half - t.firstBeatFrame) / bl).toLong()
    val k1 = floor((pos + half - t.firstBeatFrame) / bl).toLong()
    if (k1 - k0 > 400) return
    buf.line.color = color
    for (k in k0..k1) {
        val f = t.firstBeatFrame + k * bl
        val x = (w / 2f + (f - pos) / framesPerPx).toFloat()
        val bar = Math.floorMod(k, 4L) == 0L
        buf.line.strokeWidth = if (bar) 3f else 2f
        val hh = if (bar) h * 0.9f else h * 0.55f
        nc.drawLine(x, top + (h - hh) / 2f, x, top + (h + hh) / 2f, buf.line)
    }
}

/** Miniatura de la pista completa (barra superior): toca o arrastra para saltar. */
@Composable
fun Overview(deck: Deck, frame: State<Long>, modifier: Modifier = Modifier) {
    val t = deck.track
    val img = remember(t) { t?.wave?.overview?.asImageBitmap() }
    Canvas(
        modifier
            .pointerInput(deck) { detectTapGestures(onTap = { deck.seekFraction(it.x / size.width) }) }
            .pointerInput(deck) {
                detectHorizontalDragGestures { change, _ ->
                    deck.seekFraction(change.position.x / size.width)
                    change.consume()
                }
            }
    ) {
        @Suppress("UNUSED_VARIABLE") val tick = frame.value
        drawRect(Color(0xFF0D0D10))
        if (img != null) drawImage(img, dstSize = IntSize(size.width.toInt(), size.height.toInt()))
        val x = deck.progress() * size.width
        drawRect(Color.Black.copy(alpha = 0.5f), Offset.Zero, Size(x, size.height))
        val tr = deck.track
        if (tr != null) {
            if (deck.loopActive) {
                val l0 = (deck.loopInPos / tr.frames).toFloat() * size.width
                val l1 = (deck.loopOutPos / tr.frames).toFloat() * size.width
                drawRect(Color(0x5500FF88), Offset(l0, 0f), Size(max(2f, l1 - l0), size.height))
            }
            for (i in 0 until 8) {
                val f = deck.hotCues[i]
                if (f >= 0) {
                    val hx = (f / tr.frames).toFloat() * size.width
                    drawRect(Color(cueColor(i)), Offset(hx - 1f, 0f), Size(2.5f, size.height))
                }
            }
        }
        drawLine(Color.White, Offset(x, 0f), Offset(x, size.height), 2.5f)
    }
}
