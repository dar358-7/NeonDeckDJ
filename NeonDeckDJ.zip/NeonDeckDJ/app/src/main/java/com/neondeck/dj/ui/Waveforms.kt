package com.neondeck.dj.ui

import android.graphics.Paint
import android.graphics.Path
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntSize
import com.neondeck.dj.DjSession
import com.neondeck.dj.audio.Analyzer
import com.neondeck.dj.audio.Deck
import kotlin.math.ceil
import kotlin.math.floor
import kotlin.math.max

val ZOOMS = floatArrayOf(4f, 8f, 16f)
private val CUE_COLORS = intArrayOf(
    0xFFFF3B30.toInt(), 0xFFFF9500.toInt(), 0xFFFFD60A.toInt(), 0xFF34C759.toInt(),
    0xFF30B0C7.toInt(), 0xFF0A84FF.toInt(), 0xFFBF5AF2.toInt(), 0xFFFF2D92.toInt()
)
fun cueColor(i: Int) = CUE_COLORS[i % 8]

private class WaveBuffers {
    val paintsA = Array(Analyzer.QCOLORS) { i ->
        Paint().apply { color = Analyzer.waveColor(i, 0); style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT }
    }
    val paintsB = Array(Analyzer.QCOLORS) { i ->
        Paint().apply { color = Analyzer.waveColor(i, 1); style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT }
    }
    val coreA = Array(Analyzer.QCOLORS) { i ->
        Paint().apply { color = whiten(Analyzer.waveColor(i, 0)); style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT }
    }
    val coreB = Array(Analyzer.QCOLORS) { i ->
        Paint().apply { color = whiten(Analyzer.waveColor(i, 1)); style = Paint.Style.STROKE; strokeCap = Paint.Cap.BUTT }
    }
    val buckets = Array(Analyzer.QCOLORS) { FloatArray(4 * 2000) }
    val cols = FloatArray(4096)
    val bg = Paint().apply { isAntiAlias = false; style = Paint.Style.FILL }
    val small = Paint().apply { isAntiAlias = true; color = 0xAAB8B8C8.toInt(); typeface = android.graphics.Typeface.DEFAULT_BOLD }
    val counts = IntArray(Analyzer.QCOLORS)
    val fill = Paint().apply { isAntiAlias = true; style = Paint.Style.FILL }
    val line = Paint().apply { isAntiAlias = false; style = Paint.Style.STROKE }
    val text = Paint().apply { isAntiAlias = true; color = 0xFF77777C.toInt() }
    val tri = Path()
}

/** Mezcla un color con blanco (núcleo brillante de las barras). */
private fun whiten(c: Int): Int {
    val r = (c shr 16 and 255); val g = (c shr 8 and 255); val b = (c and 255)
    val t = 0.55f
    return (0xFF shl 24) or ((r + (255 - r) * t).toInt() shl 16) or ((g + (255 - g) * t).toInt() shl 8) or (b + (255 - b) * t).toInt()
}

private class Scrub { var deck: Deck? = null }

/** Ondas centrales: deck A arriba, rejilla de beats al centro (para igualar), deck B abajo. */
@Composable
fun CenterWaveforms(a: Deck, b: Deck, session: DjSession, frame: State<Long>, modifier: Modifier = Modifier, interactive: Boolean = true) {
    val buf = remember { WaveBuffers() }
    val scrub = remember { Scrub() }
    Canvas(
        modifier
            .pointerInput(interactive) {
                if (!interactive) return@pointerInput
                detectTapGestures(onDoubleTap = {
                    session.zoomIndex = (session.zoomIndex + 1) % ZOOMS.size
                    session.prefs.zoomIndex = session.zoomIndex
                })
            }
            .pointerInput(interactive) {
                if (!interactive) return@pointerInput
                detectDragGestures(
                    onDragStart = { o ->
                        val d = if (o.y < size.height / 2f) a else b
                        scrub.deck = d
                        d.touchStart()
                    },
                    onDragEnd = { scrub.deck?.touchEnd(); scrub.deck = null },
                    onDragCancel = { scrub.deck?.touchEnd(); scrub.deck = null }
                ) { change, drag ->
                    val d = scrub.deck
                    if (d != null) {
                        val window = ZOOMS[session.zoomIndex] * d.tempoRate()
                        d.scratchSeconds(-drag.x / size.width * window)
                    }
                    change.consume()
                }
            }
    ) {
        @Suppress("UNUSED_VARIABLE") val tick = frame.value
        val w = size.width
        val h = size.height
        val win = ZOOMS[session.zoomIndex]
        val topH = h * 0.42f
        val midH = h * 0.16f
        drawIntoCanvas { cv ->
            val nc = cv.nativeCanvas
            val dn = density
            buf.fill.color = 0xFF0B0B0F.toInt()
            nc.drawRoundRect(0f, 0f, w, h, 18f, 18f, buf.fill)
            drawZoom(nc, a, w, 0f, topH, win, buf, dn)
            drawZoom(nc, b, w, topH + midH, h - topH - midH, win, buf, dn)
            // franja central de beats
            buf.fill.color = 0xFF08080B.toInt()
            nc.drawRect(0f, topH, w, topH + midH, buf.fill)
            drawBeats(nc, a, w, topH, midH / 2f, win, buf, 0xFF00F0FF.toInt(), dn)
            drawBeats(nc, b, w, topH + midH / 2f, midH / 2f, win, buf, 0xFFFF6B00.toInt(), dn)
            // cabezal
            val px = w / 2f
            buf.line.color = 0x2200F0FF; buf.line.strokeWidth = 12f
            nc.drawLine(px, 0f, px, h, buf.line)
            buf.line.color = 0x5500F0FF; buf.line.strokeWidth = 5f
            nc.drawLine(px, 0f, px, h, buf.line)
            buf.line.color = 0xFFE9FEFF.toInt(); buf.line.strokeWidth = 1.6f
            nc.drawLine(px, 0f, px, h, buf.line)
            buf.fill.color = 0xFF00F0FF.toInt()
            buf.tri.reset(); buf.tri.moveTo(px - 7f, 0f); buf.tri.lineTo(px + 7f, 0f); buf.tri.lineTo(px, 9f); buf.tri.close()
            nc.drawPath(buf.tri, buf.fill)
            buf.tri.reset(); buf.tri.moveTo(px - 7f, h); buf.tri.lineTo(px + 7f, h); buf.tri.lineTo(px, h - 9f); buf.tri.close()
            nc.drawPath(buf.tri, buf.fill)
            if (a.track == null && b.track == null) {
                buf.text.textSize = h * 0.07f
                buf.text.textAlign = Paint.Align.CENTER
                nc.drawText("Toca el título de un deck para cargar una pista", w / 2f, h / 2f, buf.text)
            }
        }
    }
}

private fun drawZoom(
    nc: android.graphics.Canvas, deck: Deck, w: Float, top: Float, h: Float,
    windowSec: Float, buf: WaveBuffers, dn: Float
) {
    val t = deck.track ?: return
    val wave = t.wave
    val n = minOf(wave.bins, wave.peak.size, wave.color.size)
    if (n == 0) return
    val paints = if (deck.index == 0) buf.paintsA else buf.paintsB
    val cores = if (deck.index == 0) buf.coreA else buf.coreB
    val rate = deck.tempoRate()
    val binsPerSec = t.srcRate / Analyzer.BIN.toDouble()
    val spanBins = windowSec * rate * binsPerSec
    val pos = deck.pos
    val posBin = pos / Analyzer.BIN
    val startBin = posBin - spanBins / 2
    val binsPerPx = spanBins / w
    val cy = top + h / 2f
    val step = 2f
    java.util.Arrays.fill(buf.counts, 0)

    var x = 0f
    while (x < w) {
        val b0 = startBin + x * binsPerPx
        val b1 = b0 + step * binsPerPx
        val i0 = max(0, floor(b0).toInt())
        val i1 = minOf(n, ceil(b1).toInt())
        if (i1 > i0) {
            var best = 0f; var bi = i0
            for (i in i0 until i1) if (wave.peak[i] > best) { best = wave.peak[i]; bi = i }
            if (best > 0.01f) {
                val ci = wave.color[bi].toInt().coerceIn(0, Analyzer.QCOLORS - 1)
                val k = buf.counts[ci]
                val arr = buf.buckets[ci]
                if (k + 4 <= arr.size) {
                    val hh = best * h * 0.47f
                    arr[k] = x + step / 2f; arr[k + 1] = cy - hh
                    arr[k + 2] = x + step / 2f; arr[k + 3] = cy + hh
                    buf.counts[ci] = k + 4
                }
            }
        }
        x += step
    }
    for (ci in 0 until Analyzer.QCOLORS) {
        val c = buf.counts[ci]
        if (c > 0) {
            paints[ci].strokeWidth = step - 0.3f; paints[ci].alpha = 255
            nc.drawLines(buf.buckets[ci], 0, c, paints[ci])
        }
    }

    val framesPerPx = (windowSec * rate * t.srcRate) / w
    fun xOf(frame: Double) = (w / 2f + ((frame - pos) / framesPerPx)).toFloat()

    // loop
    if (deck.loopActive) {
        val x0 = xOf(deck.loopInPos); val x1 = xOf(deck.loopOutPos)
        buf.fill.color = 0x3300FF88
        nc.drawRect(x0.coerceIn(0f, w), top, x1.coerceIn(0f, w), top + h, buf.fill)
    }
    // hot cues y cue
    buf.line.strokeWidth = 2f
    for (i in 0 until 8) {
        val f = deck.hotCues[i]
        if (f < 0) continue
        val hx = xOf(f)
        if (hx < -4 || hx > w + 4) continue
        buf.line.color = cueColor(i)
        nc.drawLine(hx, top, hx, top + h, buf.line)
        buf.fill.color = cueColor(i)
        nc.drawRect(hx, top, hx + h * 0.1f, top + h * 0.14f, buf.fill)
    }
    val cx = xOf(deck.cuePoint)
    if (cx in 0f..w) {
        buf.line.color = 0xFFFFA000.toInt()
        nc.drawLine(cx, top, cx, top + h, buf.line)
    }
}

private fun drawBeats(
    nc: android.graphics.Canvas, deck: Deck, w: Float, top: Float, h: Float,
    windowSec: Float, buf: WaveBuffers, color: Int, dn: Float
) {
    val t = deck.track ?: return
    val rate = deck.tempoRate()
    val pos = deck.pos
    val bl = t.beatLenFrames
    val framesPerPx = (windowSec * rate * t.srcRate) / w
    val half = (w / 2f) * framesPerPx
    val k0 = ceil((pos - half - t.firstBeatFrame) / bl).toLong()
    val k1 = floor((pos + half - t.firstBeatFrame) / bl).toLong()
    if (k1 - k0 > 400) return
    buf.line.color = color
    for (k in k0..k1) {
        val f = t.firstBeatFrame + k * bl
        val x = (w / 2f + (f - pos) / framesPerPx).toFloat()
        val bar = Math.floorMod(k, 4L) == 0L
        buf.line.strokeWidth = if (bar) 3f else 2f
        val hh = if (bar) h * 0.9f else h * 0.55f
        nc.drawLine(x, top + (h - hh) / 2f, x, top + (h + hh) / 2f, buf.line)
    }
}

/** Medidor de fase entre decks: muestra cuántos ms están desfasados los beats (para empatar a mano). */
private fun drawPhase(nc: android.graphics.Canvas, a: Deck, b: Deck, w: Float, top: Float, h: Float, buf: WaveBuffers, dn: Float) {
    val ta = a.track ?: return
    val tb = b.track ?: return
    if (ta.bpm <= 0f || tb.bpm <= 0f) return
    var d = a.beatPhase() - b.beatPhase()
    if (d > 0.5) d -= 1.0
    if (d < -0.5) d += 1.0
    // ms de diferencia usando el periodo de beat real (con pitch) del deck B
    val beatMs = 60000.0 / max(1f, b.currentBpm())
    val ms = d * beatMs
    val bw = minOf(w * 0.2f, 180f * dn)
    val cx = w / 2f
    val cy = top + h / 2f
    val bh = h * 0.34f
    buf.fill.color = 0xCC000000.toInt()
    nc.drawRoundRect(cx - bw / 2f - 6f * dn, cy - bh, cx + bw / 2f + 6f * dn, cy + bh, 8f * dn, 8f * dn, buf.fill)
    val ok = kotlin.math.abs(ms) < 8.0
    val mid = kotlin.math.abs(ms) < 25.0
    val col = if (ok) 0xFF39FF88.toInt() else if (mid) 0xFFFACC15.toInt() else 0xFFFF3B3B.toInt()
    buf.line.color = 0x55FFFFFF; buf.line.strokeWidth = 1f * dn
    nc.drawLine(cx, cy - bh * 0.7f, cx, cy + bh * 0.7f, buf.line)
    val x = cx + (ms / 40.0).coerceIn(-1.0, 1.0).toFloat() * (bw / 2f)
    buf.fill.color = col
    nc.drawCircle(x, cy, bh * 0.38f, buf.fill)
    buf.small.textSize = h * 0.3f
    buf.small.color = col
    buf.small.textAlign = Paint.Align.CENTER
    nc.drawText((if (ms >= 0) "+" else "") + "%.0f ms".format(ms), cx, cy - bh * 0.5f - 2f, buf.small)
    buf.small.color = 0xAAB8B8C8.toInt()
}

/** Picos de transitorios (kicks, snares…) coloreados por frecuencia, como en la franja central de la referencia. */
private fun drawSpikes(
    nc: android.graphics.Canvas, deck: Deck, w: Float, top: Float, h: Float,
    windowSec: Float, buf: WaveBuffers, dn: Float, up: Boolean
) {
    val t = deck.track ?: return
    val wave = t.wave
    val n = minOf(wave.bins, wave.onset.size, wave.color.size)
    if (n == 0) return
    val rate = deck.tempoRate()
    val binsPerSec = t.srcRate / Analyzer.BIN.toDouble()
    val spanBins = windowSec * rate * binsPerSec
    val startBin = deck.pos / Analyzer.BIN - spanBins / 2
    val binsPerPx = spanBins / w
    val colStep = max(3f, dn * 1.1f)
    val nc2 = minOf(buf.cols.size, (w / colStep).toInt() + 1)
    var mx = 1e-6f
    for (i in 0 until nc2) {
        val b0 = startBin + i * colStep * binsPerPx
        val i0 = max(0, floor(b0).toInt()); val i1 = minOf(n, ceil(b0 + colStep * binsPerPx).toInt())
        var v = 0f
        for (q in i0 until i1) if (wave.onset[q] > v) v = wave.onset[q]
        buf.cols[i] = v
        if (v > mx) mx = v
    }
    val base = if (up) top + h else top
    val dir = if (up) -1f else 1f
    buf.line.strokeWidth = colStep * 0.7f
    for (i in 0 until nc2) {
        val v = buf.cols[i] / mx
        if (v < 0.08f) continue
        val b0 = (startBin + i * colStep * binsPerPx).toInt().coerceIn(0, n - 1)
        buf.line.color = (Analyzer.waveColor(wave.color[b0].toInt().coerceIn(0, Analyzer.QCOLORS - 1), deck.index) and 0x00FFFFFF) or 0xCC000000.toInt()
        val x = i * colStep + colStep / 2f
        nc.drawLine(x, base, x, base + dir * v * h * 0.95f, buf.line)
    }
}

/** Miniatura de la pista completa (barra superior): toca o arrastra para saltar. */
@Composable
fun Overview(deck: Deck, frame: State<Long>, modifier: Modifier = Modifier) {
    val t = deck.track
    val bmp = t?.wave?.overview
    val img = remember(t, bmp) { bmp?.asImageBitmap() }
    Canvas(
        modifier
            .pointerInput(deck) { detectTapGestures(onTap = { deck.seekFraction(it.x / size.width) }) }
            .pointerInput(deck) {
                detectHorizontalDragGestures { change, _ ->
                    deck.seekFraction(change.position.x / size.width)
                    change.consume()
                }
            }
    ) {
        @Suppress("UNUSED_VARIABLE") val tick = frame.value
        drawRect(Color(0xFF0D0D10))
        if (img != null) drawImage(img, dstSize = IntSize(size.width.toInt(), size.height.toInt()))
        else if (t != null) {
            // mientras se decodifica: onda en vivo (se va dibujando según llega el audio)
            val wv = t.wave
            val bins = minOf(wv.bins, wv.peak.size, wv.color.size)
            val total = (t.frames / Analyzer.BIN).coerceAtLeast(1)
            val cols = (size.width / 3f).toInt().coerceAtLeast(1)
            val cw = size.width / cols
            val mid = size.height / 2f
            for (c in 0 until cols) {
                val b0 = (c.toLong() * total / cols).toInt()
                if (b0 >= bins) break
                val b1 = minOf(bins, ((c + 1).toLong() * total / cols).toInt().coerceAtLeast(b0 + 1))
                var best = 0f; var bi = b0
                var q = b0
                val st = maxOf(1, (b1 - b0) / 6)
                while (q < b1) { if (wv.peak[q] > best) { best = wv.peak[q]; bi = q }; q += st }
                val hh = best * mid * 0.95f
                drawRect(Color(Analyzer.waveColor(wv.color[bi].toInt().coerceIn(0, Analyzer.QCOLORS - 1), deck.index)),
                    Offset(c * cw, mid - hh), Size(cw - 0.5f, hh * 2f))
            }
        }
        val x = deck.progress() * size.width
        drawRect(Color.Black.copy(alpha = 0.5f), Offset.Zero, Size(x, size.height))
        val tr = deck.track
        if (tr != null) {
            if (deck.loopActive) {
                val l0 = (deck.loopInPos / tr.frames).toFloat() * size.width
                val l1 = (deck.loopOutPos / tr.frames).toFloat() * size.width
                drawRect(Color(0x5500FF88), Offset(l0, 0f), Size(max(2f, l1 - l0), size.height))
            }
            for (i in 0 until 8) {
                val f = deck.hotCues[i]
                if (f >= 0) {
                    val hx = (f / tr.frames).toFloat() * size.width
                    drawRect(Color(cueColor(i)), Offset(hx - 1f, 0f), Size(2.5f, size.height))
                }
            }
        }
        drawLine(Color.White, Offset(x, 0f), Offset(x, size.height), 2.5f)
    }
}
