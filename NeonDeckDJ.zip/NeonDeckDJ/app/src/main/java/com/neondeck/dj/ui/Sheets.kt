package com.neondeck.dj.ui

import com.neondeck.dj.CrashLog
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.clickable
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neondeck.dj.DjSession
import com.neondeck.dj.audio.Deck
import com.neondeck.dj.midi.Action
import com.neondeck.dj.midi.MidiMap

@Composable
fun Chip(text: String, selected: Boolean, color: Color = Neon.DeckA, onClick: () -> Unit) {
    Text(
        text, color = if (selected) onNeon(color) else Neon.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.neonGlow(color, selected, 8.dp, 14.dp, 0.6f).clip(RoundedCornerShape(14.dp))
            .background(if (selected) color else Color(0xFF23232A))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
private fun SheetScaffold(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xD0000000))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
            .safeDrawingPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.fillMaxWidth(0.95f).fillMaxHeight(0.94f)
                .clip(RoundedCornerShape(16.dp)).background(Neon.Panel)
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Chip("✕  Cerrar", false, onClick = onClose)
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

// ============================================================================ MEZCLADOR

@Composable
fun MixerSheet(s: DjSession, frame: State<Long>) {
    SheetScaffold("MEZCLADOR", { s.mixerOpen = false }) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ChannelStrip(s.engine.deckA, Modifier.weight(1f))
            MasterStrip(s, frame, Modifier.width(210.dp))
            ChannelStrip(s.engine.deckB, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ChannelStrip(d: Deck, modifier: Modifier) {
    val c = Neon.deck(d.index)
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(Neon.Panel2).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (d.index == 0) "DECK A" else "DECK B", color = c, fontWeight = FontWeight.Black, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Chip("CUE 🎧", d.pfl, c) { d.pfl = !d.pfl }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Knob(d.volume, 0f, 1f, 1f, "VOL", c, { d.volume = it })
            Knob(d.gain, 0f, 2f, 1f, "GAIN", c, { d.gain = it })
            Knob(d.eqHigh, 0f, 1.5f, 1f, "HI", c, { d.eqHigh = it })
            Knob(d.eqMid, 0f, 1.5f, 1f, "MID", c, { d.eqMid = it })
            Knob(d.eqLow, 0f, 1.5f, 1f, "LOW", c, { d.eqLow = it })
            Knob(d.filter, -1f, 1f, 0f, "FILTER", c, { d.filter = it }, bipolarCenter = true)
        }
        Text("EFECTO", color = Neon.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("OFF", d.fxType == 0, c) { d.fxType = 0 }
            Chip("ECHO", d.fxType == 1, c) { d.fxType = 1 }
            Chip("FLANGER", d.fxType == 2, c) { d.fxType = 2 }
            Chip("REVERB", d.fxType == 3, c) { d.fxType = 3 }
            Spacer(Modifier.weight(1f))
            Knob(d.fxAmount, 0f, 1f, 0.5f, "MIX", c, { d.fxAmount = it }, size = 40.dp)
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("PING-PONG", d.fxType == 4, c) { d.fxType = 4 }
            Chip("PHASER", d.fxType == 5, c) { d.fxType = 5 }
            Chip("CRUSH", d.fxType == 6, c) { d.fxType = 6 }
            Chip("GATE", d.fxType == 7, c) { d.fxType = 7 }
            Chip("AUTO-PAN", d.fxType == 8, c) { d.fxType = 8 }
        }
        Text("STEMS (aproximados)", color = Neon.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("NORMAL", d.stemMode == 0, c) { d.stemMode = 0 }
            Chip("SIN VOZ", d.stemMode == 1, c) { d.stemMode = if (d.stemMode == 1) 0 else 1 }
            Chip("SOLO VOZ", d.stemMode == 2, c) { d.stemMode = if (d.stemMode == 2) 0 else 2 }
            Chip("KEY LOCK", d.keyLock, Neon.Green) { d.keyLock = !d.keyLock }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("VINYL", d.vinyl, c) { d.vinyl = !d.vinyl }
            Chip("RANGO ±${(d.range * 100).toInt()}%", false, c) { d.cycleRange() }
            Chip("SYNC", d.syncOn, c) { d.syncOn = false }
        }
        // ---- rejilla de beats: ajuste fino sin cortar el audio
        val t = d.track
        if (t != null) {
            @Suppress("UNUSED_VARIABLE") val refresh = d.gridBusy
            Text(
                "REJILLA  ${"%.2f".format(t.bpm)} BPM  ·  " + (if (t.dynamicGrid) "dinámica" else "fija"),
                color = Neon.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("−10ms", false, c) { d.shiftGridMs(-10.0) }
                Chip("−1ms", false, c) { d.shiftGridMs(-1.0) }
                Chip("+1ms", false, c) { d.shiftGridMs(1.0) }
                Chip("+10ms", false, c) { d.shiftGridMs(10.0) }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("BPM −0.01", false, c) { d.nudgeGridBpm(-0.01f) }
                Chip("BPM +0.01", false, c) { d.nudgeGridBpm(0.01f) }
                Chip("BEAT AQUÍ", false, Neon.Green) { d.setBeatHere() }
            }
        }
    }
}

@Composable
private fun MasterStrip(s: DjSession, frame: State<Long>, modifier: Modifier) {
    val e = s.engine
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(Neon.Panel2).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("MASTER", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            LedMeter({ e.masterLevelL }, frame, Modifier.width(9.dp).height(80.dp))
            Knob(e.masterGain, 0f, 1.2f, 0.85f, "VOL", Color.White, { e.masterGain = it }, size = 56.dp)
            LedMeter({ e.masterLevelR }, frame, Modifier.width(9.dp).height(80.dp))
        }
        Text("CROSSFADER", color = Neon.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            val names = listOf("MIX", "CUT", "POW")
            for (i in 0..2) Chip(names[i], e.crossfaderCurve == i, Neon.Gray) { e.crossfaderCurve = i; s.prefs.crossfaderCurve = i }
        }
        Chip("SPLIT CUE (L=cue R=master)", e.headphoneSplit, Neon.Green) {
            e.headphoneSplit = !e.headphoneSplit; s.prefs.headphoneSplit = e.headphoneSplit
        }
        val sec = run { frame.value; e.recorder.seconds }
        Chip(if (e.recording) "■ GRABANDO ${fmtTime(sec.toDouble())}" else "● GRABAR MEZCLA", e.recording, Neon.Red) {
            val f = e.toggleRecording()
            s.toast(if (e.recording) "Grabando…" else "Guardado: ${f?.name ?: ""}")
        }
    }
}

// ============================================================================ BIBLIOTECA

@Composable
fun LibrarySheet(s: DjSession) {
    val list = s.filteredLibrary()
    val state = rememberLazyListState()
    val showingTracks = s.libTab == 0 || s.openFolder != null
    LaunchedEffect(s.libraryIndex, list.size, s.libTab, s.openFolder) {
        if (showingTracks && list.isNotEmpty()) state.animateScrollToItem(s.libraryIndex.coerceIn(0, list.size - 1))
    }
    SheetScaffold("BIBLIOTECA", { s.libraryOpen = false }) {
        // ---- fila 1: buscador + destino + archivo
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Row(
                Modifier.weight(1f).height(38.dp).clip(RoundedCornerShape(19.dp)).background(Color(0xFF171A26))
                    .border(1.dp, if (s.libraryQuery.isNotEmpty()) Neon.DeckA.copy(alpha = 0.7f) else Neon.Edge, RoundedCornerShape(19.dp))
                    .padding(horizontal = 14.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text("🔍", fontSize = 14.sp)
                Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
                    if (s.libraryQuery.isEmpty()) Text("Buscar título o artista…", color = Neon.Gray, fontSize = 14.sp)
                    BasicTextField(
                        value = s.libraryQuery,
                        onValueChange = { s.libraryQuery = it; s.libraryIndex = 0 },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search, autoCorrect = false),
                        textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                if (s.libraryQuery.isNotEmpty())
                    Text("✕", color = Neon.Gray, fontSize = 14.sp, modifier = Modifier.clip(CircleShape).clickable { s.libraryQuery = ""; s.libraryIndex = 0 }.padding(4.dp))
            }
            Segmented(listOf("→ DECK A", "→ DECK B"), s.libraryTarget, listOf(Neon.DeckA, Neon.DeckB)) { s.libraryTarget = it }
            Chip("Archivo…", false) { s.pickTrack(s.libraryTarget) }
            Chip("↻", false) { s.scanLibrary() }
        }
        Spacer(Modifier.height(8.dp))
        // ---- fila 2: vista + orden + filtro + análisis (todo en una línea para ver más temas)
        Spacer(Modifier.height(6.dp))
        Row(
            Modifier.fillMaxWidth().horizontalScroll(androidx.compose.foundation.rememberScrollState()),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Segmented(listOf("♪  Canciones", "📁  Carpetas"), s.libTab, listOf(Neon.DeckA, Neon.DeckA)) {
                s.libTab = it; if (it == 1) s.openFolder = null; s.libraryIndex = 0
            }
            if (showingTracks) {
                Segmented(listOf("Recientes", "BPM ↑", "BPM ↓", "A-Z", "Key"), s.libSort, List(5) { Neon.DeckA }) { s.libSort = it; s.libraryIndex = 0 }
                val rb = s.refBpm()
                Chip(if (rb > 0f) "≈ ${"%.0f".format(rb)} BPM" else "≈ BPM", s.libBpmMatch, Neon.Green) { s.libBpmMatch = !s.libBpmMatch; s.libraryIndex = 0 }
            }
            val folderScope = if (s.libTab == 1) s.openFolder else null
            Chip(
                if (s.analyzing) "■ Detener  ${s.analyzeDone}/${s.analyzeTotal}" else "⚡ Analizar" + if (folderScope != null) " (carpeta)" else "",
                s.analyzing, Neon.Green
            ) { s.analyzeAll(folderScope) }
        }
        Spacer(Modifier.height(4.dp))
        when {
            !s.libraryLoaded -> Text("Buscando música en el dispositivo…", color = Neon.Gray, modifier = Modifier.padding(12.dp))
            s.libTab == 1 && s.openFolder == null -> FolderList(s)
            list.isEmpty() -> Text(
                "No se encontró música. Concede el permiso de audio, añade una carpeta o usa «Archivo…» para elegir un tema.",
                color = Neon.Gray, modifier = Modifier.padding(12.dp)
            )
            else -> Column(Modifier.fillMaxSize()) {
                if (s.libTab == 1) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Chip("← Carpetas", false) { s.openFolder = null; s.libraryIndex = 0 }
                        Text(list.firstOrNull()?.folderName ?: "", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("${list.size} temas", color = Neon.Gray, fontSize = 11.sp)
                    }
                    Spacer(Modifier.height(6.dp))
                }
                LazyColumn(Modifier.fillMaxSize(), state = state) {
                    itemsIndexed(list) { i, item -> TrackRow(s, i, item) }
                }
            }
        }
    }
}

@Composable
private fun FolderList(s: DjSession) {
    val folders = s.folders()
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                Chip("＋ Añadir carpeta", false, Neon.DeckA) { s.pickFolder() }
                if (s.treeCount > 0) Chip("Quitar carpetas añadidas (${s.treeCount})", false, Neon.Red) { s.clearAddedFolders() }
            }
        }
        itemsIndexed(folders) { _, f ->
            val played = s.library.count { it.folderPath == f.path && s.playedIds.contains(it.id) }
            Row(
                Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(RoundedCornerShape(10.dp))
                    .background(Color(0xFF181A26))
                    .clickable { s.openFolder = f.path; s.libraryIndex = 0 }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("📁", fontSize = 20.sp)
                Column(Modifier.weight(1f)) {
                    Text(f.name, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(f.path.removePrefix("/storage/emulated/0/"), color = Neon.Gray, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (played > 0) Text("$played tocadas", color = Neon.Green, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text("${f.count} temas", color = Neon.Gray, fontSize = 12.sp)
                Text("›", color = Neon.Gray, fontSize = 20.sp)
            }
        }
    }
}

@Composable
private fun Segmented(options: List<String>, selected: Int, colors: List<Color>, onSelect: (Int) -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFF14161F)).border(1.dp, Neon.Edge, RoundedCornerShape(20.dp)).padding(3.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        options.forEachIndexed { i, t ->
            val on = i == selected
            val c = colors[i]
            Text(
                t, color = if (on) onNeon(c) else Neon.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier.clip(RoundedCornerShape(17.dp)).background(if (on) c else Color.Transparent)
                    .clickable { onSelect(i) }.padding(horizontal = 12.dp, vertical = 5.dp)
            )
        }
    }
}

@Composable
private fun TrackRow(s: DjSession, i: Int, item: com.neondeck.dj.LibItem) {
    val sel = i == s.libraryIndex
    val played = s.playedIds.contains(item.id)
    val onA = s.engine.deckA.track?.id == item.id
    val onB = s.engine.deckB.track?.id == item.id
    val key = item.key
    val kc = if (key != null) Color(com.neondeck.dj.audio.Analyzer.keyColor(key)) else Neon.GrayDark
    val shape = RoundedCornerShape(14.dp)
    Row(
        Modifier.fillMaxWidth().padding(vertical = 2.dp).clip(shape)
            .background(if (sel) Color(0xFF262A3B) else if (played) Color(0xFF14231F) else Color(0xFF161925))
            .border(1.dp, if (sel) Neon.DeckA.copy(alpha = 0.65f) else Color.Transparent, shape)
            .clickable { s.selectItem(i, item) }
            .padding(start = 0.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(Modifier.width(5.dp).height(38.dp).background(kc))      // franja con el color de la tonalidad
        Column(Modifier.weight(1f).padding(vertical = 3.dp), verticalArrangement = Arrangement.spacedBy(0.dp)) {
            Text(
                item.title, color = if (played) Color(0xFF86EFAC) else Color.White, fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                if (onA) Text("A", color = onNeon(Neon.DeckA), fontSize = 9.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Neon.DeckA).padding(horizontal = 5.dp, vertical = 1.dp))
                if (onB) Text("B", color = onNeon(Neon.DeckB), fontSize = 9.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(Neon.DeckB).padding(horizontal = 5.dp, vertical = 1.dp))
                Text(
                    (if (played) "✓ Tocada · " else "") + item.artist, color = Neon.Gray, fontSize = 10.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        val bpm = item.bpm
        Column(Modifier.width(46.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                if (bpm != null) "%.0f".format(bpm) else "—", color = if (bpm != null) Color.White else Neon.GrayDark,
                fontSize = 15.sp, fontWeight = FontWeight.Black
            )
            Text("BPM", color = Neon.Gray, fontSize = 8.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
        }
        Row(Modifier.width(84.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            if (key != null) {
                Text(
                    key, color = onNeon(kc), fontSize = 11.sp, fontWeight = FontWeight.Black,
                    modifier = Modifier.clip(RoundedCornerShape(7.dp)).background(kc).padding(horizontal = 7.dp, vertical = 3.dp)
                )
                Text(com.neondeck.dj.audio.Analyzer.keyName(key), color = Color(0xFFC8C8D4), fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
            } else Text("—", color = Neon.GrayDark, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        }
        val secs = (item.durationMs / 1000).toInt()
        Text(if (secs > 0) "%d:%02d".format(secs / 60, secs % 60) else "", color = Neon.Gray, fontSize = 12.sp, modifier = Modifier.width(40.dp))
        for (d in 0..1) {
            val c = if (d == 0) Neon.DeckA else Neon.DeckB
            Box(
                Modifier.size(30.dp).clip(CircleShape).background(c.copy(alpha = 0.18f)).border(1.2.dp, c, CircleShape)
                    .clickable { s.loadTrack(d, item.uri); s.libraryOpen = false },
                contentAlignment = Alignment.Center
            ) { Text(if (d == 0) "A" else "B", color = c, fontSize = 13.sp, fontWeight = FontWeight.Black) }
        }
    }
}

// ============================================================================ AJUSTES + MIDI

@Composable
fun SettingsSheet(s: DjSession) {
    var tab by remember { mutableIntStateOf(0) }
    SheetScaffold("AJUSTES", { s.settingsOpen = false; s.router.monitorEnabled = false; s.router.cancelLearn() }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("MIDI / Controlador", tab == 0) { tab = 0 }
            Chip("Audio", tab == 1) { tab = 1 }
            Chip("Acerca de", tab == 2) { tab = 2 }
        }
        Spacer(Modifier.height(8.dp))
        when (tab) {
            0 -> MidiTab(s)
            1 -> AudioTab(s)
            else -> Column(Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState())) { AboutTab(); CrashReport(s) }
        }
    }
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, color = Neon.DeckA, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
}

@Composable
private fun MidiTab(s: DjSession) {
    val r = s.router
    val h = s.midi
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            SectionTitle("CONTROLADOR USB")
            val ok = h.connectedName != null
            Text(
                if (ok) "● ${h.status}" else "○ ${h.status}", color = if (ok) Neon.Green else Neon.Gray,
                fontWeight = FontWeight.Bold, fontSize = 13.sp
            )
            if (h.devices.isEmpty()) {
                Text(
                    "Conecta el Hercules DJControl Inpulse 200 con un cable USB-OTG. Android lo detecta como dispositivo MIDI estándar (no requiere driver).",
                    color = Neon.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp)
                )
            }
            Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("↻ Buscar", false) { h.refresh(); h.autoConnect() }
                if (ok) Chip("Desconectar", false, Neon.Red) { h.disconnectByUser() }
            }
            for (d in h.devices) {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        d.name + (if (d.canSend) "  · LEDs" else ""), color = Color.White, fontSize = 13.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Chip(if (h.connectedName == d.name) "Conectado" else "Conectar", h.connectedName == d.name, Neon.Green) { h.connect(d) }
                }
            }
        }
        item {
            SectionTitle("MONITOR MIDI (para comprobar cada botón)")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip(if (r.monitorEnabled) "Monitor ACTIVO" else "Activar monitor", r.monitorEnabled, Neon.Green) {
                    r.monitorEnabled = !r.monitorEnabled; if (!r.monitorEnabled) r.log.clear()
                }
            }
            if (r.monitorEnabled) {
                Column(Modifier.padding(top = 6.dp).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF08080A)).padding(8.dp)) {
                    if (r.log.isEmpty()) Text("Mueve o pulsa algo en el controlador…", color = Neon.Gray, fontSize = 11.sp)
                    for (line in r.log) Text(line, color = Neon.Green, fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                }
            }
        }
        item {
            SectionTitle("MAPEO DEL INPULSE 200")
            Text(
                "Mapa OFICIAL del Inpulse 200 (lista de comandos MIDI de Hercules) ya integrado: no hace falta configurar nada. Si algún control no responde: " +
                    "MAPEO RÁPIDO = solo pulsas los controles del Deck A y el Deck B se copia solo (≈1 min). MAPEO COMPLETO = pide también el Deck B. " +
                    "Usa el monitor para verificar. Se guarda automáticamente.",
                color = Neon.Gray, fontSize = 12.sp
            )
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("▶ Mapeo rápido (A→B)", r.wizardActive, Neon.DeckB) { r.startWizard(true) }
                Chip("Mapeo completo", false, Neon.DeckA) { r.startWizard(false) }
                Chip("Copiar A→B", false, Neon.Violet) { r.mirrorDecks(); s.toast("Deck B copiado del A (canal +1)") }
            }
            Row(Modifier.padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("Restaurar valores por defecto", false) { r.resetMap(s.defaultMapJson); s.toast("Mapa restaurado") }
            }
            val lt = r.learning
            if (lt != null) {
                val who = when (lt.second) { 0 -> "Deck A"; 1 -> "Deck B"; else -> "Global" }
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF2A1740)).padding(12.dp)
                ) {
                    Text(
                        (if (r.wizardActive) "Paso ${r.wizardIndex + 1} de ${r.wizardTotal}: " else "Aprendiendo: ") + "${lt.first.label} · $who",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp
                    )
                    Text(
                        if (lt.first.isCc) "Mueve ese control en el controlador (fader, knob o jog)." else "Pulsa ese botón/pad en el controlador.",
                        color = Neon.PadBorder, fontSize = 12.sp
                    )
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (r.wizardActive) Chip("Saltar", false) { r.wizardSkip() }
                        Chip("Cancelar", false, Neon.Red) { r.cancelLearn() }
                    }
                }
            }
            SectionTitle("TABLA DE ASIGNACIONES")
        }
        val rows = Action.values().flatMap { a -> if (a.perDeck) listOf(a to 0, a to 1) else listOf(a to -1) }
        itemsIndexed(rows) { _, (act, deck) ->
            val b = r.map.bindingFor(act, deck)
            val learningThis = r.learning?.let { it.first == act && it.second == deck } == true
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
                    .background(if (learningThis) Color(0xFF2A1740) else Color.Transparent).padding(vertical = 3.dp, horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    act.label + when (deck) { 0 -> "  · A"; 1 -> "  · B"; else -> "" },
                    color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f)
                )
                Text(MidiMap.describe(b), color = if (b == null) Neon.Red else Neon.Gray, fontSize = 11.sp)
                Chip(if (learningThis) "…" else "Aprender", learningThis, Neon.DeckB) { r.startLearn(act, deck) }
            }
        }
    }
}

@Composable
private fun OutRow(label: String, selected: Boolean, onSelect: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp))
            .background(if (selected) Color(0x2200F0FF) else Color(0xFF181A22))
            .clickable(onClick = onSelect).padding(horizontal = 12.dp, vertical = 9.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text(if (selected) "●" else "○", color = if (selected) Neon.DeckA else Neon.Gray, fontSize = 14.sp)
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun AudioTab(s: DjSession) {
    val e = s.engine
    var jog by remember { mutableStateOf(s.prefs.jogSecPerTick) }
    var invert by remember { mutableStateOf(s.prefs.pitchInvert) }
    var cueVol by remember { mutableStateOf(e.cueVolume) }
    var cueMix by remember { mutableStateOf(e.cueMix) }
    androidx.compose.runtime.LaunchedEffect(Unit) { e.refreshOutputs() }
    Column(
        Modifier.fillMaxSize().verticalScroll(androidx.compose.foundation.rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        SectionTitle("SALIDA PRINCIPAL (la mezcla para el público)")
        OutRow("Automático (lo decide Android)", e.masterKey.isEmpty()) { s.setMasterOut("") }
        for (o in e.outputs) OutRow(o.label, e.masterKey == o.key) { s.setMasterOut(o.key) }
        SectionTitle("PRE-ESCUCHA (auriculares / cue)")
        OutRow("Ninguna propia (usa el SPLIT del cable o la misma salida)", e.cueKey.isEmpty()) { s.setCueOut("") }
        OutRow(
            "🎧 Auriculares del controlador DJ (cable USB): master = salida 1-2 · auriculares = 3-4",
            e.cueKey == com.neondeck.dj.audio.AudioEngine.CUE_CH34
        ) { s.setCueOut(com.neondeck.dj.audio.AudioEngine.CUE_CH34) }
        if (e.cueKey == com.neondeck.dj.audio.AudioEngine.CUE_CH34) {
            Text(
                if (e.quadActive) "● Activo: el controlador recibe 4 canales. Pulsa PFL/CUE en un deck para escucharlo en los auriculares; sin PFL oyes la mezcla."
                else "○ No se pudo abrir 4 canales" + (if (e.quadStatus.isNotEmpty()) ": ${e.quadStatus}" else "") + ". Prueba otro cable/adaptador OTG o usa otra salida de pre-escucha.",
                color = if (e.quadActive) Neon.Green else Neon.Red, fontSize = 11.sp, fontWeight = FontWeight.Bold
            )
        }
        for (o in e.outputs) OutRow(o.label, e.cueKey == o.key) { s.setCueOut(o.key) }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Volumen de pre-escucha", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(170.dp))
            Slider(
                value = cueVol, onValueChange = { cueVol = it; e.cueVolume = it; s.prefs.cueVolume = it },
                valueRange = 0f..1f, modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = Neon.DeckA, activeTrackColor = Neon.DeckA)
            )
            Text("${(cueVol * 100).toInt()}%", color = Neon.Gray, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Mezcla cue ↔ master", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(170.dp))
            Slider(
                value = cueMix, onValueChange = { cueMix = it; e.cueMix = it; s.prefs.cueMix = it },
                valueRange = 0f..1f, modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = Neon.DeckB, activeTrackColor = Neon.DeckB)
            )
            Text("${(cueMix * 100).toInt()}%", color = Neon.Gray, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Text(
            "Con una pre-escucha propia, los auriculares oyen el deck con PFL activado (o la mezcla si ninguno lo tiene) y la salida principal queda limpia. " +
                "Bluetooth añade retraso (≈150-250 ms): úsalo mejor para la mezcla principal y deja el cable/USB para la pre-escucha. " +
                "Algunos teléfonos solo permiten una salida a la vez.",
            color = Neon.Gray, fontSize = 11.sp
        )
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("↻ Buscar salidas", false) { e.refreshOutputs(); e.applyOutputs() }
        }
        SectionTitle("ESTADO")
        Text("Frecuencia ${e.outRate} Hz · bloque ${e.blockFrames} frames · latencia de búfer ≈${"%.1f".format(e.latencyMs)} ms (se ajusta sola) · cortes ${e.underruns}", color = Neon.Gray, fontSize = 12.sp)
        SectionTitle("JOG DEL CONTROLADOR")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Sensibilidad del scratch", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(170.dp))
            Slider(
                value = jog, onValueChange = { jog = it; s.prefs.jogSecPerTick = it },
                valueRange = 0.0005f..0.006f, modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = Neon.DeckA, activeTrackColor = Neon.DeckA)
            )
            Text("%.4f s/tick".format(jog), color = Neon.Gray, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Fader de tempo del controlador", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(170.dp))
            Chip("Normal", !invert) { invert = false; s.prefs.pitchInvert = false }
            Chip("Invertido", invert) { invert = true; s.prefs.pitchInvert = true }
        }
        SectionTitle("PANTALLA")
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Tema", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(170.dp))
            Chip("Noche", !Neon.day) { Neon.day = false; s.prefs.dayMode = false }
            Chip("☀ Día (más brillo y contraste)", Neon.day) { Neon.day = true; s.prefs.dayMode = true }
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Zoom de las ondas (doble toque en las ondas)", color = Color.White, fontSize = 12.sp)
            for (i in ZOOMS.indices) Chip("${ZOOMS[i].toInt()} s", s.zoomIndex == i) { s.zoomIndex = i; s.prefs.zoomIndex = i }
        }
    }
}

@Composable
private fun AboutTab() {
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SectionTitle("NEON by DARVI'S · 1.1")
        Text(
            "• 2 decks con scratch suave, pitch bend, sync de tempo y fase, loops, rolls, 8 hot cues, 8 samples\n" +
                "• Formatos: WAV (8/16/24/32 bits y float), MP3, FLAC, AAC/M4A, OGG y más\n" +
                "• Carga casi instantánea (streaming) y BPM rápido de toda la biblioteca\n" +
                "• EQ de 3 bandas con kill, filtro, Echo / Flanger / Reverb por deck\n" +
                "• Detección automática de BPM, rejilla de beats y tonalidad (Camelot)\n" +
                "• Grabación de la mezcla a WAV · MIDI USB con LEDs de retorno\n\n" +
                "Atajos en pantalla: doble toque en las ondas = zoom · doble toque en el crossfader = centro · " +
                "pulsación larga en el botón LOOP = cambiar tamaño · pulsación larga en un pad de Sampler = cargar tu sonido.",
            color = Neon.Gray, fontSize = 12.sp
        )
    }
}


@Composable
private fun CrashReport(s: DjSession) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var txt: String by remember { mutableStateOf(CrashLog.read(ctx)) }
    val clip = androidx.compose.ui.platform.LocalClipboardManager.current
    Column(Modifier.fillMaxWidth().padding(top = 12.dp)) {
        SectionTitle("ÚLTIMO ERROR REGISTRADO")
        if (txt.isEmpty()) Text("Ninguno.", color = Neon.Gray, fontSize = 12.sp)
        else {
            Text(txt.take(1800), color = Color(0xFFFFB4B4), fontSize = 10.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Copiar", false) { clip.setText(androidx.compose.ui.text.AnnotatedString(txt)) }
                Chip("Borrar", false) { CrashLog.clear(ctx); txt = "" }
            }
        }
    }
}
