package com.neondeck.dj.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.neondeck.dj.DjSession
import com.neondeck.dj.audio.Deck
import com.neondeck.dj.midi.Action
import com.neondeck.dj.midi.MidiMap

@Composable
fun Chip(text: String, selected: Boolean, color: Color = Neon.DeckA, onClick: () -> Unit) {
    Text(
        text, color = if (selected) Color.White else Neon.Gray, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(14.dp))
            .background(if (selected) color else Color(0xFF1E1E23))
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 6.dp)
    )
}

@Composable
private fun SheetScaffold(title: String, onClose: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Color(0xD0000000))
            .pointerInput(Unit) { detectTapGestures(onTap = { onClose() }) }
            .safeDrawingPadding(),
        contentAlignment = Alignment.Center
    ) {
        Column(
            Modifier.fillMaxWidth(0.95f).fillMaxHeight(0.94f)
                .clip(RoundedCornerShape(16.dp)).background(Neon.Panel)
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(title, color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Chip("✕  Cerrar", false, onClick = onClose)
            }
            Spacer(Modifier.height(8.dp))
            content()
        }
    }
}

// ============================================================================ MEZCLADOR

@Composable
fun MixerSheet(s: DjSession, frame: State<Long>) {
    SheetScaffold("MEZCLADOR", { s.mixerOpen = false }) {
        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            ChannelStrip(s.engine.deckA, Modifier.weight(1f))
            MasterStrip(s, frame, Modifier.width(210.dp))
            ChannelStrip(s.engine.deckB, Modifier.weight(1f))
        }
    }
}

@Composable
private fun ChannelStrip(d: Deck, modifier: Modifier) {
    val c = Neon.deck(d.index)
    Column(modifier.clip(RoundedCornerShape(12.dp)).background(Neon.Panel2).padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (d.index == 0) "DECK A" else "DECK B", color = c, fontWeight = FontWeight.Black, fontSize = 14.sp, modifier = Modifier.weight(1f))
            Chip("CUE 🎧", d.pfl, c) { d.pfl = !d.pfl }
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
            Knob(d.gain, 0f, 2f, 1f, "GAIN", c, { d.gain = it })
            Knob(d.eqHigh, 0f, 1.5f, 1f, "HI", c, { d.eqHigh = it })
            Knob(d.eqMid, 0f, 1.5f, 1f, "MID", c, { d.eqMid = it })
            Knob(d.eqLow, 0f, 1.5f, 1f, "LOW", c, { d.eqLow = it })
            Knob(d.filter, -1f, 1f, 0f, "FILTER", c, { d.filter = it }, bipolarCenter = true)
        }
        Text("EFECTO", color = Neon.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("OFF", d.fxType == 0, c) { d.fxType = 0 }
            Chip("ECHO", d.fxType == 1, c) { d.fxType = 1 }
            Chip("FLANGER", d.fxType == 2, c) { d.fxType = 2 }
            Chip("REVERB", d.fxType == 3, c) { d.fxType = 3 }
            Spacer(Modifier.weight(1f))
            Knob(d.fxAmount, 0f, 1f, 0.5f, "MIX", c, { d.fxAmount = it }, size = 40.dp)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Chip("VINYL", d.vinyl, c) { d.vinyl = !d.vinyl }
            Chip("RANGO ±${(d.range * 100).toInt()}%", false, c) { d.cycleRange() }
            Chip("SYNC", d.syncOn, c) { d.syncOn = false }
        }
    }
}

@Composable
private fun MasterStrip(s: DjSession, frame: State<Long>, modifier: Modifier) {
    val e = s.engine
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(Neon.Panel2).padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Text("MASTER", color = Color.White, fontWeight = FontWeight.Black, fontSize = 13.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
            LedMeter({ e.masterLevelL }, frame, Modifier.width(9.dp).height(80.dp))
            Knob(e.masterGain, 0f, 1.2f, 0.85f, "VOL", Color.White, { e.masterGain = it }, size = 56.dp)
            LedMeter({ e.masterLevelR }, frame, Modifier.width(9.dp).height(80.dp))
        }
        Text("CROSSFADER", color = Neon.Gray, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            val names = listOf("MIX", "CUT", "POW")
            for (i in 0..2) Chip(names[i], e.crossfaderCurve == i, Neon.Gray) { e.crossfaderCurve = i; s.prefs.crossfaderCurve = i }
        }
        Chip("SPLIT CUE (L=cue R=master)", e.headphoneSplit, Neon.Green) {
            e.headphoneSplit = !e.headphoneSplit; s.prefs.headphoneSplit = e.headphoneSplit
        }
        val sec = run { frame.value; e.recorder.seconds }
        Chip(if (e.recording) "■ GRABANDO ${fmtTime(sec.toDouble())}" else "● GRABAR MEZCLA", e.recording, Neon.Red) {
            val f = e.toggleRecording()
            s.toast(if (e.recording) "Grabando…" else "Guardado: ${f?.name ?: ""}")
        }
    }
}

// ============================================================================ LIBRERÍA

@Composable
fun LibrarySheet(s: DjSession) {
    val list = s.filteredLibrary()
    val state = rememberLazyListState()
    LaunchedEffect(s.libraryIndex, list.size) {
        if (list.isNotEmpty()) state.animateScrollToItem(s.libraryIndex.coerceIn(0, list.size - 1))
    }
    SheetScaffold("LIBRERÍA", { s.libraryOpen = false }) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("→ DECK A", s.libraryTarget == 0, Neon.DeckA) { s.libraryTarget = 0 }
            Chip("→ DECK B", s.libraryTarget == 1, Neon.DeckB) { s.libraryTarget = 1 }
            Box(
                Modifier.weight(1f).height(34.dp).clip(RoundedCornerShape(17.dp)).background(Color(0xFF1E1E23)).padding(horizontal = 14.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                if (s.libraryQuery.isEmpty()) Text("Buscar título o artista…", color = Neon.Gray, fontSize = 13.sp)
                BasicTextField(
                    value = s.libraryQuery,
                    onValueChange = { s.libraryQuery = it; s.libraryIndex = 0 },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 13.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
            }
            Chip("📁 Archivos…", false) { s.pickTrack(s.libraryTarget) }
            Chip("↻", false) { s.scanLibrary() }
        }
        Spacer(Modifier.height(8.dp))
        when {
            !s.libraryLoaded -> Text("Buscando música en el dispositivo…", color = Neon.Gray, modifier = Modifier.padding(12.dp))
            list.isEmpty() -> Text(
                "No se encontró música. Concede el permiso de audio o usa «Archivos…» para elegir un tema.",
                color = Neon.Gray, modifier = Modifier.padding(12.dp)
            )
            else -> LazyColumn(Modifier.fillMaxSize(), state = state) {
                itemsIndexed(list) { i, item ->
                    val sel = i == s.libraryIndex
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                            .background(if (sel) Color(0xFF26262D) else Color.Transparent)
                            .clickable { s.libraryIndex = i }
                            .padding(horizontal = 10.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(item.title, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(item.artist, color = Neon.Gray, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        val secs = (item.durationMs / 1000).toInt()
                        Text("%d:%02d".format(secs / 60, secs % 60), color = Neon.Gray, fontSize = 11.sp)
                        Chip("A", false, Neon.DeckA) { s.loadTrack(0, item.uri); s.libraryOpen = false }
                        Chip("B", false, Neon.DeckB) { s.loadTrack(1, item.uri); s.libraryOpen = false }
                    }
                }
            }
        }
    }
}

// ============================================================================ AJUSTES + MIDI

@Composable
fun SettingsSheet(s: DjSession) {
    var tab by remember { mutableIntStateOf(0) }
    SheetScaffold("AJUSTES", { s.settingsOpen = false; s.router.monitorEnabled = false; s.router.cancelLearn() }) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Chip("MIDI / Controlador", tab == 0) { tab = 0 }
            Chip("Audio", tab == 1) { tab = 1 }
            Chip("Acerca de", tab == 2) { tab = 2 }
        }
        Spacer(Modifier.height(8.dp))
        when (tab) {
            0 -> MidiTab(s)
            1 -> AudioTab(s)
            else -> AboutTab()
        }
    }
}

@Composable
private fun SectionTitle(t: String) {
    Text(t, color = Neon.DeckA, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(top = 10.dp, bottom = 4.dp))
}

@Composable
private fun MidiTab(s: DjSession) {
    val r = s.router
    val h = s.midi
    LazyColumn(Modifier.fillMaxSize()) {
        item {
            SectionTitle("CONTROLADOR USB")
            val ok = h.connectedName != null
            Text(
                if (ok) "● ${h.status}" else "○ ${h.status}", color = if (ok) Neon.Green else Neon.Gray,
                fontWeight = FontWeight.Bold, fontSize = 13.sp
            )
            if (h.devices.isEmpty()) {
                Text(
                    "Conecta el Hercules DJControl Inpulse 200 con un cable USB-OTG. Android lo detecta como dispositivo MIDI estándar (no requiere driver).",
                    color = Neon.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 6.dp)
                )
            }
            Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("↻ Buscar", false) { h.refresh(); h.autoConnect() }
                if (ok) Chip("Desconectar", false, Neon.Red) { h.disconnectByUser() }
            }
            for (d in h.devices) {
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text(
                        d.name + (if (d.canSend) "  · LEDs" else ""), color = Color.White, fontSize = 13.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Chip(if (h.connectedName == d.name) "Conectado" else "Conectar", h.connectedName == d.name, Neon.Green) { h.connect(d) }
                }
            }
        }
        item {
            SectionTitle("MONITOR MIDI (para comprobar cada botón)")
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip(if (r.monitorEnabled) "Monitor ACTIVO" else "Activar monitor", r.monitorEnabled, Neon.Green) {
                    r.monitorEnabled = !r.monitorEnabled; if (!r.monitorEnabled) r.log.clear()
                }
            }
            if (r.monitorEnabled) {
                Column(Modifier.padding(top = 6.dp).fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF08080A)).padding(8.dp)) {
                    if (r.log.isEmpty()) Text("Mueve o pulsa algo en el controlador…", color = Neon.Gray, fontSize = 11.sp)
                    for (line in r.log) Text(line, color = Neon.Green, fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
                }
            }
        }
        item {
            SectionTitle("MAPEO DEL INPULSE 200")
            Text(
                "El mapa por defecto es una base editable. Para asegurar que cada control coincide con tu unidad, usa el MAPEO GUIADO: " +
                    "la app te pide cada control uno por uno y aprende su nota/CC real (≈2 min). Se guarda automáticamente.",
                color = Neon.Gray, fontSize = 12.sp
            )
            Row(Modifier.padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("▶ Mapeo guiado", r.wizardActive, Neon.DeckB) { r.startWizard() }
                Chip("Restaurar valores por defecto", false) { r.resetMap(s.defaultMapJson); s.toast("Mapa restaurado") }
            }
            val lt = r.learning
            if (lt != null) {
                val who = when (lt.second) { 0 -> "Deck A"; 1 -> "Deck B"; else -> "Global" }
                Column(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color(0xFF2A1740)).padding(12.dp)
                ) {
                    Text(
                        (if (r.wizardActive) "Paso ${r.wizardIndex + 1} de ${r.wizardTotal}: " else "Aprendiendo: ") + "${lt.first.label} · $who",
                        color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp
                    )
                    Text(
                        if (lt.first.isCc) "Mueve ese control en el controlador (fader, knob o jog)." else "Pulsa ese botón/pad en el controlador.",
                        color = Neon.PadBorder, fontSize = 12.sp
                    )
                    Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        if (r.wizardActive) Chip("Saltar", false) { r.wizardSkip() }
                        Chip("Cancelar", false, Neon.Red) { r.cancelLearn() }
                    }
                }
            }
            SectionTitle("TABLA DE ASIGNACIONES")
        }
        val rows = Action.values().flatMap { a -> if (a.perDeck) listOf(a to 0, a to 1) else listOf(a to -1) }
        itemsIndexed(rows) { _, (act, deck) ->
            val b = r.map.bindingFor(act, deck)
            val learningThis = r.learning?.let { it.first == act && it.second == deck } == true
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp))
                    .background(if (learningThis) Color(0xFF2A1740) else Color.Transparent).padding(vertical = 3.dp, horizontal = 6.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    act.label + when (deck) { 0 -> "  · A"; 1 -> "  · B"; else -> "" },
                    color = Color.White, fontSize = 12.sp, modifier = Modifier.weight(1f)
                )
                Text(MidiMap.describe(b), color = if (b == null) Neon.Red else Neon.Gray, fontSize = 11.sp)
                Chip(if (learningThis) "…" else "Aprender", learningThis, Neon.DeckB) { r.startLearn(act, deck) }
            }
        }
    }
}

@Composable
private fun AudioTab(s: DjSession) {
    val e = s.engine
    var jog by remember { mutableStateOf(s.prefs.jogSecPerTick) }
    var invert by remember { mutableStateOf(s.prefs.pitchInvert) }
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SectionTitle("SALIDA")
        Text("Frecuencia ${e.outRate} Hz · bloque ${e.blockFrames} frames (≈${"%.1f".format(e.blockFrames * 1000f / e.outRate)} ms) · underruns ${e.underruns}", color = Neon.Gray, fontSize = 12.sp)
        SectionTitle("JOG DEL CONTROLADOR")
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Sensibilidad del scratch", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(170.dp))
            Slider(
                value = jog, onValueChange = { jog = it; s.prefs.jogSecPerTick = it },
                valueRange = 0.0005f..0.006f, modifier = Modifier.weight(1f),
                colors = SliderDefaults.colors(thumbColor = Neon.DeckA, activeTrackColor = Neon.DeckA)
            )
            Text("%.4f s/tick".format(jog), color = Neon.Gray, fontSize = 11.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Fader de tempo del controlador", color = Color.White, fontSize = 12.sp, modifier = Modifier.width(170.dp))
            Chip("Normal", !invert) { invert = false; s.prefs.pitchInvert = false }
            Chip("Invertido", invert) { invert = true; s.prefs.pitchInvert = true }
        }
        SectionTitle("PANTALLA")
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Zoom de las ondas (doble toque en las ondas)", color = Color.White, fontSize = 12.sp)
            for (i in ZOOMS.indices) Chip("${ZOOMS[i].toInt()} s", s.zoomIndex == i) { s.zoomIndex = i; s.prefs.zoomIndex = i }
        }
    }
}

@Composable
private fun AboutTab() {
    Column(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        SectionTitle("NEONDECK DJ 1.0")
        Text(
            "• 2 decks con scratch, pitch bend, sync de tempo y fase, loops, rolls, 8 hot cues, 8 samples\n" +
                "• EQ de 3 bandas con kill, filtro, Echo / Flanger / Reverb por deck\n" +
                "• Detección automática de BPM, rejilla de beats y tonalidad (Camelot)\n" +
                "• Grabación de la mezcla a WAV · MIDI USB con LEDs de retorno\n\n" +
                "Atajos en pantalla: doble toque en las ondas = zoom · doble toque en el crossfader = centro · " +
                "pulsación larga en el botón LOOP = cambiar tamaño · pulsación larga en un pad de Sampler = cargar tu sonido.",
            color = Neon.Gray, fontSize = 12.sp
        )
    }
}
