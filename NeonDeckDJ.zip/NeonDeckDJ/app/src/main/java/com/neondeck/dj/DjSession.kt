package com.neondeck.dj

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.neondeck.dj.audio.Analyzer
import com.neondeck.dj.audio.AudioEngine
import com.neondeck.dj.audio.Deck
import com.neondeck.dj.audio.LoadedTrack
import com.neondeck.dj.audio.TrackLoader
import com.neondeck.dj.midi.MidiHost
import com.neondeck.dj.midi.MidiRouter
import com.neondeck.dj.midi.UiHooks
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import java.util.concurrent.atomic.AtomicInteger
import kotlin.concurrent.thread

class LibItem(
    val uri: Uri,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val folderPath: String,
    val folderName: String
) {
    val id: String = uri.toString()
    var bpm by mutableStateOf<Float?>(null)
}

class FolderInfo(val path: String, val name: String, val count: Int)

/** Contenedor de todo el estado de la app: motor de audio, MIDI, librería y paneles. */
class DjSession(private val ctx: Context) : UiHooks {
    val prefs = Prefs(ctx)
    val engine = AudioEngine(ctx)
    val router = MidiRouter(engine, prefs, this)
    val midi = MidiHost(ctx) { s, a, b -> router.onMessage(s, a, b) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var ledJob: Job? = null

    // ---- paneles
    var libraryOpen by mutableStateOf(false)
    var libraryTarget by mutableIntStateOf(0)
    var mixerOpen by mutableStateOf(false)
    var settingsOpen by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var zoomIndex by mutableIntStateOf(1)

    // ---- librería
    val library = mutableStateListOf<LibItem>()
    private val libById = HashMap<String, LibItem>()
    var libraryQuery by mutableStateOf("")
    var libraryIndex by mutableIntStateOf(0)
    var libraryLoaded by mutableStateOf(false)
    var libTab by mutableIntStateOf(0)                    // 0 = canciones, 1 = carpetas
    var openFolder by mutableStateOf<String?>(null)       // carpeta abierta en la pestaña Carpetas
    var treeCount by mutableIntStateOf(0)

    /** Temas ya tocados en ESTA sesión (se resaltan; al cerrar la app todo vuelve a como estaba). */
    val playedIds = mutableStateListOf<String>()

    // ---- análisis de BPM en lote
    var analyzing by mutableStateOf(false)
    var analyzeDone by mutableIntStateOf(0)
    var analyzeTotal by mutableIntStateOf(0)
    private var analyzeJob: Job? = null

    // ---- carga / precarga
    private val tokens = arrayOfNulls<TrackLoader.Token>(2)
    private var preTrack: LoadedTrack? = null
    private var preToken: TrackLoader.Token? = null
    private var preId: String? = null

    var defaultMapJson: String = ""
        private set

    fun folders(): List<FolderInfo> =
        library.groupBy { it.folderPath }
            .map { (path, items) -> FolderInfo(path, items.first().folderName, items.size) }
            .sortedBy { it.name.lowercase() }

    fun filteredLibrary(): List<LibItem> {
        val q = libraryQuery.trim()
        val folder = if (libTab == 1) openFolder else null
        return library.filter { item ->
            (folder == null || item.folderPath == folder) &&
                (q.isEmpty() || item.title.contains(q, true) || item.artist.contains(q, true))
        }
    }

    fun start() {
        val defJson = ctx.assets.open("midi/hercules_inpulse_200.json").bufferedReader().use { it.readText() }
        defaultMapJson = defJson
        router.loadMap(defJson)
        router.host = midi
        engine.crossfaderCurve = prefs.crossfaderCurve
        engine.headphoneSplit = prefs.headphoneSplit
        zoomIndex = prefs.zoomIndex
        treeCount = prefs.treeUris.size
        engine.start()
        midi.start()
        ledJob = scope.launch {
            while (true) {
                router.updateLeds()
                for (d in listOf(engine.deckA, engine.deckB)) {
                    val t = d.track ?: continue
                    if (d.playing && !playedIds.contains(t.id)) playedIds.add(t.id)
                    if (t.bpm > 0f) {
                        val item = libById[t.id]
                        if (item != null && item.bpm == null) item.bpm = t.bpm
                    }
                }
                delay(70)
            }
        }
    }

    fun stop() {
        ledJob?.cancel()
        analyzeJob?.cancel()
        tokens.forEach { it?.cancelled = true }
        preToken?.cancelled = true
        playedIds.clear()
        midi.stop()
        engine.stop()
        scope.cancel()
    }

    /** Los asigna MainActivity (selectores de archivos del sistema). */
    var pickTrackHandler: (Int) -> Unit = {}
    var pickSampleHandler: (Int) -> Unit = {}
    var pickFolderHandler: () -> Unit = {}
    fun pickTrack(deck: Int) = pickTrackHandler(deck)
    fun pickSample(slot: Int) = pickSampleHandler(slot)
    fun pickFolder() = pickFolderHandler()

    fun toast(msg: String) { message = msg }

    // ---------------------------------------------------------------- carga de pistas
    private fun attach(d: Deck, t: LoadedTrack) {
        val needColor = t.deckIndex != d.index
        t.deckIndex = d.index
        d.load(t)
        d.loading = false
        d.loadProgress = 1f
        if (needColor && t.complete) {
            thread(name = "dj-overview") { t.wave.overview = Analyzer.overviewBitmap(t.wave, d.index) }
        }
    }

    /** Carga en streaming: el deck puede sonar a los ~1.5 s; si el tema estaba precargado es instantáneo. */
    fun loadTrack(deckIdx: Int, uri: Uri) {
        val d = engine.deck(deckIdx)
        val id = uri.toString()
        tokens[deckIdx]?.cancelled = true

        val pt = preTrack
        if (pt != null && preId == id && !pt.cancelled) {
            tokens[deckIdx] = preToken
            preTrack = null; preToken = null; preId = null
            attach(d, pt)
            return
        }
        if (preId == id) { preToken?.cancelled = true; preTrack = null; preToken = null; preId = null }

        d.loading = true
        d.loadProgress = 0.1f
        val tok = TrackLoader.Token()
        tokens[deckIdx] = tok
        thread(name = "dj-load-$deckIdx") {
            TrackLoader.load(
                ctx, uri, deckIdx, prefs, tok,
                onReady = { t -> if (!tok.cancelled) attach(d, t) },
                onError = { e ->
                    if (!tok.cancelled) {
                        d.loading = false
                        toast("No se pudo cargar la pista: ${e.message ?: e.javaClass.simpleName}")
                    }
                }
            )
        }
    }

    /** Decodifica en segundo plano el tema seleccionado para que al pulsar A/B cargue al instante. */
    private fun preload(item: LibItem) {
        if (preId == item.id) return
        preToken?.cancelled = true
        preTrack?.cancelled = true
        preTrack = null
        if (item.durationMs > 15 * 60_000L) { preId = null; preToken = null; return }
        val tok = TrackLoader.Token()
        preToken = tok
        preId = item.id
        val deck = libraryTarget
        thread(name = "dj-preload") {
            TrackLoader.load(
                ctx, item.uri, deck, prefs, tok,
                onReady = { t -> if (!tok.cancelled && preId == item.id) preTrack = t },
                onError = { }
            )
        }
    }

    fun selectItem(index: Int, item: LibItem) {
        libraryIndex = index
        preload(item)
        if (item.bpm == null) {
            scope.launch {
                item.bpm = withContext(Dispatchers.Default) { TrackLoader.quickBpm(ctx, item.uri, prefs) }
            }
        }
    }

    fun loadSampleIntoSlot(slot: Int, uri: Uri) {
        scope.launch {
            try {
                val name = TrackLoader.displayName(ctx, uri).take(14).uppercase()
                val data = withContext(Dispatchers.Default) { TrackLoader.decodeMono(ctx, uri, engine.outRate) }
                engine.sampler.setSample(slot, name, data)
            } catch (e: Throwable) {
                toast("No se pudo cargar el sample: ${e.message ?: ""}")
            }
        }
    }

    // ---------------------------------------------------------------- librería
    private val audioExt = setOf("mp3", "wav", "flac", "m4a", "aac", "ogg", "opus", "wma", "aiff", "aif")

    private fun scanTree(treeUri: Uri, out: MutableList<LibItem>) {
        val rootId = try { DocumentsContract.getTreeDocumentId(treeUri) } catch (_: Exception) { return }
        fun walk(docId: String, folderName: String, depth: Int) {
            val children = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, docId)
            try {
                ctx.contentResolver.query(
                    children,
                    arrayOf(
                        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
                        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
                        DocumentsContract.Document.COLUMN_MIME_TYPE
                    ), null, null, null
                )?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getString(0) ?: continue
                        val name = c.getString(1) ?: ""
                        val mime = c.getString(2) ?: ""
                        if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                            if (depth < 6) walk(id, name, depth + 1)
                        } else if (mime.startsWith("audio/") || name.substringAfterLast('.', "").lowercase() in audioExt) {
                            val item = LibItem(
                                DocumentsContract.buildDocumentUriUsingTree(treeUri, id),
                                name.substringBeforeLast('.'), "", 0L, "saf:$docId", folderName
                            )
                            item.bpm = prefs.bpmOf(item.id)
                            out.add(item)
                        }
                    }
                }
            } catch (_: Exception) { }
        }
        walk(rootId, rootId.substringAfterLast(':').substringAfterLast('/').ifEmpty { "Carpeta" }, 0)
    }

    fun scanLibrary() {
        scope.launch {
            val items = withContext(Dispatchers.IO) {
                val out = ArrayList<LibItem>()
                try {
                    val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                    val proj = arrayOf(
                        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION,
                        MediaStore.Audio.Media.DATA
                    )
                    ctx.contentResolver.query(
                        base, proj, "${MediaStore.Audio.Media.DURATION} > 30000", null,
                        "${MediaStore.Audio.Media.DATE_ADDED} DESC"
                    )?.use { c ->
                        while (c.moveToNext()) {
                            val artist = c.getString(2) ?: ""
                            val path = c.getString(4) ?: ""
                            val low = path.lowercase()
                            if (low.contains("/ringtones/") || low.contains("/notifications/") || low.contains("/alarms/")) continue
                            val folderPath = path.substringBeforeLast('/', "")
                            val item = LibItem(
                                ContentUris.withAppendedId(base, c.getLong(0)),
                                c.getString(1) ?: "?",
                                if (artist == "<unknown>") "" else artist,
                                c.getLong(3),
                                folderPath,
                                folderPath.substringAfterLast('/').ifEmpty { "(sin carpeta)" }
                            )
                            item.bpm = prefs.bpmOf(item.id)
                            out.add(item)
                        }
                    }
                } catch (_: SecurityException) { }
                for (t in prefs.treeUris) {
                    try { scanTree(Uri.parse(t), out) } catch (_: Exception) { }
                }
                out
            }
            library.clear()
            library.addAll(items)
            libById.clear()
            for (i in items) libById[i.id] = i
            libraryLoaded = true
        }
    }

    fun addFolder(uri: Uri) {
        prefs.treeUris = prefs.treeUris + uri.toString()
        treeCount = prefs.treeUris.size
        scanLibrary()
        toast("Carpeta añadida")
    }

    fun clearAddedFolders() {
        prefs.treeUris = emptySet()
        treeCount = 0
        scanLibrary()
    }

    /** Analiza el BPM de los temas pendientes en paralelo (≈40 s de audio por tema). */
    fun analyzeAll(onlyFolder: String? = null) {
        if (analyzing) { analyzeJob?.cancel(); analyzing = false; return }
        val pending = library.filter { it.bpm == null && (onlyFolder == null || it.folderPath == onlyFolder) }
        if (pending.isEmpty()) { toast("Todos los temas ya tienen BPM"); return }
        analyzing = true
        analyzeDone = 0
        analyzeTotal = pending.size
        analyzeJob = scope.launch {
            val done = AtomicInteger(0)
            try {
                val sem = Semaphore(3)
                coroutineScope {
                    for (item in pending) launch(Dispatchers.Default) {
                        sem.withPermit {
                            if (isActive) {
                                val b = TrackLoader.quickBpm(ctx, item.uri, prefs)
                                val n = done.incrementAndGet()
                                withContext(Dispatchers.Main) { item.bpm = b; analyzeDone = n }
                            }
                        }
                    }
                }
                toast("BPM analizado en ${pending.size} temas")
            } finally {
                analyzing = false
            }
        }
    }

    // ---------------------------------------------------------------- UiHooks (MIDI)
    override fun requestLoad(deck: Int) {
        libraryTarget = deck.coerceIn(0, 1)
        libraryOpen = true
        if (!libraryLoaded) scanLibrary()
    }

    override fun browseMove(delta: Int) {
        if (!libraryOpen) { libraryOpen = true; if (!libraryLoaded) scanLibrary(); return }
        val list = filteredLibrary()
        if (list.isNotEmpty()) {
            val i = (libraryIndex + delta).coerceIn(0, list.size - 1)
            selectItem(i, list[i])
        }
    }

    override fun browsePress() {
        if (!libraryOpen) { libraryOpen = true; if (!libraryLoaded) scanLibrary(); return }
        val list = filteredLibrary()
        if (libraryIndex in list.indices) {
            loadTrack(libraryTarget, list[libraryIndex].uri)
            libraryOpen = false
        }
    }
}
