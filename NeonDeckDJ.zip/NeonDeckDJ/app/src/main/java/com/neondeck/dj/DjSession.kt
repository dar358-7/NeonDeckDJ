package com.neondeck.dj

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.neondeck.dj.audio.AudioEngine
import com.neondeck.dj.audio.TrackLoader
import com.neondeck.dj.midi.MidiHost
import com.neondeck.dj.midi.MidiRouter
import com.neondeck.dj.midi.UiHooks
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LibItem(val uri: Uri, val title: String, val artist: String, val durationMs: Long)

/** Contenedor de todo el estado de la app: motor de audio, MIDI, librería y paneles. */
class DjSession(private val ctx: Context) : UiHooks {
    val prefs = Prefs(ctx)
    val engine = AudioEngine(ctx)
    val router = MidiRouter(engine, prefs, this)
    val midi = MidiHost(ctx) { s, a, b -> router.onMessage(s, a, b) }
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var ledJob: Job? = null

    // ---- paneles
    var libraryOpen by mutableStateOf(false)
    var libraryTarget by mutableIntStateOf(0)
    var mixerOpen by mutableStateOf(false)
    var settingsOpen by mutableStateOf(false)
    var message by mutableStateOf<String?>(null)
    var zoomIndex by mutableIntStateOf(1)

    // ---- librería
    val library = mutableStateListOf<LibItem>()
    var libraryQuery by mutableStateOf("")
    var libraryIndex by mutableIntStateOf(0)
    var libraryLoaded by mutableStateOf(false)

    fun filteredLibrary(): List<LibItem> {
        val q = libraryQuery.trim()
        return if (q.isEmpty()) library.toList()
        else library.filter { it.title.contains(q, true) || it.artist.contains(q, true) }
    }

    fun start() {
        val defJson = ctx.assets.open("midi/hercules_inpulse_200.json").bufferedReader().use { it.readText() }
        defaultMapJson = defJson
        router.loadMap(defJson)
        router.host = midi
        engine.crossfaderCurve = prefs.crossfaderCurve
        engine.headphoneSplit = prefs.headphoneSplit
        zoomIndex = prefs.zoomIndex
        engine.start()
        midi.start()
        ledJob = scope.launch {
            while (true) {
                router.updateLeds()
                delay(70)
            }
        }
    }

    var defaultMapJson: String = ""
        private set

    fun stop() {
        ledJob?.cancel()
        midi.stop()
        engine.stop()
        scope.cancel()
    }

    /** Los asigna MainActivity (selectores de archivos del sistema). */
    var pickTrackHandler: (Int) -> Unit = {}
    var pickSampleHandler: (Int) -> Unit = {}
    fun pickTrack(deck: Int) = pickTrackHandler(deck)
    fun pickSample(slot: Int) = pickSampleHandler(slot)

    fun toast(msg: String) { message = msg }

    // ---------------------------------------------------------------- carga de pistas
    fun loadTrack(deckIdx: Int, uri: Uri) {
        val d = engine.deck(deckIdx)
        if (d.loading) return
        d.loading = true
        d.loadProgress = 0f
        scope.launch {
            try {
                val t = TrackLoader.load(ctx, uri) { p -> d.loadProgress = p }
                d.load(t)
            } catch (e: Throwable) {
                toast("No se pudo cargar la pista: ${e.message ?: e.javaClass.simpleName}")
            } finally {
                d.loading = false
            }
        }
    }

    fun loadSampleIntoSlot(slot: Int, uri: Uri) {
        scope.launch {
            try {
                val name = TrackLoader.displayName(ctx, uri).take(14).uppercase()
                val data = withContext(Dispatchers.Default) { TrackLoader.decodeMono(ctx, uri, engine.outRate) }
                engine.sampler.setSample(slot, name, data)
            } catch (e: Throwable) {
                toast("No se pudo cargar el sample: ${e.message ?: ""}")
            }
        }
    }

    fun scanLibrary() {
        scope.launch {
            val items = withContext(Dispatchers.IO) {
                val out = ArrayList<LibItem>()
                try {
                    val base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                    val proj = arrayOf(
                        MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                        MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION
                    )
                    ctx.contentResolver.query(
                        base, proj, "${MediaStore.Audio.Media.DURATION} > 30000", null,
                        "${MediaStore.Audio.Media.DATE_ADDED} DESC"
                    )?.use { c ->
                        while (c.moveToNext()) {
                            val artist = c.getString(2) ?: ""
                            out.add(
                                LibItem(
                                    ContentUris.withAppendedId(base, c.getLong(0)),
                                    c.getString(1) ?: "?",
                                    if (artist == "<unknown>") "" else artist,
                                    c.getLong(3)
                                )
                            )
                        }
                    }
                } catch (_: SecurityException) { }
                out
            }
            library.clear()
            library.addAll(items)
            libraryLoaded = true
        }
    }

    // ---------------------------------------------------------------- UiHooks (MIDI)
    override fun requestLoad(deck: Int) {
        libraryTarget = deck.coerceIn(0, 1)
        libraryOpen = true
        if (!libraryLoaded) scanLibrary()
    }

    override fun browseMove(delta: Int) {
        if (!libraryOpen) { libraryOpen = true; if (!libraryLoaded) scanLibrary(); return }
        val n = filteredLibrary().size
        if (n > 0) libraryIndex = (libraryIndex + delta).coerceIn(0, n - 1)
    }

    override fun browsePress() {
        if (!libraryOpen) { libraryOpen = true; if (!libraryLoaded) scanLibrary(); return }
        val list = filteredLibrary()
        if (libraryIndex in list.indices) {
            loadTrack(libraryTarget, list[libraryIndex].uri)
            libraryOpen = false
        }
    }
}
