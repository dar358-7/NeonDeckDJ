package com.neondeck.dj.audio

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.ln
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.sqrt

/** Análisis offline: forma de onda coloreada, BPM, rejilla de beats y tonalidad (Camelot). */
object Analyzer {
    const val BIN = 128
    const val QCOLORS = 24

    private fun lerpC(a: Int, b: Int, t: Float): Int {
        val r = ((a shr 16 and 255) + ((b shr 16 and 255) - (a shr 16 and 255)) * t).toInt()
        val g = ((a shr 8 and 255) + ((b shr 8 and 255) - (a shr 8 and 255)) * t).toInt()
        val bl = ((a and 255) + ((b and 255) - (a and 255)) * t).toInt()
        return (0xFF shl 24) or (r shl 16) or (g shl 8) or bl
    }

    /** Color de la onda por índice (graves -> medios -> agudos). Deck A: azul/cian. Deck B: naranja/ámbar. */
    fun waveColor(i: Int, deck: Int): Int {
        val x = i / (QCOLORS - 1f)
        val low = if (deck == 0) 0xFF2563FF.toInt() else 0xFFFF6A00.toInt()
        val mid = if (deck == 0) 0xFF22D3EE.toInt() else 0xFFFFC21A.toInt()
        val high = 0xFFFFFFFF.toInt()
        return if (x < 0.5f) lerpC(low, mid, x / 0.5f) else lerpC(mid, high, (x - 0.5f) / 0.5f)
    }

    /** Construye la forma de onda en streaming, a medida que llega el PCM. */
    class WaveBuilder(private val w: Waveform, srcRate: Int) {
        private val aL = (1.0 - exp(-2.0 * PI * 250.0 / srcRate)).toFloat()
        private val aH = (1.0 - exp(-2.0 * PI * 2500.0 / srcRate)).toFloat()
        private var l1 = 0f; private var l2 = 0f; private var h1 = 0f; private var h2 = 0f
        private var prevE = 0f
        private var runMax = 0.25f
        var done = 0
            private set

        fun feed(pcm: ShortArray, decodedFrames: Int) {
            val target = decodedFrames / BIN
            if (target <= done) return
            w.ensure(target + 1)
            val peak = w.peak; val color = w.color; val onset = w.onset
            for (b in done until target) {
                var pk = 0f; var eL = 0f; var eM = 0f; var eH = 0f
                val base = b * BIN
                for (i in 0 until BIN) {
                    val idx = (base + i) * 2
                    val x = (pcm[idx] + pcm[idx + 1]) * (0.5f / 32768f)
                    l1 += aL * (x - l1); l2 += aL * (l1 - l2)
                    h1 += aH * (x - h1); h2 += aH * (h1 - h2)
                    eL += abs(l2); eM += abs(h2 - l2); eH += abs(x - h2)
                    val a = abs(x)
                    if (a > pk) pk = a
                }
                if (pk > runMax) runMax = pk
                peak[b] = sqrt(min(1f, pk / runMax))
                val tot = eL + eM + eH + 1e-6f
                val c = ((eM * 0.55f + eH * 1.0f) / tot * 1.8f).coerceIn(0f, 1f)
                color[b] = (c * (QCOLORS - 1)).toInt().toByte()
                val e = eL / BIN + 0.5f * (eM / BIN)
                onset[b] = max(0f, e - prevE)
                prevE = e
            }
            done = target
            w.bins = target
        }
    }

    fun overviewBitmap(w: Waveform, deck: Int, width: Int = 900, height: Int = 48): Bitmap {
        val bmp = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val cv = Canvas(bmp)
        val p = Paint().apply { strokeWidth = 1f; isAntiAlias = false }
        val bins = minOf(w.bins, w.peak.size, w.color.size)
        if (bins == 0) return bmp
        val mid = height / 2f
        for (x in 0 until width) {
            val b0 = (x.toLong() * bins / width).toInt()
            val b1 = max(b0 + 1, ((x + 1).toLong() * bins / width).toInt()).coerceAtMost(bins)
            var best = 0f; var bi = b0
            for (b in b0 until b1) if (w.peak[b] > best) { best = w.peak[b]; bi = b }
            p.color = waveColor(w.color[bi.coerceAtMost(bins - 1)].toInt().coerceIn(0, QCOLORS - 1), deck)
            val h = best * mid * 0.95f
            cv.drawLine(x + 0.5f, mid - h, x + 0.5f, mid + h, p)
        }
        return bmp
    }

    // ------------------------------------------------------------------ BPM

    /**
     * BPM rápido. onsetIn[0 until n] es la envolvente de ataques (hopRate = bins/s).
     * Analiza como máximo 60 s (centrados si hay más). Devuelve (bpm, primer beat en s, relativo al inicio de onsetIn).
     */
    fun detectBpm(onsetIn: FloatArray, n: Int, hopRate: Double): Pair<Float, Double> {
        if (n < hopRate * 8) return 0f to 0.0
        val maxLen = (hopRate * 60).toInt()
        val start = if (n > maxLen + hopRate * 10) (n - maxLen) / 2 else 0
        val end = min(n, start + maxLen)
        val seg = onsetIn.copyOfRange(start, end)
        var mean = 0.0
        for (v in seg) mean += v
        mean /= seg.size
        for (i in seg.indices) seg[i] = max(0f, seg[i] - (mean * 0.8).toFloat())

        fun acf(lag: Double): Double {
            val li = lag.toInt()
            val fr = (lag - li).toFloat()
            val lim = seg.size - li - 2
            if (lim <= 0) return 0.0
            var s = 0.0
            for (i in 0 until lim) s += seg[i] * (seg[i + li] * (1f - fr) + seg[i + li + 1] * fr)
            return s / lim
        }
        fun score(bpm: Double): Double {
            val lag = 60.0 / bpm * hopRate
            return acf(lag) + 0.5 * acf(lag * 2)
        }
        fun prior(bpm: Double): Double {
            val d = ln(bpm / 125.0) / ln(2.0)
            return exp(-d * d / (2 * 0.55 * 0.55))
        }

        var bestBpm = 120.0; var bestScore = -1.0
        var b = 70.0
        while (b <= 180.0) {
            val s = score(b) * prior(b)
            if (s > bestScore) { bestScore = s; bestBpm = b }
            b += 1.0
        }
        var fine = bestBpm; var fineScore = -1.0
        var f = bestBpm - 1.2
        while (f <= bestBpm + 1.2) {
            val s = score(f)
            if (s > fineScore) { fineScore = s; fine = f }
            f += 0.1
        }
        var bpm = fine
        while (bpm < 80) bpm *= 2
        while (bpm > 180) bpm /= 2

        // fase de la rejilla sobre el mismo tramo
        val lagBins = 60.0 / bpm * hopRate
        var bestPhase = 0.0; var bestPs = -1.0
        var ph = 0.0
        while (ph < lagBins) {
            var s = 0.0
            var pos = ph
            while (pos < seg.size - 1) {
                val i = pos.toInt(); val fr = (pos - i).toFloat()
                s += seg[i] * (1f - fr) + seg[i + 1] * fr
                pos += lagBins
            }
            if (s > bestPs) { bestPs = s; bestPhase = ph }
            ph += 0.5
        }
        // pasar la fase al inicio del audio original y normalizarla a [0, beat)
        val lagSec = 60.0 / bpm
        var first = (start + bestPhase) / hopRate
        first %= lagSec
        if (first < 0) first += lagSec
        return bpm.toFloat() to first
    }

    // ------------------------------------------------------------------ KEY

    private val MAJOR = doubleArrayOf(6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)
    private val MINOR = doubleArrayOf(6.33, 2.68, 3.52, 5.38, 2.60, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17)
    // Camelot por clase de altura (0 = C)
    private val CAM_MAJOR = intArrayOf(8, 3, 10, 5, 12, 7, 2, 9, 4, 11, 6, 1)
    private val CAM_MINOR = intArrayOf(5, 12, 7, 2, 9, 4, 11, 6, 1, 8, 3, 10)

    fun detectKey(pcm: ShortArray, frames: Int, srcRate: Int): String {
        val dec = 4
        val sr = srcRate / dec.toDouble()
        val nMono = frames / dec
        val winN = 8192
        if (nMono < winN * 4) return "--"
        val hann = FloatArray(winN) { (0.5 - 0.5 * cos(2 * PI * it / (winN - 1))).toFloat() }
        val chroma = DoubleArray(12)
        val windows = 40
        val buf = FloatArray(winN)
        val firstNote = 36; val lastNote = 83
        val coeffs = DoubleArray(lastNote - firstNote + 1) {
            val f = 440.0 * 2.0.pow((firstNote + it - 69) / 12.0)
            2 * cos(2 * PI * f / sr)
        }
        for (w in 0 until windows) {
            val startMono = ((0.1 + 0.8 * w / windows) * (nMono - winN)).toInt()
            for (i in 0 until winN) {
                var s = 0
                val base = (startMono + i) * dec
                for (k in 0 until dec) {
                    val idx = (base + k) * 2
                    s += pcm[idx] + pcm[idx + 1]
                }
                buf[i] = s * (1f / (32768f * dec * 2)) * hann[i]
            }
            for (ni in coeffs.indices) {
                val c = coeffs[ni]
                var s1 = 0.0; var s2 = 0.0
                for (i in 0 until winN) {
                    val s0 = buf[i] + c * s1 - s2
                    s2 = s1; s1 = s0
                }
                val power = s1 * s1 + s2 * s2 - c * s1 * s2
                chroma[(firstNote + ni) % 12] += sqrt(max(0.0, power))
            }
        }
        var bestCorr = -2.0; var bestPc = 0; var bestMinor = false
        for (pc in 0 until 12) {
            val cMaj = corr(chroma, MAJOR, pc)
            val cMin = corr(chroma, MINOR, pc)
            if (cMaj > bestCorr) { bestCorr = cMaj; bestPc = pc; bestMinor = false }
            if (cMin > bestCorr) { bestCorr = cMin; bestPc = pc; bestMinor = true }
        }
        return if (bestMinor) "${CAM_MINOR[bestPc]}A" else "${CAM_MAJOR[bestPc]}B"
    }

    private fun corr(chroma: DoubleArray, prof: DoubleArray, tonic: Int): Double {
        var mx = 0.0; var my = 0.0
        for (i in 0 until 12) { mx += chroma[(i + tonic) % 12]; my += prof[i] }
        mx /= 12; my /= 12
        var sxy = 0.0; var sxx = 0.0; var syy = 0.0
        for (i in 0 until 12) {
            val dx = chroma[(i + tonic) % 12] - mx
            val dy = prof[i] - my
            sxy += dx * dy; sxx += dx * dx; syy += dy * dy
        }
        return if (sxx <= 0 || syy <= 0) 0.0 else sxy / sqrt(sxx * syy)
    }

    /** Color de la insignia de tonalidad según el número Camelot (rueda de color). */
    fun keyColor(key: String): Int {
        val n = key.dropLast(1).toIntOrNull() ?: return 0xFF555555.toInt()
        val hue = ((n - 1) * 30f + 15f) % 360f
        return android.graphics.Color.HSVToColor(floatArrayOf(hue, 0.75f, 1f))
    }

}
