package com.neondeck.dj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import com.neondeck.dj.audio.Deck
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

fun fmtTime(sec: Double): String {
    val s = if (sec < 0) 0.0 else sec
    val m = (s / 60).toInt()
    val r = s - m * 60
    return "%02d:%04.1f".format(m, r)
}

private fun DrawScope.centerText(m: TextMeasurer, text: String, cx: Float, cy: Float, style: TextStyle) {
    val l = m.measure(text, style)
    drawText(l, topLeft = Offset(cx - l.size.width / 2f, cy - l.size.height / 2f))
}

/**
 * Plato del deck: disco blanco con BPM gigante, aguja giratoria que sigue la posición,
 * anillo de progreso y gestos de scratch / pitch-bend.
 */
@Composable
fun Platter(deck: Deck, frame: State<Long>, modifier: Modifier = Modifier) {
    val accent = Neon.deck(deck.index)
    val measurer = rememberTextMeasurer(cacheSize = 24)
    var lastAngle by remember { mutableFloatStateOf(0f) }
    val twoPi = (2 * PI).toFloat()

    Canvas(
        modifier
            .pointerInput(deck) {
                detectDragGestures(
                    onDragStart = { o ->
                        lastAngle = atan2(o.y - size.height / 2f, o.x - size.width / 2f)
                        deck.touchStart()
                    },
                    onDragEnd = { deck.touchEnd() },
                    onDragCancel = { deck.touchEnd() }
                ) { change, _ ->
                    val a = atan2(change.position.y - size.height / 2f, change.position.x - size.width / 2f)
                    var d = a - lastAngle
                    if (d > PI.toFloat()) d -= twoPi
                    if (d < -PI.toFloat()) d += twoPi
                    lastAngle = a
                    deck.scratchSeconds(d / twoPi * 1.8)   // 33⅓ rpm: 1 vuelta = 1.8 s
                    change.consume()
                }
            }
            .pointerInput(deck) {
                detectTapGestures(onTap = { o ->
                    val cx = size.width / 2f; val cy = size.height / 2f
                    val r = minOf(size.width, size.height) / 2f
                    if (o.x > cx + 0.2f * r && o.y > cy - 0.2f * r && o.y < cy + 0.22f * r) deck.cycleRange()
                })
            }
    ) {
        @Suppress("UNUSED_VARIABLE") val tick = frame.value
        val s = size.minDimension
        val c = Offset(size.width / 2f, size.height / 2f)
        val ringW = s * 0.045f
        val rr = s / 2f - ringW * 1.55f          // radio medio del aro (deja margen para el resplandor)
        val r = rr - ringW / 2f - s * 0.012f     // radio del disco
        val playing = deck.playing
        val ink = androidx.compose.ui.graphics.lerp(accent, Color.Black, 0.45f)   // color del deck legible sobre blanco

        // ---- aro iluminado del color del deck
        val glowA = if (playing) 0.20f else 0.09f
        for (i in 4 downTo 1) {
            drawCircle(accent.copy(alpha = glowA * (5 - i) / 4f * 0.55f), rr, c, style = Stroke(ringW + i * ringW * 0.55f))
        }
        drawCircle(Color(0xFF1B1B23), rr, c, style = Stroke(ringW))
        drawCircle(accent.copy(alpha = if (playing) 0.55f else 0.30f), rr, c, style = Stroke(ringW * 0.28f))
        // progreso de la pista
        val sweep = 360f * deck.progress()
        if (sweep > 0.5f) {
            drawArc(
                accent.copy(alpha = 0.22f), -90f, sweep, false,
                Offset(c.x - rr, c.y - rr), Size(2 * rr, 2 * rr), style = Stroke(ringW * 1.7f, cap = StrokeCap.Round)
            )
            drawArc(
                accent, -90f, sweep, false,
                Offset(c.x - rr, c.y - rr), Size(2 * rr, 2 * rr), style = Stroke(ringW * 0.75f, cap = StrokeCap.Round)
            )
        }

        // ---- disco blanco sólido, liso (sin marcas)
        drawCircle(Color.White, r, c)

        // pulso de beat
        if (playing && deck.track != null) {
            val ph = deck.beatPhase().toFloat()
            if (ph < 0.2f) drawCircle(accent.copy(alpha = 0.55f * (1f - ph / 0.2f)), r * 0.985f, c, style = Stroke(s * 0.03f))
        }

        // ---- letra del deck
        centerText(
            measurer, if (deck.index == 0) "A" else "B", c.x + (if (deck.index == 0) -1 else 1) * r * 0.70f, c.y - r * 0.70f,
            TextStyle(color = ink, fontSize = (s * 0.075f).toSp(), fontWeight = FontWeight.Black)
        )

        // ---- aguja
        val ang = (((deck.posSec() * 200.0) % 360.0) - 90.0) * PI / 180.0
        val ca = cos(ang).toFloat(); val sa = sin(ang).toFloat()
        val tip = Offset(c.x + ca * r * 0.96f, c.y + sa * r * 0.96f)
        val base = Offset(c.x + ca * r * 0.12f, c.y + sa * r * 0.12f)
        drawLine(Color.Black.copy(alpha = 0.18f), base, tip, s * 0.04f, StrokeCap.Round)
        drawLine(Color(0xFF0C0C10), base, tip, s * 0.026f, StrokeCap.Round)
        drawCircle(Color(0xFF9A9AA6), s * 0.05f, c)
        drawCircle(Color.White.copy(alpha = 0.55f), s * 0.05f, c, style = Stroke(s * 0.008f))
        drawCircle(accent, s * 0.016f, c)

        // ---- textos
        val t = deck.track
        val bpm = deck.currentBpm()
        val analyzing = t != null && t.bpm <= 0f
        val labelStyle = TextStyle(color = ink, fontSize = (s * 0.07f).toSp(), fontWeight = FontWeight.Bold, letterSpacing = (s * 0.006f).toSp())
        centerText(measurer, if (analyzing) "ANALIZANDO…" else if (deck.syncOn) "REL" else "BPM", c.x, c.y - r * 0.62f, labelStyle)

        val bigColor = if (deck.syncOn) ink else Color(0xFF0C0C10)
        val intPart = if (t == null || analyzing) "--" else "%d".format(bpm.toInt())
        val dec = if (t == null || analyzing) "" else ".%d".format(((bpm - bpm.toInt()) * 10).toInt().coerceIn(0, 9))
        val numStyle = TextStyle(color = bigColor, fontWeight = FontWeight.Bold, fontFeatureSettings = "tnum")
        val big = measurer.measure(intPart, numStyle.copy(fontSize = (s * 0.215f).toSp()))
        val small = measurer.measure(dec, numStyle.copy(fontSize = (s * 0.11f).toSp()))
        val totalW = big.size.width + small.size.width
        val bx = c.x - totalW / 2f
        val by = c.y - r * 0.34f - big.size.height / 2f
        drawText(big, topLeft = Offset(bx, by))
        drawText(small, topLeft = Offset(bx + big.size.width, by + big.size.height - small.size.height * 1.12f))

        val pitchPct = deck.pitch * deck.range * 100f
        val sideStyle = TextStyle(fontSize = (s * 0.068f).toSp(), fontWeight = FontWeight.Bold, fontFeatureSettings = "tnum")
        centerText(measurer, "%+.1f%%".format(pitchPct), c.x - r * 0.58f, c.y + r * 0.02f,
            sideStyle.copy(color = if (kotlin.math.abs(pitchPct) < 0.05f) Color(0xFF0B8A43) else Color(0xFF3A3A44)))
        centerText(measurer, "±%d".format((deck.range * 100f).toInt()), c.x + r * 0.58f, c.y + r * 0.02f, sideStyle.copy(color = Color(0xFF6B6B76)))

        val dur = deck.durationSec().toDouble()
        val el = deck.posSec()
        centerText(
            measurer, fmtTime(el), c.x, c.y + r * 0.37f,
            TextStyle(color = Color(0xFF6B6B76), fontSize = (s * 0.095f).toSp(), fontWeight = FontWeight.SemiBold, fontFeatureSettings = "tnum")
        )
        centerText(
            measurer, "-" + fmtTime(dur - el), c.x, c.y + r * 0.64f,
            TextStyle(color = Color(0xFF0C0C10), fontSize = (s * 0.11f).toSp(), fontWeight = FontWeight.Bold, fontFeatureSettings = "tnum")
        )
    }
}
