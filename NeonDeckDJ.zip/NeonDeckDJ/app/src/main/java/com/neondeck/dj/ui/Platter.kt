package com.neondeck.dj.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextMeasurer
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import com.neondeck.dj.audio.Deck
import kotlin.math.PI
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

fun fmtTime(sec: Double): String {
    val s = if (sec < 0) 0.0 else sec
    val m = (s / 60).toInt()
    val r = s - m * 60
    return "%02d:%04.1f".format(m, r)
}

private fun DrawScope.centerText(m: TextMeasurer, text: String, cx: Float, cy: Float, style: TextStyle) {
    val l = m.measure(text, style)
    drawText(l, topLeft = Offset(cx - l.size.width / 2f, cy - l.size.height / 2f))
}

/**
 * Plato del deck: disco blanco con BPM gigante, aguja giratoria que sigue la posición,
 * anillo de progreso y gestos de scratch / pitch-bend.
 */
@Composable
fun Platter(deck: Deck, frame: State<Long>, modifier: Modifier = Modifier) {
    val accent = Neon.deck(deck.index)
    val measurer = rememberTextMeasurer(cacheSize = 24)
    var lastAngle by remember { mutableFloatStateOf(0f) }
    val twoPi = (2 * PI).toFloat()

    Canvas(
        modifier
            .pointerInput(deck) {
                detectDragGestures(
                    onDragStart = { o ->
                        lastAngle = atan2(o.y - size.height / 2f, o.x - size.width / 2f)
                        deck.touchStart()
                    },
                    onDragEnd = { deck.touchEnd() },
                    onDragCancel = { deck.touchEnd() }
                ) { change, _ ->
                    val a = atan2(change.position.y - size.height / 2f, change.position.x - size.width / 2f)
                    var d = a - lastAngle
                    if (d > PI.toFloat()) d -= twoPi
                    if (d < -PI.toFloat()) d += twoPi
                    lastAngle = a
                    deck.scratchSeconds(d / twoPi * 1.8)   // 33⅓ rpm: 1 vuelta = 1.8 s
                    change.consume()
                }
            }
            .pointerInput(deck) {
                detectTapGestures(onTap = { o ->
                    val cx = size.width / 2f; val cy = size.height / 2f
                    val r = minOf(size.width, size.height) / 2f
                    if (o.x > cx + 0.2f * r && o.y > cy - 0.2f * r && o.y < cy + 0.22f * r) deck.cycleRange()
                })
            }
    ) {
        @Suppress("UNUSED_VARIABLE") val tick = frame.value
        val s = size.minDimension
        val c = Offset(size.width / 2f, size.height / 2f)
        val ringW = s * 0.05f
        val rr = s / 2f - ringW / 2f
        val r = s / 2f - ringW - s * 0.012f

        // resplandor suave del deck cuando suena
        if (deck.playing) drawCircle(accent.copy(alpha = 0.10f), s / 2f, c)
        // anillo + progreso de la pista (color del deck)
        drawCircle(Color(0xFF1B1D29), rr, c, style = Stroke(ringW))
        drawArc(
            Brush.sweepGradient(listOf(accent.copy(alpha = 0.35f), accent, accent.copy(alpha = 0.35f)), c),
            -90f, 360f * deck.progress(), false,
            Offset(c.x - rr, c.y - rr), Size(2 * rr, 2 * rr), style = Stroke(ringW, cap = StrokeCap.Round)
        )
        // disco con degradado
        drawCircle(
            Brush.radialGradient(listOf(Color.White, Color(0xFFE6EAF4)), center = c, radius = r),
            r, c
        )

        // pulso de beat
        if (deck.playing && deck.track != null) {
            val ph = deck.beatPhase().toFloat()
            if (ph < 0.2f) drawCircle(accent.copy(alpha = 0.45f * (1f - ph / 0.2f)), r - s * 0.015f, c, style = Stroke(s * 0.035f))
        }

        // aguja
        val ang = (((deck.posSec() * 200.0) % 360.0) - 90.0) * PI / 180.0
        val tip = Offset(c.x + cos(ang).toFloat() * r * 0.97f, c.y + sin(ang).toFloat() * r * 0.97f)
        drawLine(Color(0xFF111111), c, tip, s * 0.05f, StrokeCap.Round)
        drawCircle(Color(0xFF8A8A90), s * 0.045f, c)

        // textos
        val t = deck.track
        val bpm = deck.currentBpm()
        val labelStyle = TextStyle(color = if (deck.syncOn) accent else Color(0xFF555559), fontSize = (s * 0.075f).toSp(), fontWeight = FontWeight.Bold)
        centerText(measurer, if (t != null && t.bpm <= 0f) "ANALIZANDO…" else if (deck.syncOn) "REL" else "BPM", c.x, c.y - r * 0.62f, labelStyle)

        val bigColor = if (deck.syncOn) accent else Color(0xFF0A0A0A)
        val intPart = if (t == null || t.bpm <= 0f) "--" else "%d".format(bpm.toInt())
        val dec = if (t == null || t.bpm <= 0f) "" else ".%d".format(((bpm - bpm.toInt()) * 10).toInt().coerceIn(0, 9))
        val big = measurer.measure(intPart, TextStyle(color = bigColor, fontSize = (s * 0.215f).toSp(), fontWeight = FontWeight.Bold))
        val small = measurer.measure(dec, TextStyle(color = bigColor, fontSize = (s * 0.11f).toSp(), fontWeight = FontWeight.Bold))
        val totalW = big.size.width + small.size.width
        val bx = c.x - totalW / 2f
        val by = c.y - r * 0.34f - big.size.height / 2f
        drawText(big, topLeft = Offset(bx, by))
        drawText(small, topLeft = Offset(bx + big.size.width, by + big.size.height - small.size.height * 1.12f))

        val sideStyle = TextStyle(color = Color(0xFF444448), fontSize = (s * 0.07f).toSp(), fontWeight = FontWeight.Bold)
        centerText(measurer, "%+.1f%%".format(deck.pitch * deck.range * 100f), c.x - r * 0.56f, c.y, sideStyle)
        centerText(measurer, "±%d".format((deck.range * 100f).toInt()), c.x + r * 0.56f, c.y, sideStyle)

        val dur = deck.durationSec().toDouble()
        val el = deck.posSec()
        centerText(
            measurer, fmtTime(el), c.x, c.y + r * 0.37f,
            TextStyle(color = Color(0xFF8A8A90), fontSize = (s * 0.1f).toSp(), fontWeight = FontWeight.SemiBold)
        )
        centerText(
            measurer, fmtTime(dur - el), c.x, c.y + r * 0.64f,
            TextStyle(color = Color(0xFF0A0A0A), fontSize = (s * 0.115f).toSp(), fontWeight = FontWeight.Bold)
        )
    }
}
