# NEON by DARVI'S (Android)

App de DJ de 2 decks (Kotlin + Jetpack Compose, minSdk 26) con interfaz horizontal inspirada en tu video.

## Compilar
- **Android Studio**: File > Open esta carpeta > Run (o Build > Build APK).
- **Sin PC potente**: sube la carpeta a un repositorio de GitHub; el workflow `.github/workflows/build-apk.yml`
  genera el APK (Actions > Build APK > Artifacts).

## Controlador Hercules DJControl Inpulse 200
Enchúfalo por USB-OTG: Android lo ve como dispositivo MIDI estándar y la app conecta sola.
Ajustes (⚙) > MIDI: monitor MIDI, **Mapeo guiado** (aprende cada botón/fader/jog), tabla editable, restaurar.
El mapa por defecto (assets/midi/hercules_inpulse_200.json) es una base: ejecuta el mapeo guiado una vez para
ajustarlo a tu unidad. LEDs de retorno: Play, Cue, Sync, Vinyl, Loop, PFL, modos y pads.

## Funciones
Scratch/bend en plato y jog, SYNC tempo+fase, loops, rolls, 8 hot cues, 8 samples (cargas los tuyos con pulsación larga),
EQ 3 bandas, filtro, Echo/Flanger/Reverb, BPM/rejilla/tonalidad automáticos, crossfader (3 curvas), grabación WAV, librería.

## Novedades 1.1
- Nombre NEON by DARVI'S; deck B en naranja/ámbar (sin rosa); diseño con degradados y brillo.
- Scratch suavizado (interpolación Hermite) y soporte WAV 8/16/24/32 bits/float.
- Carga en streaming (suena en ~1.5 s) + precarga al seleccionar en la biblioteca.
- Biblioteca: pestañas Canciones/Carpetas (+ añadir carpetas), BPM rápido en lote, temas tocados resaltados (se reinician al cerrar la app).
- Fader vertical con marca central = BPM original.
