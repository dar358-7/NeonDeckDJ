# NEON by DARVI'S (Android)

App de DJ de 2 decks (Kotlin + Jetpack Compose, minSdk 26) con interfaz horizontal inspirada en tu video.

## Compilar
- **Android Studio**: File > Open esta carpeta > Run (o Build > Build APK).
- **Sin PC potente**: sube la carpeta a un repositorio de GitHub; el workflow `.github/workflows/build-apk.yml`
  genera el APK (Actions > Build APK > Artifacts).

## Controlador Hercules DJControl Inpulse 200
Enchúfalo por USB-OTG: Android lo ve como dispositivo MIDI estándar y la app conecta sola.
Ajustes (⚙) > MIDI: monitor MIDI, **Mapeo guiado** (aprende cada botón/fader/jog), tabla editable, restaurar.
El mapa por defecto (assets/midi/hercules_inpulse_200.json) es una base: ejecuta el mapeo guiado una vez para
ajustarlo a tu unidad. LEDs de retorno: Play, Cue, Sync, Vinyl, Loop, PFL, modos y pads.

## Funciones
Scratch/bend en plato y jog, SYNC tempo+fase, loops, rolls, 8 hot cues, 8 samples (cargas los tuyos con pulsación larga),
EQ 3 bandas, filtro, Echo/Flanger/Reverb, BPM/rejilla/tonalidad automáticos, crossfader (3 curvas), grabación WAV, librería.

## Novedades 1.7.12
- 5 efectos nuevos por deck: PING-PONG, PHASER, CRUSH, GATE (trance) y AUTO-PAN (mezclador > EFECTO).
- CUE mantenido + PLAY: la reproducción se engancha y sigue al soltar CUE (como en CDJ); antes se pausaba.

## Novedades 1.7.11
- Buscador de la biblioteca: teclado con acción «Buscar», sin autocorrección, y filtrado protegido contra errores (queda registrado en Ajustes > Acerca de).

## Novedades 1.7.10
- CrashLog pasa a estar dentro de Prefs.kt (ya no hay archivo nuevo que se pueda perder al subir).

## Novedades 1.7.9
- Corrige el error de compilación de 1.7.7/1.7.8 (faltaba importar CrashLog).

## Novedades 1.7.8
- Arranque cuantizado: se elimina una condición de carrera (el otro deck cambiaba de pista justo en ese instante) que podía cerrar la app tras una mezcla.

## Novedades 1.7.7
- Protección del hilo de audio: un error en un bloque ya no cierra la app.
- Registro del último error (también tras un cierre inesperado) en Ajustes > Acerca de, con botón Copiar.

## Novedades 1.7.6
- Bluetooth: la salida usa PCM de 16 bits (algunos teléfonos distorsionan el audio float hacia el códec A2DP).

## Novedades 1.7.5
- Detección de BPM corregida: usa el BPM escrito en el título («85 BPM») cuando existe, evita errores de octava, ajusta a entero cuando corresponde y afina con la rejilla de beats (0,01).
- Se descartan los BPM guardados con el detector anterior: pulsa «Analizar BPM + Key» para recalcularlos (las tonalidades se conservan).

## Novedades 1.7.4
- Bluetooth: -3 dB de margen en la salida (el códec A2DP distorsiona cerca del tope), además del búfer grande ya existente.

## Novedades 1.7.3
- Se revierten los cambios de 1.7.2 (tamaño de platos y velocidad del analizador); vuelve el comportamiento de 1.7.1.

## Novedades 1.7.1
- Botonera inferior reorganizada: cada deck en su panel (mezclador, play, cue, sync, loop) con borde de su color, crossfader en cápsula central y pads con los mismos márgenes.
- Nombre y artista completos en la cabecera con texto en movimiento (marquesina) cuando no caben.

## Novedades 1.7.0
- Pre-escucha (CUE) **pre-fader**: se oye aunque el fader de canal esté abajo. Los laterales solo llevan el fader de BPM (el volumen de canal pasa al mezclador como knob VOL).
- Biblioteca: orden por BPM ↑/↓, A-Z y tonalidad; filtro «≈ BPM» (±6 %, también mitad/doble) respecto al otro deck.
- Ondas con paleta más distintiva (rojo→naranja→amarillo→verde→cian→azul→violeta) y contraste adaptativo por pista.
- Beatgrid fino: seguimiento de beats por programación dinámica sobre transitorios; rejilla fija (regresión) o dinámica si el tempo varía.
- Ajuste manual: botones ± = 0,01 BPM (acelera al mantener); en el mezclador: rejilla ±1/±10 ms, BPM de rejilla ±0,01, «BEAT AQUÍ».
- SYNC: enganche de fase con rejilla dinámica y arranque cuantizado (PLAY/CUE esperan al sub-beat 1/4 exacto del otro deck).
- Latencia: se mide con AudioTrack.getTimestamp y las ondas/agujas se dibujan en la posición realmente audible.

## Novedades 1.6.1
- Firma fija (app/neon.jks): las nuevas versiones se instalan como ACTUALIZACIÓN sobre la app anterior. Solo la primera vez que pases de una versión antigua a esta hay que desinstalar la anterior.
- Faders laterales como antes (sin FINO/KEY), vúmetro más ancho.

## Novedades 1.6
- Key Lock / Master Tempo (WSOLA): el tono no cambia al variar el pitch. Botón KEY junto a cada fader y en el mezclador.
- SYNC con enganche de fase continuo (PLL) además de tempo y rejilla.
- Beat Jump cuantizado (pads BEAT JUMP: ±1/±4 y ±8/±16 beats) y loops de 1/32 a 32 beats.
- Stems aproximados por deck: SIN VOZ / SOLO VOZ (cancelación del centro; no es separación con IA).
- Modo día (Ajustes → Pantalla), háptica al pulsar botones y pads, bordes de cristal azul/naranja, aguja con contrapeso.
- Latencia de búfer adaptativa (empieza en 2 bloques y sube sola si hay cortes).

## Novedades 1.5.1
- Pre-escucha por los auriculares del controlador USB: salida de 4 canales (1-2 master, 3-4 auriculares).
- Botón PLAY con el mismo estilo que SYNC activo; se quitó el medidor de fase en pantalla.

## Novedades 1.5
- Ajustes → Audio: elige la salida principal y una salida de pre-escucha propia (cable, USB, Bluetooth, altavoz), con volumen y mezcla cue/master.
- Botón BROWSER (barra superior y encoder del controlador) abre/cierra la biblioteca; LOAD A/B carga el tema resaltado.
- Aro del plato A en azul.
- Empate manual más preciso: fader de tempo relativo con modo FINO, ± de 0.1 % (0.02 % en FINO) con repetición al mantener, pitch con 2 decimales, BPM con 2 decimales y medidor de fase en ms entre decks.

## Novedades 1.4
- Mapa MIDI OFICIAL del Inpulse 200 (lista de comandos de Hercules V1.0): decks en 0x91/0x92, pads 0x96/0x97 con notas por modo (00/10/20/30), mixer en B1/B2, globales en B0/90, jog con SHIFT en B4/B5.
- Corregido el decodificador de jog/browse (encoders relativos 01-3F / 7F-40).
- LEDs de pads según el modo activo; al conectar se pide el estado de faders y knobs (B0 7F 7F).

## Novedades 1.3
- Ondas con el estilo de la referencia: barras con halo de color y núcleo brillante, franja central de picos de transitorios, números de compás y más resolución.
- Las ondas ocupan todo el ancho y pasan por debajo de los platos, ahora de cristal translúcido con escala de 60 marcas.
- Biblioteca: tonalidad Camelot + nota (p. ej. 8A · Am) y análisis automático de BPM/Key en segundo plano.

## Novedades 1.2
- Rediseño premium oscuro: negro mate, carbón y neón cian #00F0FF / naranja #FF6B00 / violeta #8A2BE2, esquinas redondeadas y brillo neón al activar.
- Platos con aro perimetral iluminado (Deck A cian, Deck B naranja), aguja central, BPM / pitch / tiempo legibles.
- Ondas por frecuencia (graves rojo/naranja, medios verde/amarillo, agudos azul/blanco) y playhead neón fino.
- Pads retroiluminados con luz ambiental, botones LOOP/PLAY/CUE/SYNC neón, crossfader metálico.
- Barra superior consolidada: título, artista, BPM, Key y logo NEON by DARVI'S.
- Biblioteca: la tonalidad (Camelot) aparece junto al BPM de cada tema; "Analizar" calcula ambos.
- MIDI: mapa base con decks en canales 2/3, Mapeo rápido (aprendes el Deck A y el B se copia solo), Mapeo completo y botón Copiar A→B.

## Novedades 1.1
- Nombre NEON by DARVI'S; deck B en naranja/ámbar (sin rosa); diseño con degradados y brillo.
- Scratch suavizado (interpolación Hermite) y soporte WAV 8/16/24/32 bits/float.
- Carga en streaming (suena en ~1.5 s) + precarga al seleccionar en la biblioteca.
- Biblioteca: pestañas Canciones/Carpetas (+ añadir carpetas), BPM rápido en lote, temas tocados resaltados (se reinician al cerrar la app).
- Fader vertical con marca central = BPM original.
