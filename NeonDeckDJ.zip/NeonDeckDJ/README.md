# NEON by DARVI'S (Android)

App de DJ de 2 decks (Kotlin + Jetpack Compose, minSdk 26) con interfaz horizontal inspirada en tu video.

## Compilar
- **Android Studio**: File > Open esta carpeta > Run (o Build > Build APK).
- **Sin PC potente**: sube la carpeta a un repositorio de GitHub; el workflow `.github/workflows/build-apk.yml`
  genera el APK (Actions > Build APK > Artifacts).

## Controlador Hercules DJControl Inpulse 200
Enchúfalo por USB-OTG: Android lo ve como dispositivo MIDI estándar y la app conecta sola.
Ajustes (⚙) > MIDI: monitor MIDI, **Mapeo guiado** (aprende cada botón/fader/jog), tabla editable, restaurar.
El mapa por defecto (assets/midi/hercules_inpulse_200.json) es una base: ejecuta el mapeo guiado una vez para
ajustarlo a tu unidad. LEDs de retorno: Play, Cue, Sync, Vinyl, Loop, PFL, modos y pads.

## Funciones
Scratch/bend en plato y jog, SYNC tempo+fase, loops, rolls, 8 hot cues, 8 samples (cargas los tuyos con pulsación larga),
EQ 3 bandas, filtro, Echo/Flanger/Reverb, BPM/rejilla/tonalidad automáticos, crossfader (3 curvas), grabación WAV, librería.

## Novedades 1.4
- Mapa MIDI OFICIAL del Inpulse 200 (lista de comandos de Hercules V1.0): decks en 0x91/0x92, pads 0x96/0x97 con notas por modo (00/10/20/30), mixer en B1/B2, globales en B0/90, jog con SHIFT en B4/B5.
- Corregido el decodificador de jog/browse (encoders relativos 01-3F / 7F-40).
- LEDs de pads según el modo activo; al conectar se pide el estado de faders y knobs (B0 7F 7F).

## Novedades 1.3
- Ondas con el estilo de la referencia: barras con halo de color y núcleo brillante, franja central de picos de transitorios, números de compás y más resolución.
- Las ondas ocupan todo el ancho y pasan por debajo de los platos, ahora de cristal translúcido con escala de 60 marcas.
- Biblioteca: tonalidad Camelot + nota (p. ej. 8A · Am) y análisis automático de BPM/Key en segundo plano.

## Novedades 1.2
- Rediseño premium oscuro: negro mate, carbón y neón cian #00F0FF / naranja #FF6B00 / violeta #8A2BE2, esquinas redondeadas y brillo neón al activar.
- Platos con aro perimetral iluminado (Deck A cian, Deck B naranja), aguja central, BPM / pitch / tiempo legibles.
- Ondas por frecuencia (graves rojo/naranja, medios verde/amarillo, agudos azul/blanco) y playhead neón fino.
- Pads retroiluminados con luz ambiental, botones LOOP/PLAY/CUE/SYNC neón, crossfader metálico.
- Barra superior consolidada: título, artista, BPM, Key y logo NEON by DARVI'S.
- Biblioteca: la tonalidad (Camelot) aparece junto al BPM de cada tema; "Analizar" calcula ambos.
- MIDI: mapa base con decks en canales 2/3, Mapeo rápido (aprendes el Deck A y el B se copia solo), Mapeo completo y botón Copiar A→B.

## Novedades 1.1
- Nombre NEON by DARVI'S; deck B en naranja/ámbar (sin rosa); diseño con degradados y brillo.
- Scratch suavizado (interpolación Hermite) y soporte WAV 8/16/24/32 bits/float.
- Carga en streaming (suena en ~1.5 s) + precarga al seleccionar en la biblioteca.
- Biblioteca: pestañas Canciones/Carpetas (+ añadir carpetas), BPM rápido en lote, temas tocados resaltados (se reinician al cerrar la app).
- Fader vertical con marca central = BPM original.
