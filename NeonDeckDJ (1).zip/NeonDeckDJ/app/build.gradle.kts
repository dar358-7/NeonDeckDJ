plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

android {
    namespace = "com.neondeck.dj"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.neondeck.dj"
        minSdk = 26
        targetSdk = 35
        versionCode = 21
        versionName = "1.7.9"
    }

    // Clave FIJA incluida en el proyecto: todas las versiones salen con la misma firma,
    // así Android las instala como ACTUALIZACIÓN sobre la app ya instalada (sin desinstalar).
    signingConfigs {
        create("neon") {
            storeFile = file("neon.jks")
            storePassword = "neondarvis"
            keyAlias = "neon"
            keyPassword = "neondarvis"
        }
    }
    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("neon")
        }
        debug { signingConfig = signingConfigs.getByName("neon") }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { compose = true }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2024.10.01")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
}
