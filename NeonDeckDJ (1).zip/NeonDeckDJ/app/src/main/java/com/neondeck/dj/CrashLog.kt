package com.neondeck.dj

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Guarda el último error (en un archivo) para poder verlo en Ajustes > Acerca de, incluso tras un cierre inesperado. */
object CrashLog {
    private fun file(ctx: Context) = File(ctx.filesDir, "last_crash.txt")

    fun save(ctx: Context, where: String, e: Throwable) {
        try {
            val t = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            file(ctx).writeText("$t  [$where]\n" + e.stackTraceToString().take(4000))
        } catch (_: Throwable) { }
    }

    fun read(ctx: Context): String = try { file(ctx).takeIf { it.exists() }?.readText() ?: "" } catch (_: Throwable) { "" }
    fun clear(ctx: Context) { try { file(ctx).delete() } catch (_: Throwable) { } }

    fun install(ctx: Context) {
        val app = ctx.applicationContext
        val prev = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { th, e ->
            save(app, "Hilo ${th.name}", e)
            prev?.uncaughtException(th, e)
        }
    }
}
